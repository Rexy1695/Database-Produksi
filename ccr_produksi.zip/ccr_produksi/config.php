<?php

date_default_timezone_set('Asia/Kuala_Lumpur');

$host   = 'localhost';
$user   = 'root';
$pass   = '';
$dbname = 'ccr_produksi';

$koneksi = mysqli_connect($host, $user, $pass, $dbname);

// Cek koneksi database
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Menentukan protocol (http / https)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';

// Folder project
$project_folder = 'ccr_produksi';

// Base URL otomatis
$main_url = $protocol . $_SERVER['HTTP_HOST'] . '/' . $project_folder;