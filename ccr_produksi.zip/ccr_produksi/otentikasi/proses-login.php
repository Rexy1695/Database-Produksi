<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = $_POST['password'];

    $result = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username = '$username'");

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row['password'])) {
            // Set Session
            $_SESSION['login'] = true;
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = $row['role'];
            
            // REDIRECT BALIK KE LOGIN DULU UNTUK MUNCULKAN ALERT
            header("Location: login.php?pesan=sukses");
            exit;
        }
    }
    // Jika gagal
    header("Location: login.php?pesan=gagal");
    exit;
}