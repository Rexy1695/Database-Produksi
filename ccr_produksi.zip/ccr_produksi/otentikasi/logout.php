<?php
session_start();

// Hapus semua data session
session_unset();
session_destroy();

// Arahkan kembali ke login dengan pesan logout
header("Location: login.php?pesan=logout");
exit;
