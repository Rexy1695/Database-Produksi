<?php
require "../config.php";
session_start();

// Proteksi Halaman: Jika sudah login, tendang ke index (kecuali sedang proses sukses)
if (isset($_SESSION['login']) && (!isset($_GET['pesan']) || $_GET['pesan'] !== 'sukses')) {
    header("Location: ../index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CCR - Production Monitoring System</title>

    <link rel="shortcut icon" type="image/x-icon" href="<?= $main_url ?>/assets/images/logo.png">
    <link rel="stylesheet" type="text/css" href="<?= $main_url ?>/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        :root {
            --primary-blue: #0A0F3A;
            --accent-neon: #00D1FF;
            --glass-bg: rgba(255, 255, 255, 0.05);
            --glass-border: rgba(255, 255, 255, 0.1);
            --glow: rgba(0, 209, 255, 0.3);
        }

        body,
        html {
            height: 100%;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #fff;
            overflow: hidden;

            /* Background Image */
            background: linear-gradient(rgba(10, 15, 58, 0.75), rgba(10, 15, 58, 0.75)),
                url('<?= $main_url ?>/assets/images/loader.jpg') no-repeat center center fixed;
            background-size: cover;
        }   

        /* ==============================
           1. PRELOADER TECH SCANNING
           ============================== */
        #robot-loader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: #020617;
            z-index: 10000;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .loader-text-container {
            position: relative;
            margin-top: 25px;
            text-align: center;
            width: 300px;
        }

        .loader-text-base {
            color: rgba(255, 255, 255, 0.1);
            /* Teks samar sebagai background */
            font-size: 1rem;
            font-weight: 300;
            letter-spacing: 6px;
            text-transform: uppercase;
            margin: 0;
        }

        .loader-text-dynamic {
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            color: var(--accent-neon);
            font-size: 1rem;
            font-weight: 400;
            letter-spacing: 6px;
            text-transform: uppercase;
            white-space: nowrap;
            overflow: hidden;
            width: 0;
            border-right: 2px solid var(--accent-neon);
            animation: scanning-text 2.5s steps(20) infinite;
        }

        @keyframes scanning-text {
            0% {
                width: 0;
            }

            50% {
                width: 100%;
            }

            100% {
                width: 0;
            }
        }

        /* ==============================
           2. BACKGROUND ABSTRACT SHAPES
           ============================== */
        .abstract-background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
        }

        .shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
        }

        .shape-1 {
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(0, 209, 255, 0.15) 0%, rgba(0, 209, 255, 0) 70%);
            bottom: -150px;
            left: -150px;
        }

        .shape-2 {
            width: 450px;
            height: 450px;
            background: radial-gradient(circle, rgba(0, 81, 255, 0.1) 0%, rgba(0, 81, 255, 0) 70%);
            top: -100px;
            right: -100px;
        }

        /* ==============================
           3. LOGIN CARD (GLASSMORPHISM)
           ============================== */
        .auth-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-card {
            background: var(--glass-bg);
            backdrop-filter: blur(25px);
            -webkit-backdrop-filter: blur(25px);
            border: 1px solid var(--glass-border);
            border-radius: 24px;
            padding: 70px 45px 45px;
            width: 100%;
            max-width: 420px;
            text-align: center;
            position: relative;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.4);
        }

        .logo-wrapper {
            width: 85px;
            height: 85px;
            background: #fff;
            padding: 15px;
            border-radius: 50%;
            position: absolute;
            top: -42px;
            left: 50%;
            transform: translateX(-50%);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.3);
            z-index: 5;
        }

        .login-card h2 {
            font-size: 26px;
            font-weight: 700;
            margin-bottom: 10px;
            letter-spacing: 0.5px;
        }

        .login-card p {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.6);
            margin-bottom: 40px;
        }

        /* Form Inputs */
        .form-input-group {
            position: relative;
            margin-bottom: 20px;
        }

        .form-input {
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            border-radius: 12px;
            padding: 14px 20px;
            color: #fff;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--accent-neon);
            background: rgba(255, 255, 255, 0.08);
            box-shadow: 0 0 15px var(--glow);
        }

        .password-toggle {
            position: absolute;
            right: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.4);
            cursor: pointer;
            z-index: 10;
        }

        .password-toggle:hover {
            color: var(--accent-neon);
        }

        /* Login Button */
        .btn-login {
            width: 100%;
            background: var(--accent-neon);
            color: var(--primary-blue);
            border: none;
            padding: 15px;
            border-radius: 12px;
            font-weight: 800;
            font-size: 15px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            cursor: pointer;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            margin-top: 15px;
        }

        .btn-login:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0, 209, 255, 0.4);
            color: #fff;
        }

        .fade-out {
            opacity: 0;
            transition: opacity 0.8s ease-out;
            pointer-events: none;
        }

        .footer-text {
            margin-top: 30px;
            font-size: 11px;
            color: rgba(255, 255, 255, 0.3);
            letter-spacing: 1px;
        }
    </style>
</head>

<body>

    <div id="robot-loader">
        <script src="https://unpkg.com/@dotlottie/player-component@latest/dist/dotlottie-player.mjs" type="module"></script>
        <dotlottie-player src="https://lottie.host/9f518861-5509-40d1-9494-0130f146312a/BghwE13P16.json"
            background="transparent" speed="1.2" style="width: 250px; height: 250px;" loop autoplay>
        </dotlottie-player>

        <div class="loader-text-container">
            <p class="loader-text-base"></p>
            <div class="loader-text-dynamic">Selamat Datang</div>
        </div>
    </div>

    <div class="abstract-background">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
    </div>

    <div class="auth-container">
        <div class="login-card">
            <div class="logo-wrapper">
                <img src="<?= $main_url ?>/assets/images/logo.png" class="img-fluid" alt="CCR Logo">
            </div>

            <h2>Project Control</h2>
            <p>Khusus Petugas Resmi</p>

            <form action="proses-login.php" method="POST">
                <div class="form-input-group">
                    <input type="text" name="username" class="form-input" placeholder="Username" required autofocus autocomplete="username">
                </div>

                <div class="form-input-group">
                    <input type="password" name="password" id="password" class="form-input" placeholder="Password" required autocomplete="current-password">
                    <i class="fas fa-eye password-toggle" id="togglePassword"></i>
                </div>

                <button type="submit" name="login" class="btn-login">Sign In</button>
            </form>

            <div class="footer-text">
                &copy; 2026 PRODUCTION MONITORING SYSTEM V2.0
            </div>
        </div>
    </div>

    <script src="<?= $main_url ?>/assets/vendors/js/vendors.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        // URL Parameter Handler
        const urlParams = new URLSearchParams(window.location.search);
        const pesan = urlParams.get('pesan');

        // Loader Handler
        window.addEventListener('load', function() {
            const loader = document.getElementById('robot-loader');
            if (pesan !== 'sukses') {
                setTimeout(() => {
                    loader.classList.add('fade-out');
                    setTimeout(() => {
                        loader.style.display = 'none';
                    }, 800);
                }, 2200);
            }
        });

        // SweetAlert Handler (Tema Gelap Senada)
        const swalConfig = {
            background: '#0A0F3A',
            color: '#fff',
            confirmButtonColor: '#00D1FF'
        };

        if (pesan === 'sukses') {
            document.getElementById('robot-loader').style.display = 'none';
            Swal.fire({
                ...swalConfig,
                icon: 'success',
                title: 'AKSES DITERIMA',
                text: 'Welcome back to Control Center.',
                timer: 2500,
                showConfirmButton: false,
                timerProgressBar: true
            }).then(() => {
                window.location.href = "../index.php";
            });
        } else if (pesan === 'gagal') {
            Swal.fire({
                ...swalConfig,
                icon: 'error',
                title: 'Akses Ditolak',
                text: 'Salah Username atau Password!'
            });
        } else if (pesan === 'logout') {
            Swal.fire({
                ...swalConfig,
                icon: 'info',
                title: 'LOGGED OUT',
                text: 'Session Anda Selesai.'
            });
        }

        // Password Visibility Toggle
        const togglePassword = document.querySelector('#togglePassword');
        const passwordInput = document.querySelector('#password');

        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('fa-eye-slash');
        });
    </script>
</body>

</html>