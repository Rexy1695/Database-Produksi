<body>
    <!--! ================================================================ !-->
    <!--! [Start] Navigation Manu !-->
    <!--! ================================================================ !-->
    <nav class="nxl-navigation">
        <div class="navbar-wrapper">
            <div class="m-header">
                <a href="<?= $main_url ?>/index.php" class="d-flex align-items-center" style="text-decoration: none; min-height: 60px;">
                    <div style="width: 42px; height: 42px; background: linear-gradient(135deg, #4e73df 0%, #224abe 100%); border-radius: 12px; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(0,0,0,0.2);">
                        <i class="feather-user" style="color: #ffffff; font-size: 20px;"></i>
                    </div>
                    <div style="margin-left: 12px; display: flex; flex-direction: column; justify-content: center;">
                        <span style="color: #d10fb1; font-weight: 700; font-size: 14px; line-height: 1.2; text-transform: capitalize; display: block; max-width: 140px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                            <?= $_SESSION['nama'] ?? $_SESSION['username'] ?? 'User Aktif'; ?>
                        </span>
                        <span style="color: rgba(214, 17, 139, 0.7); font-weight: 600; font-size: 10px; line-height: 1.5; text-transform: uppercase; letter-spacing: 0.5px; display: flex; align-items: center;">
                            <span style="width: 7px; height: 7px; background: #2ecc71; border-radius: 50%; display: inline-block; margin-right: 6px; box-shadow: 0 0 5px #2ecc71;"></span>
                            Hallo, <?= $_SESSION['role'] ?? 'User' ?>
                        </span>
                    </div>
                </a>
            </div>

            <div class="navbar-content">
                <ul class="nxl-navbar">
                    <li class="nxl-item nxl-caption"><label>Menu Dashboard</label></li>

                    <li class="nxl-item">
                        <a href="<?= $main_url ?>/index.php" class="nxl-link">
                            <span class="nxl-micon"><i class="feather-airplay"></i></span>
                            <span class="nxl-mtext">Dashboards</span>
                        </a>
                    </li>

                    <?php
                    $role = $_SESSION['role'] ?? '';
                    if ($role == 'Admin' || $role == 'Office') :
                    ?>
                        <li class="nxl-item">
                            <a href="<?= $main_url ?>/user/user.php" class="nxl-link">
                                <span class="nxl-micon"><i class="feather-users"></i></span>
                                <span class="nxl-mtext">Users</span>
                            </a>
                        </li>

                        <li class="nxl-item">
                            <a href="<?= $main_url ?>/target/target_bulanan.php" class="nxl-link" id="nav-target">
                                <span class="nxl-micon"><i class="feather-briefcase"></i></span>
                                <span class="nxl-mtext">Monthly Target Area</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if ($role !== 'Visitor') : ?>
                        <li class="nxl-item nxl-hasmenu">
                            <a href="javascript:void(0);" class="nxl-link">
                                <span class="nxl-micon"><i class="feather-cast"></i></span>
                                <span class="nxl-mtext">Reports</span>
                                <span class="nxl-arrow"><i class="feather-chevron-right"></i></span>
                            </a>
                            <ul class="nxl-submenu">
                                <?php if ($role == 'Admin' || $role == 'Office' || $role == 'Km 6') : ?>
                                    <li class="nxl-item"><a class="nxl-link" href="<?= $main_url ?>/produksi/produksi_senyiur.php">WB Km 6</a></li>
                                <?php endif; ?>
                                <?php if ($role == 'Admin' || $role == 'Office' || $role == 'Km 10') : ?>
                                    <li class="nxl-item"><a class="nxl-link" href="<?= $main_url ?>/produksi/produksi_muarapahu.php">WB Km 10</a></li>
                                <?php endif; ?>
                                <!-- <?php if ($role == 'Admin' || $role == 'Office' || $role == 'Km 98') : ?>
                                    <li class="nxl-item"><a class="nxl-link" href="<?= $main_url ?>/produksi/all.php">WB Km 98</a></li>
                                <?php endif; ?> -->
                                <?php if ($role == 'Admin' || $role == 'Office' || $role == 'Office') : ?>
                                    <li class="nxl-item"><a class="nxl-link" href="<?= $main_url ?>/produksi/all.php">All Area</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if ($role !== 'Visitor') : ?>
                        <li class="nxl-item nxl-hasmenu">
                            <a href="javascript:void(0);" class="nxl-link">
                                <span class="nxl-micon">
                                    <i class="feather-truck"></i></span>
                                <span class="nxl-mtext">Driver Retasi</span>
                                <span class="nxl-arrow"><i class="feather-chevron-right"></i></span>
                            </a>
                            <ul class="nxl-submenu">
                                <?php if ($role == 'Admin' || $role == 'Office' || $role == 'Km 6') : ?>
                                    <li class="nxl-item"><a class="nxl-link" href="<?= $main_url ?>/driver_retasi/Km_6_Driver.php">Retasi Km 6</a></li>
                                <?php endif; ?>
                                <li class="nxl-item"><a class="nxl-link" href="<?= $main_url ?>/driver_retasi/database_opt.php">Database Operator</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <li class="nxl-item">
                        <a href="<?= $main_url ?>/otentikasi/logout.php" class="nxl-link">
                            <span class="nxl-micon"><i class="feather-power"></i></span>
                            <span class="nxl-mtext">Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>