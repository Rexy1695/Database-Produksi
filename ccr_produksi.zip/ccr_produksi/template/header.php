<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="keyword" content="" />
    <meta name="author" content="flexilecode" />
    <!--! The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags !-->
    <!--! BEGIN: Apps Title-->
    <title><?= $title ?></title>
    <!--! END:  Apps Title-->
    <!--! BEGIN: Favicon-->
    <link rel="shortcut icon" type="image/x-icon" href="<?= $main_url ?>/assets/images/logo.png" />
    <!--! END: Favicon-->
    <!--! BEGIN: Bootstrap CSS-->
    <link rel="stylesheet" type="text/css" href="<?= $main_url ?>/assets/css/bootstrap.min.css" />
    <!--! END: Bootstrap CSS-->
    <!--! BEGIN: Vendors CSS-->
    <link rel="stylesheet" type="text/css" href="<?= $main_url ?>/assets/vendors/css/vendors.min.css" />
    <link rel="stylesheet" type="text/css" href="<?= $main_url ?>/assets/vendors/css/daterangepicker.min.css" />
    <!--! END: Vendors CSS-->
    <!--! BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?= $main_url ?>/assets/css/theme.min.css" />
    <!--! END: Custom CSS-->
    <!--! HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries !-->
    <!--! WARNING: Respond.js doesn"t work if you view the page via file: !-->
    <!--[if lt IE 9]>
			<script src="https:oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https:oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
    <style>
        /* 1. Mencegah pemotongan pada container utama */
        .table-responsive,
        .card-body,
        .card,
        .main-content {
            overflow: visible !important;
            position: static !important;
            /* Mengizinkan dropdown keluar dari batasan parent */
        }

        /* 2. Memastikan footer selalu di bawah */
        .nxl-container {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .nxl-content {
            flex: 1;
        }

        /* 3. Menghilangkan scrollbar horizontal yang muncul akibat overflow:visible */
        body {
            overflow-x: hidden;
        }
    </style>
</head>