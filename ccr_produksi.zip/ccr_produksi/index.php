<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: otentikasi/login.php");
    exit;
}
require "config.php";
/** @var mysqli $koneksi */
// --- 1. FILTER PERIODE & SATUAN ---
$bulan_pilihan = $_GET['bulan'] ?? date('m');
$tahun_pilihan = $_GET['tahun'] ?? date('Y');
$unit          = $_GET['unit']  ?? 'ton';

$pembagi_prod = ($unit == 'ton') ? 1000 : 1;
$pembagi_target = ($unit == 'ton') ? 1000 : 1;

$jumlah_hari = cal_days_in_month(CAL_GREGORIAN, (int)$bulan_pilihan, (int)$tahun_pilihan);

// --- LOGIKA HITUNG HARI TERUPLOAD ---
$q_count_day = mysqli_query($koneksi, "SELECT COUNT(DISTINCT tanggal) as jml_hari_upload FROM tbl_produksi 
                                       WHERE MONTH(tanggal) = '$bulan_pilihan' AND YEAR(tanggal) = '$tahun_pilihan'");
$row_count = mysqli_fetch_assoc($q_count_day);
$hari_terupload = (int)($row_count['jml_hari_upload'] ?? 0);

$days = [];
$data_all = array_fill(0, $jumlah_hari, 0);
$data_senyiur = array_fill(0, $jumlah_hari, 0);
$data_mp = array_fill(0, $jumlah_hari, 0);
for ($i = 1; $i <= $jumlah_hari; $i++) {
    $days[] = $i;
}

// --- 2. DATA UPDATE ---
$q_last_update = mysqli_query($koneksi, "SELECT MAX(tanggal) as tgl_akhir FROM tbl_produksi");
$row_last = mysqli_fetch_assoc($q_last_update);
$last_update = ($row_last['tgl_akhir']) ? date('d F Y', strtotime($row_last['tgl_akhir'])) : '-';

function cleanToFloat($val)
{
    if (!$val || $val == '0,000') return 0;
    if (strpos($val, ',') !== false) {
        $s = str_replace('.', '', $val);
        $s = str_replace(',', '.', $s);
        return (float)$s;
    }
    return (float)$val;
}

// --- 3. DATA ACTUAL MTD ---
$q_mtd = mysqli_query($koneksi, "SELECT tanggal, lokasi, nett FROM tbl_produksi 
                                 WHERE MONTH(tanggal) = '$bulan_pilihan' AND YEAR(tanggal) = '$tahun_pilihan'");
$mtd_senyiur = 0;
$mtd_mp = 0;
while ($row = mysqli_fetch_assoc($q_mtd)) {
    $tgl_d = (int)date('j', strtotime($row['tanggal']));
    $idx = $tgl_d - 1;
    $nilai_final = cleanToFloat($row['nett']) / $pembagi_prod;

    if ($row['lokasi'] == 'Senyiur') {
        $data_senyiur[$idx] += $nilai_final;
        $mtd_senyiur += $nilai_final;
    } elseif ($row['lokasi'] == 'Muara Pahu') {
        $data_mp[$idx] += $nilai_final;
        $mtd_mp += $nilai_final;
    }
    $data_all[$idx] += $nilai_final;
}
$mtd_total = array_sum($data_all);

// --- 4. DATA TARGET & ACHIEVEMENT ---
$q_target = mysqli_query($koneksi, "SELECT * FROM target_bulanan WHERE bulan = '$bulan_pilihan' AND tahun = '$tahun_pilihan'");
$row_target = mysqli_fetch_assoc($q_target);

$unit_s = (int)($row_target['unit_senyiur'] ?? 0);
$unit_m = (int)($row_target['unit_mp'] ?? 0);

$target_s_bulan = (float)($row_target['senyiur'] ?? 0) / $pembagi_target;
$target_m_bulan = (float)($row_target['muara_pahu'] ?? 0) / $pembagi_target;
$target_total_bulan = $target_s_bulan + $target_m_bulan;

$target_s_aktual = ($target_s_bulan / $jumlah_hari) * $hari_terupload;
$target_m_aktual = ($target_m_bulan / $jumlah_hari) * $hari_terupload;
$target_total_aktual = $target_s_aktual + $target_m_aktual;

$ach_s_akt = ($target_s_aktual > 0) ? ($mtd_senyiur / $target_s_aktual) * 100 : 0;
$ach_s_bln = ($target_s_bulan > 0) ? ($mtd_senyiur / $target_s_bulan) * 100 : 0;
$ach_m_akt = ($target_m_aktual > 0) ? ($mtd_mp / $target_m_aktual) * 100 : 0;
$ach_m_bln = ($target_m_bulan > 0) ? ($mtd_mp / $target_m_bulan) * 100 : 0;

$persentase_aktual  = ($target_total_aktual > 0) ? ($mtd_total / $target_total_aktual) * 100 : 0;
$persentase_bulanan = ($target_total_bulan > 0) ? ($mtd_total / $target_total_bulan) * 100 : 0;
$dev_total_aktual = $mtd_total - $target_total_aktual;

// --- 5. DATA YTD ---
$ytd_total = 0;
$ytd_senyiur = 0;
$ytd_mp = 0;
$q_ytd = mysqli_query($koneksi, "SELECT lokasi, nett FROM tbl_produksi WHERE YEAR(tanggal) = '$tahun_pilihan'");
while ($row = mysqli_fetch_assoc($q_ytd)) {
    $nilai_ytd = cleanToFloat($row['nett']) / $pembagi_prod;
    if ($row['lokasi'] == 'Senyiur') $ytd_senyiur += $nilai_ytd;
    if ($row['lokasi'] == 'Muara Pahu') $ytd_mp += $nilai_ytd;
}
$q_survey_ytd = mysqli_query($koneksi, "SELECT SUM(survey_mp) as tot_mp, SUM(survey_senyiur) as tot_s FROM target_bulanan WHERE tahun = '$tahun_pilihan'");
$row_survey = mysqli_fetch_assoc($q_survey_ytd);
$ytd_senyiur += ((float)($row_survey['tot_s'] ?? 0) / $pembagi_target);
$ytd_mp += ((float)($row_survey['tot_mp'] ?? 0) / $pembagi_target);
$ytd_total = $ytd_senyiur + $ytd_mp;

$list_bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
$title = "Dashboard Produksi - Home";
require "template/header.php";
require "template/sidebar.php";
require "template/navbar.php";
?>

<style>
    :root {
        --grad-blue: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
        --grad-green: linear-gradient(135deg, #064e3b 0%, #10b981 100%);
        --grad-red: linear-gradient(135deg, #7f1d1d 0%, #ef4444 100%);
        --grad-dark: linear-gradient(135deg, #0f172a 0%, #334155 100%);
        --grad-orange: linear-gradient(135deg, #92400e 0%, #f59e0b 100%);
    }

    .card-premium {
        border: none;
        border-radius: 20px;
        transition: all 0.3s;
        overflow: hidden;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
    }

    .stat-label {
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 1px;
        text-transform: uppercase;
        opacity: 0.8;
    }

    .stat-value {
        font-size: 2rem;
        font-weight: 900;
        line-height: 1.1;
    }

    .badge-glass {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(5px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: #fff;
        font-size: 10px;
        font-weight: 700;
        padding: 4px 8px;
        border-radius: 4px;
    }

    .progress-thin {
        height: 6px;
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.1);
    }

    .divider-white {
        border-top: 1px solid rgba(255, 255, 255, 0.1);
    }

    .chart-container {
        background: #fff;
        border-radius: 20px;
        padding: 25px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
        border: 1px solid #f1f5f9;
    }

    #countdown-box {
        background: #fee2e2;
        color: #dc2626;
        padding: 4px 12px;
        border-radius: 50px;
        font-weight: 800;
        font-size: 12px;
        border: 1px solid #fecaca;
    }
</style>

<main class="nxl-container">
    <div class="nxl-content pt-4">
        <div class="container-fluid">

            <div class="row mb-4 align-items-center">
                <div class="col-md-6">
                    <h1 class="fw-black text-dark mb-1">Dashboard Produksi</h1>
                    <div class="d-flex align-items-center gap-2">
                        <span id="countdown-box">REFRESH IN <span id="timer">15:00</span></span>
                        <span class="text-muted small fw-medium">• Last Updated: <?= $last_update ?></span>
                    </div>
                </div>
                <div class="col-md-6 text-md-end">
                    <form method="GET" class="d-inline-flex gap-2 bg-white p-2 rounded-pill shadow-sm border">
                        <select name="bulan" class="form-select form-select-sm border-0 fw-bold" onchange="this.form.submit()">
                            <?php foreach ($list_bulan as $m => $nama): $v = str_pad($m + 1, 2, '0', STR_PAD_LEFT); ?>
                                <option value="<?= $v ?>" <?= ($v == $bulan_pilihan ? 'selected' : '') ?>><?= $nama ?></option>
                            <?php endforeach; ?>
                        </select>
                        <select name="tahun" class="form-select form-select-sm border-0 fw-bold" onchange="this.form.submit()">
                            <?php for ($t = date('Y'); $t >= 2023; $t--): ?>
                                <option value="<?= $t ?>" <?= ($t == $tahun_pilihan ? 'selected' : '') ?>><?= $t ?></option>
                            <?php endfor; ?>
                        </select>
                        <div class="btn-group btn-group-sm">
                            <a href="?bulan=<?= $bulan_pilihan ?>&tahun=<?= $tahun_pilihan ?>&unit=ton" class="btn rounded-pill px-3 <?= $unit == 'ton' ? 'btn-primary' : 'btn-light' ?>">TON</a>
                            <a href="?bulan=<?= $bulan_pilihan ?>&tahun=<?= $tahun_pilihan ?>&unit=kg" class="btn rounded-pill px-3 <?= $unit == 'kg' ? 'btn-primary' : 'btn-light' ?>">KG</a>
                        </div>
                    </form>
                </div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-xl-3 col-md-6">
                    <div class="card card-premium h-100 text-white" style="background: var(--grad-blue);">
                        <div class="card-body p-4">
                            <span class="stat-label d-block mb-2">Aktual MTD (<?= strtoupper($unit) ?>)</span>
                            <div class="stat-value mb-4"><?= number_format($mtd_total, 3, ',', '.') ?></div>
                            <div class="divider-white pt-3 row text-center">
                                <div class="col-6 border-end border-white border-opacity-10">
                                    <small class="d-block opacity-75" style="font-size: 9px;">Senyiur (<?= $unit_s ?> Unit)</small>
                                    <span class="fw-bold"><?= number_format($mtd_senyiur, 3, ',', '.') ?></span>
                                </div>
                                <div class="col-6">
                                    <small class="d-block opacity-75" style="font-size: 9px;">M. Pahu (<?= $unit_m ?> Unit)</small>
                                    <span class="fw-bold"><?= number_format($mtd_mp, 3, ',', '.') ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6">
                    <div class="card card-premium h-100 text-white" style="background: var(--grad-green);">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <span class="stat-label">Target Aktual (<?= $hari_terupload ?> Hari)</span>
                                <div class="d-flex flex-column align-items-end gap-1">
                                    <span class="badge-glass">MTD: <?= number_format($persentase_aktual, 1, ',', '.') ?>%</span>
                                    <span class="badge-glass">Monthly: <?= number_format($persentase_bulanan, 1, ',', '.') ?>%</span>
                                </div>
                            </div>
                            <div class="stat-value"><?= number_format($target_total_aktual, 3, ',', '.') ?></div>
                            <small class="d-block mb-3 opacity-75">Target Bulanan: <?= number_format($target_total_bulan, 3, ',', '.') ?></small>
                            <div class="mt-2">
                                <div class="d-flex justify-content-between fw-bold" style="font-size: 11px; margin-bottom: 2px;">
                                    <span>SENYIUR</span>
                                    <span>
                                        <span class="opacity-75">Monthly: <?= number_format($ach_s_bln, 1, ',', '.') ?>%</span> |
                                        <span>MTD: <?= number_format($ach_s_akt, 1, ',', '.') ?>%</span>
                                    </span>
                                </div>
                                <div class="progress progress-thin mb-1">
                                    <div class="progress-bar bg-white" style="width:<?= min($ach_s_akt, 100) ?>%"></div>
                                </div>
                                <div class="text-end opacity-75 mb-2" style="font-size: 9px;">Target: <?= number_format($target_s_bulan, 3, ',', '.') ?></div>
                                <div class="d-flex justify-content-between fw-bold" style="font-size: 11px; margin-bottom: 2px;">
                                    <span>M. PAHU</span>
                                    <span>
                                        <span class="opacity-75">Monthly: <?= number_format($ach_m_bln, 1, ',', '.') ?>%</span> |
                                        <span>MTD: <?= number_format($ach_m_akt, 1, ',', '.') ?>%</span>
                                    </span>
                                </div>
                                <div class="progress progress-thin mb-1">
                                    <div class="progress-bar bg-white" style="width:<?= min($ach_m_akt, 100) ?>%"></div>
                                </div>
                                <div class="text-end opacity-75" style="font-size: 9px;">Target: <?= number_format($target_m_bulan, 3, ',', '.') ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6">
                    <div class="card card-premium h-100 text-white" style="background: <?= $dev_total_aktual < 0 ? 'var(--grad-red)' : 'var(--grad-orange)' ?>;">
                        <div class="card-body p-4">
                            <span class="stat-label d-block mb-2">Deviasi Aktual</span>
                            <div class="stat-value mb-1"><?= number_format($dev_total_aktual, 3, ',', '.') ?></div>
                            <span class="badge badge-glass mb-4">Status: <?= $dev_total_aktual < 0 ? 'Kurang' : 'Lebih' ?></span>
                            <div class="divider-white pt-3 row text-center">
                                <div class="col-6 border-end border-white border-opacity-10">
                                    <small class="d-block opacity-75" style="font-size: 9px;">Dev Senyiur</small>
                                    <span class="fw-bold"><?= number_format($mtd_senyiur - $target_s_aktual, 3, ',', '.') ?></span>
                                </div>
                                <div class="col-6">
                                    <small class="d-block opacity-75" style="font-size: 9px;">Dev M. Pahu</small>
                                    <span class="fw-bold"><?= number_format($mtd_mp - $target_m_aktual, 3, ',', '.') ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6">
                    <div class="card card-premium h-100 text-white" style="background: var(--grad-dark);">
                        <div class="card-body p-4">
                            <span class="stat-label d-block mb-2 opacity-70">Accumulated YTD (<?= $tahun_pilihan ?>)</span>
                            <div class="stat-value mb-4"><?= number_format($ytd_total, 3, ',', '.') ?></div>
                            <div class="divider-white pt-3 row text-center">
                                <div class="col-6 border-end border-white border-opacity-10">
                                    <small class="d-block opacity-75" style="font-size: 9px;">Senyiur</small>
                                    <span class="fw-bold small"><?= number_format($ytd_senyiur, 3, ',', '.') ?></span>
                                </div>
                                <div class="col-6">
                                    <small class="d-block opacity-75" style="font-size: 9px;">M. Pahu</small>
                                    <span class="fw-bold small"><?= number_format($ytd_mp, 3, ',', '.') ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="chart-container">
                        <h5 class="fw-black mb-4">Produksi Harian</h5>
                        <div id="chartHarian" style="min-height: 400px;"></div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // --- TIMER REFRESH ---
        let totalSeconds = 15 * 60;
        const timerDisplay = document.getElementById('timer');
        const countdown = setInterval(() => {
            let min = Math.floor(totalSeconds / 60);
            let sec = totalSeconds % 60;
            timerDisplay.textContent = (min < 10 ? "0" + min : min) + ":" + (sec < 10 ? "0" + sec : sec);
            if (totalSeconds <= 0) {
                clearInterval(countdown);
                window.location.reload();
            }
            totalSeconds--;
        }, 1000);

        // --- CHART HARIAN ---
        const formatIndo = (v) => parseFloat(v).toLocaleString('id-ID', {
            minimumFractionDigits: 3
        });
        new ApexCharts(document.querySelector("#chartHarian"), {
            series: [{
                    name: 'Total Production',
                    type: 'area',
                    data: <?= json_encode(array_values($data_all)); ?>
                },
                {
                    name: 'Senyiur',
                    type: 'line',
                    data: <?= json_encode(array_values($data_senyiur)); ?>
                },
                {
                    name: 'Muara Pahu',
                    type: 'line',
                    data: <?= json_encode(array_values($data_mp)); ?>
                }
            ],
            chart: {
                height: 400,
                type: 'line',
                toolbar: {
                    show: false
                }
            },
            stroke: {
                width: [0, 4, 4],
                curve: 'smooth'
            },
            fill: {
                type: ['gradient', 'solid', 'solid']
            },
            colors: ['#3b82f6', '#10b981', '#f59e0b'],
            labels: <?= json_encode($days); ?>,
            xaxis: {
                labels: {
                    style: {
                        colors: '#64748b',
                        fontWeight: 600
                    }
                }
            },
            yaxis: {
                labels: {
                    formatter: (v) => v.toLocaleString('id-ID')
                }
            },
            tooltip: {
                theme: 'dark',
                shared: true,
                y: {
                    formatter: (v) => formatIndo(v) + " <?= strtoupper($unit) ?>"
                }
            }
        }).render();
    });
</script>

<?php require "template/footer.php"; ?>