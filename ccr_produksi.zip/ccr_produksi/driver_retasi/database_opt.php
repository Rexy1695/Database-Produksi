<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: ../auth/login.php");
    exit;
}
require "../config.php";
/** @var mysqli $koneksi */


$title = "Dashboard Produksi - All Area";
require "../template/header.php";
require "../template/sidebar.php";
require "../template/navbar.php";
?>


<?php
require "../template/footer.php";

?>
