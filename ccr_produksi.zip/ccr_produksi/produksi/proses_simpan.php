<?php
require "../config.php";
/** @var mysqli $koneksi */
$data = json_decode(file_get_contents('php://input'), true);

if ($data) {
    $tgl = $data['tanggal'];
    foreach ($data['payload'] as $row) {
        $id = $row['id'];
        $sft = $row['sft'];
        $unt = $row['unt'];
        $vsl = $row['vsl'];
        $lp = $row['lp'];
        $typ = $row['typ'];
        $wb = $row['wb'];
        $trs = $row['trs'];
        $grs = $row['grs'];
        $tar = $row['tar'];
        $net = $row['net'];
        $tin = $row['tin'];
        $tout = $row['tout'];
        $tip = $row['tip'];
        $rem = $row['rem'];
        $lok = $row['lok'];

        if ($id) {
            mysqli_query($koneksi, "UPDATE tbl_produksi SET shift='$sft', no_unit='$unt', type_vessel='$vsl', loading_point='$lp', material_type='$typ', weighbridge='$wb', no_transaction='$trs', gross='$grs', tare='$tar', nett='$net', time_in='$tin', time_out='$tout', tipping='$tip', remarks='$rem' WHERE id_produksi=$id");
        } else {
            mysqli_query($koneksi, "INSERT INTO tbl_produksi (tanggal, shift, no_unit, type_vessel, loading_point, material_type, weighbridge, no_transaction, gross, tare, nett, time_in, time_out, tipping, remarks, lokasi) VALUES ('$tgl', '$sft', '$unt', '$vsl', '$lp', '$typ', '$wb', '$trs', '$grs', '$tar', '$net', '$tin', '$tout', '$tip', '$rem', '$lok')");
        }
    }
    echo json_encode(['status' => 'ok']);
}
