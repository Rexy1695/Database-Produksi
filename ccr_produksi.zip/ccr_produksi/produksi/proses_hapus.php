<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */
// Set header agar output selalu berupa JSON
header('Content-Type: application/json');

// 1. KEAMANAN: Cek apakah user sudah login
if (!isset($_SESSION['login'])) {
    echo json_encode(['status' => 'error', 'message' => 'Sesi berakhir, silakan login ulang']);
    exit;
}

// 2. AMBIL PARAMETER: Menentukan aksi apa yang dijalankan
$action = $_GET['action'] ?? '';

// 3. LOGIKA UTAMA: Pastikan hanya menerima request POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // --- CASE A: HAPUS SATU BARIS (delete_one) ---
    // Digunakan saat menekan tombol [X] di tabel
    if ($action === 'delete_one') {
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            $id = mysqli_real_escape_string($koneksi, $_POST['id']);
            $query = "DELETE FROM tbl_produksi WHERE id_produksi = '$id'";

            if (mysqli_query($koneksi, $query)) {
                echo json_encode(['status' => 'ok']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Gagal hapus database: ' . mysqli_error($koneksi)]);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'ID data tidak ditemukan']);
        }
    }

    // --- CASE B: HAPUS SEMUA DATA PER LOKASI (delete_all_lokasi) ---
    // Digunakan di halaman khusus (Senyiur / Muara Pahu)
    else if ($action === 'delete_all_lokasi') {
        if (isset($_POST['tanggal']) && isset($_POST['lokasi'])) {
            $tanggal = mysqli_real_escape_string($koneksi, $_POST['tanggal']);
            $lokasi = mysqli_real_escape_string($koneksi, $_POST['lokasi']);

            // Hapus data hanya pada tanggal dan lokasi yang spesifik
            $query = "DELETE FROM tbl_produksi WHERE tanggal = '$tanggal' AND lokasi = '$lokasi'";

            if (mysqli_query($koneksi, $query)) {
                echo json_encode(['status' => 'ok']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Gagal hapus area: ' . mysqli_error($koneksi)]);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Parameter tanggal atau lokasi kurang']);
        }
    }

    // --- CASE C: HAPUS SEMUA TANPA FILTER LOKASI (delete_all) ---
    // Digunakan di halaman All Area (Hapus total satu tanggal)
    else if ($action === 'delete_all') {
        if (isset($_POST['tanggal'])) {
            $tanggal = mysqli_real_escape_string($koneksi, $_POST['tanggal']);
            $query = "DELETE FROM tbl_produksi WHERE tanggal = '$tanggal'";

            if (mysqli_query($koneksi, $query)) {
                echo json_encode(['status' => 'ok']);
            } else {
                echo json_encode(['status' => 'error', 'message' => mysqli_error($koneksi)]);
            }
        }
    }

    // JIKA ACTION TIDAK SESUAI
    else {
        echo json_encode(['status' => 'error', 'message' => 'Aksi hapus tidak dikenal']);
    }
} else {
    // JIKA DI AKSES TANPA POST
    echo json_encode(['status' => 'error', 'message' => 'Metode akses ditolak']);
}
