<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: ../auth/login.php");
    exit;
}
require "../config.php";
/** @var mysqli $koneksi */
$tgl_filter = $_GET['tgl'] ?? date('Y-m-d');
// Filter project dikunci ke 'Senyiur'
$prj_filter = 'Senyiur'; 

$where = "WHERE tanggal = '$tgl_filter' AND lokasi = '$prj_filter'";

$query_data = mysqli_query($koneksi, "SELECT * FROM tbl_produksi $where ORDER BY lokasi ASC, id_produksi ASC");
$existing_data = [];
$total_day_kg = 0;

while ($row = mysqli_fetch_assoc($query_data)) {
    $existing_data[] = $row;
    $total_day_kg += (float)$row['nett'];
}

$title = "Dashboard Produksi - Lokasi Senyiur";
require "../template/header.php";
require "../template/sidebar.php";
require "../template/navbar.php";
?>

<style>
    .excel-wrapper {
        background: #fff;
        border: 1px solid #dee2e6;
        border-radius: 4px;
        display: flex;
        flex-direction: column;
        margin-bottom: 20px;
    }

    .header-tool {
        background: #2c3e50;
        color: white;
        padding: 12px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-radius: 4px 4px 0 0;
    }

    .table-scroll-area {
        max-height: 70vh;
        overflow: auto;
        background: #f8f9fa;
    }

    .table-excel {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
    }

    .table-excel thead th {
        position: sticky;
        top: 0;
        z-index: 100;
        background: #005f73 !important;
        color: white !important;
        font-size: 10px;
        border: 1px solid #ddd;
        padding: 8px;
        text-align: center;
    }

    .table-excel td {
        border: 1px solid #ddd;
        padding: 0 !important;
        height: 32px;
    }

    .table-excel input {
        border: none;
        width: 100%;
        height: 100%;
        padding: 0 5px;
        font-size: 11px;
        outline: none;
        background: transparent;
    }

    .table-excel input:focus {
        background: #fff9c4;
        box-shadow: inset 0 0 0 2px #005f73;
    }

    .bg-unit {
        background: #fce4ec !important;
    }

    .bg-lokasi {
        background: #e9f5db !important;
    }

    .text-end-input {
        text-align: right !important;
    }

    .btn-del {
        color: #dc3545;
        font-weight: bold;
        border: none;
        background: transparent;
        cursor: pointer;
        width: 100%;
        height: 100%;
        font-size: 16px;
    }
</style>

<main class="nxl-container">
    <div class="nxl-content pt-3">
        <div class="container-fluid">
            <div class="excel-wrapper shadow-sm">
                <div class="header-tool">
                    <div><i class="feather-database me-2"></i><b>PRODUCTION - SENYIUR AREA</b></div>
                    <div class="d-flex align-items-center gap-3">
                        <div class="text-end me-2">
                            <small class="d-block opacity-75" style="font-size: 10px;">TOTAL NETT (KG)</small>
                            <span class="fs-5 fw-bold" id="grandTotal"><?= number_format($total_day_kg, 3, ',', '.') ?></span>
                        </div>
                        <button class="btn btn-danger btn-sm fw-bold" onclick="deleteAllData()">
                            <i class="feather-trash-2 me-1"></i> HAPUS SEMUA
                        </button>
                        <button class="btn btn-success btn-sm fw-bold px-4" id="btnSimpan" onclick="submitData()">
                            <i class="feather-save me-1"></i> SIMPAN DATA
                        </button>
                    </div>
                </div>

                <div class="p-2 bg-light border-bottom d-flex gap-2">
                    <input type="date" class="form-control form-control-sm" style="width:150px" value="<?= $tgl_filter ?>" onchange="location.href='?tgl='+this.value">
                    <input type="text" id="smartSearch" class="form-control form-control-sm" placeholder="Cari data...">
                </div>

                <div class="table-scroll-area">
                    <table class="table-excel" id="excelTable">
                        <thead>
                            <tr>
                                <th style="width: 35px;">#</th>
                                <th style="width: 50px;">SHIFT</th>
                                <th style="width: 80px;">NO UNIT</th>
                                <th style="width: 120px;">TYPE VESSEL</th>
                                <th style="width: 150px;">LOADING POINT</th>
                                <th style="width: 100px;">TYPE</th>
                                <th style="width: 100px;">WEIGHBRIDGE</th>
                                <th style="width: 130px;">NO TRANSACTION</th>
                                <th style="width: 90px;">GROSS</th>
                                <th style="width: 90px;">TARE</th>
                                <th style="width: 90px;">NETT</th>
                                <th style="width: 65px;">TIME IN</th>
                                <th style="width: 65px;">TIME OUT</th>
                                <th style="width: 80px;">TIPPING</th>
                                <th style="width: 140px;">REMARKS</th>
                                <th style="width: 110px;">LOKASI</th>
                                <th style="width: 40px;">DEL</th>
                            </tr>
                        </thead>
                        <tbody id="tableBody"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    const formatIndo = (v) => {
        let n = parseFloat(v);
        return isNaN(n) ? "0,000" : n.toLocaleString('id-ID', {
            minimumFractionDigits: 3,
            maximumFractionDigits: 3
        });
    };

    const cleanNum = (s) => {
        if (!s) return 0;
        let cleaned = s.toString().replace(/\./g, '').replace(',', '.');
        return parseFloat(cleaned) || 0;
    };

    let masterData = <?= json_encode($existing_data) ?>.map(d => ({
        id: d.id_produksi,
        sft: d.shift || '',
        unt: d.no_unit || '',
        vsl: d.type_vessel || '',
        lp: d.loading_point || '',
        typ: d.material_type || '',
        wb: d.weighbridge || '',
        trs: d.no_transaction || '',
        grs: formatIndo(d.gross),
        tar: formatIndo(d.tare),
        net: formatIndo(d.nett),
        tin: d.time_in || '',
        tout: d.time_out || '',
        tip: d.tipping || '',
        rem: d.remarks || '',
        lok: d.lokasi || ''
    }));

    if (masterData.length < 50) {
        for (let i = 0; i < 50; i++) masterData.push({
            id: null,
            sft: '',
            unt: '',
            vsl: '',
            lp: '',
            typ: '',
            wb: '',
            trs: '',
            grs: '0,000',
            tar: '0,000',
            net: '0,000',
            tin: '',
            tout: '',
            tip: '',
            rem: '',
            lok: 'Senyiur' // Default lokasi otomatis terisi Senyiur
        });
    }

    function render() {
        const kw = document.getElementById('smartSearch').value.toLowerCase();
        const tbody = document.getElementById('tableBody');
        let html = '';
        let totalNettOnly = 0;

        masterData.forEach((d, i) => {
            if (kw && !Object.values(d).join(" ").toLowerCase().includes(kw)) return;
            totalNettOnly += cleanNum(d.net);

            html += `
                <tr>
                    <td style="background:#f3f3f3; text-align:center; font-size:10px;">${i+1}</td>
                    <td><input type="text" value="${d.sft}" onchange="upd(${i},'sft',this.value)"></td>
                    <td class="bg-unit"><input type="text" class="text-danger fw-bold" value="${d.unt}" onchange="upd(${i},'unt',this.value)"></td>
                    <td><input type="text" value="${d.vsl}" onchange="upd(${i},'vsl',this.value)"></td>
                    <td><input type="text" value="${d.lp}" onchange="upd(${i},'lp',this.value)"></td>
                    <td><input type="text" value="${d.typ}" onchange="upd(${i},'typ',this.value)"></td>
                    <td><input type="text" value="${d.wb}" onchange="upd(${i},'wb',this.value)"></td>
                    <td><input type="text" value="${d.trs}" onchange="upd(${i},'trs',this.value)"></td>
                    <td><input type="text" class="text-end-input" value="${d.grs}" onchange="upd(${i},'grs',this.value)"></td>
                    <td><input type="text" class="text-end-input" value="${d.tar}" onchange="upd(${i},'tar',this.value)"></td>
                    <td style="background:#eee"><input type="text" class="text-end-input fw-bold" value="${d.net}" onchange="upd(${i},'net',this.value)"></td>
                    <td><input type="text" value="${d.tin}" onchange="upd(${i},'tin',this.value)"></td>
                    <td><input type="text" value="${d.tout}" onchange="upd(${i},'tout',this.value)"></td>
                    <td><input type="text" value="${d.tip}" onchange="upd(${i},'tip',this.value)"></td>
                    <td><input type="text" value="${d.rem}" onchange="upd(${i},'rem',this.value)"></td>
                    <td class="bg-lokasi"><input type="text" value="${d.lok}" onchange="upd(${i},'lok',this.value)" readonly></td>
                    <td><button class="btn-del" onclick="deleteRow(${i})">&times;</button></td>
                </tr>`;
        });
        tbody.innerHTML = html;
        document.getElementById('grandTotal').innerText = formatIndo(totalNettOnly);
    }

    function upd(i, k, v) {
        if (k === 'grs' || k === 'tar') {
            masterData[i][k] = formatIndo(cleanNum(v));
            let g = cleanNum(masterData[i].grs);
            let t = cleanNum(masterData[i].tar);
            if (g > 0) masterData[i].net = formatIndo(g - t);
        } else if (k === 'net') {
            masterData[i][k] = formatIndo(cleanNum(v));
        } else {
            masterData[i][k] = v;
        }
        render();
    }

    document.getElementById('excelTable').addEventListener('paste', function(e) {
        e.preventDefault();
        const text = (e.clipboardData || window.clipboardData).getData('Text');
        const rows = text.split(/\r\n|\n|\r/);
        const activeInput = document.activeElement;
        if (activeInput.tagName !== 'INPUT') return;

        const td = activeInput.closest('td');
        const tr = td.closest('tr');
        const startRow = Array.from(tr.parentNode.children).indexOf(tr);
        const startCol = Array.from(tr.children).indexOf(td);
        const fields = ['sft', 'unt', 'vsl', 'lp', 'typ', 'wb', 'trs', 'grs', 'tar', 'net', 'tin', 'tout', 'tip', 'rem', 'lok'];

        rows.forEach((rowContent, rOffset) => {
            if (!rowContent.trim()) return;
            const cols = rowContent.split('\t');
            const targetIdx = startRow + rOffset;
            if (!masterData[targetIdx]) {
                masterData.push({
                    id: null,
                    sft: '',
                    unt: '',
                    vsl: '',
                    lp: '',
                    typ: '',
                    wb: '',
                    trs: '',
                    grs: '0,000',
                    tar: '0,000',
                    net: '0,000',
                    tin: '',
                    tout: '',
                    tip: '',
                    rem: '',
                    lok: 'Senyiur'
                });
            }
            cols.forEach((val, cOffset) => {
                const fieldIdx = (startCol - 1) + cOffset;
                const fName = fields[fieldIdx];
                if (fName) {
                    if (['grs', 'tar', 'net'].includes(fName)) {
                        masterData[targetIdx][fName] = formatIndo(cleanNum(val));
                    } else if (fName === 'lok') {
                        masterData[targetIdx][fName] = 'Senyiur'; // Paksa lokasi tetap Senyiur saat paste
                    } else {
                        masterData[targetIdx][fName] = val.trim();
                    }
                }
            });
            let g = cleanNum(masterData[targetIdx].grs);
            let t = cleanNum(masterData[targetIdx].tar);
            if (g > 0) masterData[targetIdx].net = formatIndo(g - t);
        });
        render();
    });

    function submitData() {
        const btn = document.getElementById('btnSimpan');
        btn.disabled = true;
        btn.innerText = "Memproses...";
        const payload = masterData.filter(d => d.unt !== '' || cleanNum(d.net) > 0).map(d => ({
            ...d,
            lok: 'Senyiur', // Pastikan data yang dikirim ke DB adalah Senyiur
            grs: cleanNum(d.grs),
            tar: cleanNum(d.tar),
            net: cleanNum(d.net)
        }));
        fetch('proses_simpan.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    tanggal: '<?= $tgl_filter ?>',
                    payload: payload
                })
            })
            .then(r => r.json())
            .then(res => {
                if (res.status === 'ok') Swal.fire('Berhasil', payload.length + ' data disimpan', 'success').then(() => location.reload());
            })
            .catch(() => {
                btn.disabled = false;
                btn.innerText = "SIMPAN DATA";
                Swal.fire('Error', 'Gagal mengirim data.', 'error');
            });
    }

    function deleteRow(i) {
        if (confirm('Hapus baris ini?')) {
            if (masterData[i].id) {
                const fd = new FormData();
                fd.append('id', masterData[i].id);
                fetch('proses_hapus.php?action=delete_one', {
                    method: 'POST',
                    body: fd
                }).then(() => {
                    masterData.splice(i, 1);
                    render();
                });
            } else {
                masterData.splice(i, 1);
                render();
            }
        }
    }

    function deleteAllData() {
        Swal.fire({
            title: 'Hapus Semua Data Senyiur?',
            text: "Semua data Senyiur pada tanggal <?= $tgl_filter ?> akan dihapus permanen!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc3545',
            confirmButtonText: 'Ya, Hapus Semua!'
        }).then((result) => {
            if (result.isConfirmed) {
                const fd = new FormData();
                fd.append('tanggal', '<?= $tgl_filter ?>');
                fd.append('lokasi', 'Senyiur'); // Tambahan parameter lokasi untuk keamanan hapus
                fetch('proses_hapus.php?action=delete_all', {
                        method: 'POST',
                        body: fd
                    })
                    .then(r => r.json())
                    .then(res => {
                        if (res.status === 'ok') {
                            Swal.fire('Terhapus!', 'Semua data Senyiur telah dibersihkan.', 'success').then(() => location.reload());
                        }
                    });
            }
        });
    }

    document.getElementById('smartSearch').addEventListener('input', render);
    render();
</script>