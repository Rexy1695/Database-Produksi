<?php
session_start();

// Jika session 'login' tidak ada atau salah, tendang paksa ke login.php
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: ../auth/login.php"); // Sesuaikan path ke file login Anda
    exit;
}
/** @var mysqli $koneksi */
require "../config.php";
$title = "CCR - Edit User";
require "../template/header.php";
require "../template/sidebar.php";
require "../template/navbar.php";

// Ambil ID dari URL
$id = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE id_user = '$id'");
$data = mysqli_fetch_array($query);

// Jika data tidak ditemukan
if (!$data) {
    header("Location: index.php");
    exit();
}
?>

<main class="nxl-container">
    <div class="nxl-content">
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title"><h5 class="m-b-10">Edit User</h5></div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="user.php">Data User</a></li>
                    <li class="breadcrumb-item">Edit</li>
                </ul>
            </div>
        </div>

        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <form action="proses-edit-user.php" method="POST">
                        <input type="hidden" name="id_user" value="<?= $data['id_user'] ?>">
                        
                        <div class="card">
                            <div class="card-body">
                                <div class="row mb-4">
                                    <div class="col-lg-4"><label class="fw-semibold">Username</label></div>
                                    <div class="col-lg-8">
                                        <input type="text" class="form-control" name="username" value="<?= $data['username'] ?>" required>
                                    </div>
                                </div>

                                <div class="row mb-4">
                                    <div class="col-lg-4"><label class="fw-semibold">Role</label></div>
                                    <div class="col-lg-8">
                                        <select class="form-control" name="role" required>
                                            <?php $r = $data['role']; ?>
                                            <option value="Admin" <?= $r == 'Admin' ? 'selected' : '' ?>>Admin</option>
                                            <option value="Km 10" <?= $r == 'Km 10' ? 'selected' : '' ?>>Km 10</option>
                                            <option value="Km 6" <?= $r == 'Km 6' ? 'selected' : '' ?>>Km 6</option>
                                            <option value="Km 98" <?= $r == 'Km 98' ? 'selected' : '' ?>>Km 98</option>
                                            <option value="Office" <?= $r == 'Office' ? 'selected' : '' ?>>Office</option>
                                            <option value="Visitor" <?= $r == 'Visitor' ? 'selected' : '' ?>>Visitor</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row mb-4">
                                    <div class="col-lg-4">
                                        <label class="fw-semibold">Password Baru</label>
                                        <small class="d-block text-muted text-info">*Kosongkan jika tidak ingin ganti password</small>
                                    </div>
                                    <div class="col-lg-8">
                                        <input type="password" class="form-control" name="password" placeholder="Masukkan password baru">
                                    </div>
                                </div>

                                <div class="text-end">
                                    <a href="user.php" class="btn btn-light-brand">Batal</a>
                                    <button type="submit" name="update" class="btn btn-primary">Update User</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<?php require "../template/footer.php"; ?>