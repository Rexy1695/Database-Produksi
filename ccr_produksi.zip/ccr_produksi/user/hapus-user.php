<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus data berdasarkan ID
    $query = mysqli_query($koneksi, "DELETE FROM tbl_user WHERE id_user = '$id'");

    if ($query) {
        header("Location: user.php?status=deleted");
    } else {
        header("Location: user.php?status=error");
    }
} else {
    header("Location: index.php");
}
?>