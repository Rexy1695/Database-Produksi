<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */
if (isset($_POST['update'])) {
    $id       = $_POST['id_user'];
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $role     = mysqli_real_escape_string($koneksi, $_POST['role']);
    $password = $_POST['password'];

    // Jika ganti password
    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $query = "UPDATE tbl_user SET username='$username', role='$role', password='$hashed_password' WHERE id_user='$id'";
    } else {
        // Jika password tidak diisi, update username & role saja
        $query = "UPDATE tbl_user SET username='$username', role='$role' WHERE id_user='$id'";
    }

    if (mysqli_query($koneksi, $query)) {
        header("Location: user.php?status=updated");
    } else {
        header("Location: user.php?status=error");
    }
}
?>