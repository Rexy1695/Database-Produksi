<?php
session_start();

// Jika session 'login' tidak ada atau salah, tendang paksa ke login.php
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: ../auth/login.php"); // Sesuaikan path ke file login Anda
    exit;
}
require "../config.php";
/** @var mysqli $koneksi */
$title = "CCR - Data User";
require "../template/header.php";
require "../template/sidebar.php";
require "../template/navbar.php";

// Ambil data dari database
$query = mysqli_query($koneksi, "SELECT * FROM tbl_user ORDER BY id_user DESC");
?>

<main class="nxl-container">
    <div class="nxl-content">
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10">User</h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="user.php">Data User</a></li>
                    <li class="breadcrumb-item">User</li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <a href="tambah_user.php" class="btn btn-primary">
                            <i class="feather-plus me-2"></i>
                            <span>Tambah User</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card stretch stretch-full">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover" id="leadList">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Username</th>
                                            <th>Role</th>
                                            <th class="text-end">Tindakan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no = 1;
                                        while ($data = mysqli_fetch_array($query)) :
                                        ?>
                                            <tr class="single-item">
                                                <td><?= $no++; ?></td>
                                                <td>
                                                    <span class="text-truncate-1-line"><?= htmlspecialchars($data['username']); ?></span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-soft-primary text-primary"><?= $data['role']; ?></span>
                                                </td>
                                                <td>
                                                    <div class="hstack gap-2 justify-content-end">
                                                        <div class="dropdown">
                                                            <a href="javascript:void(0)" class="avatar-text avatar-md" data-bs-toggle="dropdown" data-bs-boundary="viewport">
                                                                <i class="feather feather-more-horizontal"></i>
                                                            </a>
                                                            <ul class="dropdown-menu dropdown-menu-end shadow-lg">
                                                                <li>
                                                                    <a class="dropdown-item" href="edit-user.php?id=<?= $data['id_user']; ?>">
                                                                        <i class="feather feather-edit-3 me-3"></i>
                                                                        <span>Edit</span>
                                                                    </a>
                                                                </li>
                                                                <li class="dropdown-divider"></li>
                                                                <li>
                                                                    <a class="dropdown-item text-danger" href="hapus-user.php?id=<?= $data['id_user']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus user ini?')">
                                                                        <i class="feather feather-trash-2 me-3"></i>
                                                                        <span>Delete</span>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>

                                        <?php if (mysqli_num_rows($query) == 0) : ?>
                                            <tr>
                                                <td colspan="4" class="text-center p-5 text-muted">Belum ada data user.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    const urlParams = new URLSearchParams(window.location.search);
    const status = urlParams.get('status');

    if (status === 'success') {
        Swal.fire('Berhasil!', 'User ditambahkan.', 'success');
    } else if (status === 'updated') {
        Swal.fire('Berhasil!', 'Data user diperbarui.', 'success');
    } else if (status === 'deleted') {
        Swal.fire('Terhapus!', 'User telah dihapus.', 'success');
    } else if (status === 'error') {
        Swal.fire('Gagal!', 'Terjadi kesalahan sistem.', 'error');
    }
</script>

<?php require "../template/footer.php"; ?>