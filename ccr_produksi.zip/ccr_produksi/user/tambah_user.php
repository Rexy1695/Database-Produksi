<?php
session_start();

// Jika session 'login' tidak ada atau salah, tendang paksa ke login.php
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: otentikasi/login.php"); // Sesuaikan path ke file login Anda
    exit;
}
require "../config.php";
/** @var mysqli $koneksi */
$title = "CCR - Tambah User";
require "../template/header.php";
require "../template/sidebar.php";
require "../template/navbar.php";

// Logika untuk menangkap pesan dari URL (untuk alert)
$status = isset($_GET['status']) ? $_GET['status'] : '';
?>

<main class="nxl-container">
    <div class="nxl-content">
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10">User</h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="user.php">Data User</a></li>
                    <li class="breadcrumb-item">Tambah User</li>
                </ul>
            </div>
        </div>

        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <form action="proses-user.php" method="POST">
                        <div class="card border-top-0">
                            <div class="card-header p-0">
                                <ul class="nav nav-tabs flex-wrap w-100 text-center customers-nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item flex-fill border-top" role="presentation">
                                        <a href="javascript:void(0);" class="nav-link active" data-bs-toggle="tab" data-bs-target="#profileTab" role="tab">Profile</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="tab-content">
                                <div class="tab-pane fade show active" id="profileTab" role="tabpanel">
                                    <div class="card-body personal-info">
                                        <div class="mb-4 d-flex align-items-center justify-content-between">
                                            <h5 class="fw-bold mb-0 me-4">
                                                <span class="d-block mb-2">Tambahkan User</span>
                                            </h5>
                                        </div>

                                        <div class="row mb-4 align-items-center">
                                            <div class="col-lg-4">
                                                <label for="username" class="fw-semibold">Username</label>
                                            </div>
                                            <div class="col-lg-8">
                                                <div class="input-group">
                                                    <div class="input-group-text"><i class="feather-user"></i></div>
                                                    <input type="text" class="form-control" name="username" id="username" placeholder="Username" required>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mb-4 align-items-center">
                                            <div class="col-lg-4">
                                                <label class="fw-semibold">Role</label>
                                            </div>
                                            <div class="col-lg-8">
                                                <select class="form-control" name="role" required>
                                                    <option value="">--Pilih Role--</option>
                                                    <option value="Admin">Admin</option>
                                                    <option value="Km 10">Km 10</option>
                                                    <option value="Km 6">Km 6</option>
                                                    <option value="Km 98">Km 98</option>
                                                    <option value="Office">Office</option>
                                                    <option value="Visitor">Visitor</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row mb-4 align-items-center">
                                            <div class="col-lg-4">
                                                <label for="password" class="fw-semibold">Password: </label>
                                            </div>
                                            <div class="col-lg-8">
                                                <div class="input-group">
                                                    <div class="input-group-text"><i class="feather-key"></i></div>
                                                    <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mb-4 align-items-center">
                                            <div class="col-lg-4">
                                                <label for="confirm_password" class="fw-semibold">Password Confirm: </label>
                                            </div>
                                            <div class="col-lg-8">
                                                <div class="input-group">
                                                    <div class="input-group-text"><i class="feather-key"></i></div>
                                                    <input type="password" class="form-control" name="confirm_password" id="confirm_password" placeholder="Password Confirm" required>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mt-5">
                                            <div class="col-lg-12 text-end">
                                                <button type="submit" name="simpan" class="btn btn-primary">Simpan Data</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<?php require "../template/footer.php"; ?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    const urlParams = new URLSearchParams(window.location.search);
    const status = urlParams.get('status');

    if (status === 'success') {
        Swal.fire('Berhasil!', 'User baru telah ditambahkan.', 'success');
    } else if (status === 'wrong_password') {
        Swal.fire('Gagal!', 'Konfirmasi password tidak cocok.', 'error');
    } else if (status === 'error') {
        Swal.fire('Gagal!', 'Terjadi kesalahan sistem.', 'error');
    } else if (status === 'exists') {
        Swal.fire('Gagal!', 'Username sudah terdaftar.', 'warning');
    }
</script>