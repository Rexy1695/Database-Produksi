<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */
if (isset($_POST['simpan'])) {
    // Ambil data dari form dan bersihkan (mencegah SQL Injection)
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $role     = mysqli_real_escape_string($koneksi, $_POST['role']);
    $password = $_POST['password'];
    $confirm  = $_POST['confirm_password'];

    // 1. Validasi Password Match
    if ($password !== $confirm) {
        header("Location: tambah_user.php?status=wrong_password");
        exit();
    }

    // 2. Cek apakah Username sudah ada
    $cekUser = mysqli_query($koneksi, "SELECT username FROM tbl_user WHERE username = '$username'");
    if (mysqli_num_rows($cekUser) > 0) {
        header("Location: tambah_user.php?status=exists");
        exit();
    }

    // 3. Enkripsi Password (Hashing)
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // 4. Query Insert
    $query = "INSERT INTO tbl_user (username, password, role) VALUES ('$username', '$hashed_password', '$role')";

    if (mysqli_query($koneksi, $query)) {
        header("Location: tambah_user.php?status=success");
    } else {
        header("Location: tambah_user.php?status=error");
    }
} else {
    // Jika mencoba akses langsung tanpa submit
    header("Location: user-tambah.php");
}
?>  