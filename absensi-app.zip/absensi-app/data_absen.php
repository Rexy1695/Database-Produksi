<?php
include 'config.php';

header('Content-Type: application/json');

date_default_timezone_set('Asia/Makassar');

// Ambil waktu lokal sekarang
$nowLocal = new DateTime('now', new DateTimeZone('Asia/Makassar'));

// Tentukan start waktu hari ini jam 07:00:00
$startLocal = new DateTime($nowLocal->format('Y-m-d') . ' 07:00:00', new DateTimeZone('Asia/Makassar'));

// Kalau sekarang sebelum jam 7 pagi, start pindah ke kemarin jam 7 pagi
if ($nowLocal < $startLocal) {
    $startLocal->modify('-1 day');
}

// End waktu 24 jam setelah start
$endLocal = clone $startLocal;
$endLocal->modify('+1 day');

// Konversi ke UTC untuk query
$startUtc = $startLocal->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
$endUtc = $endLocal->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');

// Query absensi per shift dan area_kerja antara waktu start dan end
$query = "
  SELECT shift, area_kerja, COUNT(*) AS jumlah
  FROM absensi
  WHERE tanggal_kerja >= ? AND tanggal_kerja < ?
  GROUP BY shift, area_kerja
";

$stmt = $koneksi->prepare($query);
if (!$stmt) {
    echo json_encode(['error' => 'SQL Prepare error: ' . $koneksi->error]);
    exit;
}

$stmt->bind_param('ss', $startUtc, $endUtc);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

// Jika data kosong, kirim pesan debug (bisa dihapus di production)
if (empty($data)) {
    echo json_encode([
        'debug' => true,
        'startLocal' => $startLocal->format('Y-m-d H:i:s T'),
        'endLocal' => $endLocal->format('Y-m-d H:i:s T'),
        'startUtc' => $startUtc,
        'endUtc' => $endUtc,
        'note' => 'Tidak ada data absensi di rentang waktu ini.'
    ]);
    exit;
}

// Kirim data JSON hasil query
echo json_encode($data);
?>
