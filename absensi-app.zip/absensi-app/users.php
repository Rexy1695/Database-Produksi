<?php
include 'config.php';
session_start();

// Cek login
if (!isset($_SESSION['nik'])) {
    header("Location: login.php");
    exit;
}

$logged_nik = $_SESSION['nik'];
$logged_jabatan = $_SESSION['jabatan'] ?? '';

$msg = '';
if (isset($_GET['msg']) && $_GET['msg'] !== '') {
    $msg = urldecode($_GET['msg']);
}

// Pagination & Search setup
$limit = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $limit;
$search = $_GET['search'] ?? '';
$search_esc = mysqli_real_escape_string($koneksi, $search);

// Kondisi query sesuai role dan search
$where = '';
if ($logged_jabatan === 'admin') {
    if ($search_esc !== '') {
        $where = "WHERE nama LIKE '%$search_esc%' OR nik LIKE '%$search_esc%'";
    }
} else {
    $where = "WHERE nik = '" . mysqli_real_escape_string($koneksi, $logged_nik) . "'";
}

// Hitung total data
$total_query = "SELECT COUNT(*) AS total FROM users $where";
$total_result = mysqli_query($koneksi, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_data = $total_row['total'];
$total_pages = ceil($total_data / $limit);

// Ambil data users
$query = "SELECT nik, nama, jabatan FROM users $where ORDER BY nik ASC LIMIT $limit OFFSET $offset";
$result = mysqli_query($koneksi, $query);

// Proses POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Tambah User
    if (isset($_POST['add_user']) && $_POST['add_user'] == '1') {
        if ($logged_jabatan !== 'admin') {
            header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Anda tidak berhak menambah user."));
            exit;
        } else {
            $nik = trim($_POST['nik']);
            $nama = trim($_POST['nama']);
            $jabatan = $_POST['jabatan'];
            $password = $_POST['password'] ?? '';
            $password_confirm = $_POST['password_confirm'] ?? '';

            $allowed_roles = ['admin', 'crew ccr'];
            if (!in_array($jabatan, $allowed_roles)) {
                header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Jabatan tidak valid."));
                exit;
            }

            if (!$nik || !$nama || !$jabatan || !$password || !$password_confirm) {
                header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Semua field wajib diisi!"));
                exit;
            } elseif ($password !== $password_confirm) {
                header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Password dan konfirmasi password tidak sama!"));
                exit;
            } else {
                $cek = mysqli_query($koneksi, "SELECT nik FROM users WHERE nik='$nik'");
                if (mysqli_num_rows($cek) > 0) {
                    header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("NIK sudah ada."));
                    exit;
                } else {
                    $passHash = password_hash($password, PASSWORD_DEFAULT);
                    $sql = "INSERT INTO users (nik, nama, jabatan, password) VALUES ('$nik', '$nama', '$jabatan', '$passHash')";
                    if (mysqli_query($koneksi, $sql)) {
                        header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("User berhasil ditambahkan."));
                        exit;
                    } else {
                        header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Gagal tambah user: " . mysqli_error($koneksi)));
                        exit;
                    }
                }
            }
        }
    }

    // Proses input banyak user
    if (isset($_POST['bulk_add_user']) && $logged_jabatan === 'admin') {
        $success = 0;
        $failed = 0;
        $niks = $_POST['nik'] ?? [];
        $namas = $_POST['nama'] ?? [];
        $jabatans = $_POST['jabatan'] ?? [];
        $passwords = $_POST['password'] ?? [];

        for ($i = 0; $i < count($niks); $i++) {
            $nik = trim($niks[$i]);
            $nama = trim($namas[$i]);
            $jabatan = strtolower(trim($jabatans[$i]));
            $password = trim($passwords[$i]);

            if (!$nik || !$nama || !$jabatan || !$password) {
                $failed++;
                continue;
            }

            $cek = mysqli_query($koneksi, "SELECT nik FROM users WHERE nik='" . mysqli_real_escape_string($koneksi, $nik) . "'");
            if (mysqli_num_rows($cek) > 0) {
                $failed++;
                continue;
            }

            $allowed_roles = ['admin', 'crew ccr'];
            if (!in_array($jabatan, $allowed_roles)) {
                $failed++;
                continue;
            }

            $passHash = password_hash($password, PASSWORD_DEFAULT);
            $nik = mysqli_real_escape_string($koneksi, $nik);
            $nama = mysqli_real_escape_string($koneksi, $nama);
            $jabatan = mysqli_real_escape_string($koneksi, $jabatan);

            $insert = mysqli_query($koneksi, "INSERT INTO users (nik, nama, jabatan, password) VALUES ('$nik', '$nama', '$jabatan', '$passHash')");
            if ($insert) {
                $success++;
            } else {
                $failed++;
            }
        }

        $msg = "$success user berhasil ditambahkan. $failed gagal.";
        header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode($msg));
        exit;
    }

    // Edit User
    if (isset($_POST['edit_user']) && $_POST['edit_user'] == '1') {
        $nik_asli = trim($_POST['edit_hidden_nik'] ?? '');
        $nik_baru = trim($_POST['nik'] ?? '');
        $nama = trim($_POST['nama'] ?? '');
        $jabatan = $_POST['jabatan'] ?? '';
        $password_lama = $_POST['password_lama'] ?? '';
        $password_baru = $_POST['password_baru'] ?? '';
        $password_konfirmasi = $_POST['password_konfirmasi'] ?? '';

        // Cek hak akses: selain admin hanya boleh edit dirinya sendiri
        if ($logged_jabatan !== 'admin' && $nik_asli !== $logged_nik) {
            header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Anda tidak berhak mengedit user lain."));
            exit;
        }

        if ($logged_jabatan !== 'admin') {
            // Non-admin hanya bisa update nama dan password sendiri, tidak boleh ubah nik/jabatan
            if (!$nama) {
                header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Nama wajib diisi."));
                exit;
            }

            if ($password_lama || $password_baru || $password_konfirmasi) {
                // Kalau mau ganti password, wajib isi semua field password
                if (!$password_lama || !$password_baru || !$password_konfirmasi) {
                    header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Semua field password harus diisi jika ingin mengganti password."));
                    exit;
                }

                // Cek password lama
                $user = mysqli_query($koneksi, "SELECT password FROM users WHERE nik='$nik_asli'");
                if (mysqli_num_rows($user) === 1) {
                    $data_user = mysqli_fetch_assoc($user);
                    if (!password_verify($password_lama, $data_user['password'])) {
                        header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Password lama salah."));
                        exit;
                    }
                } else {
                    header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("User tidak ditemukan."));
                    exit;
                }

                // Validasi password baru dan konfirmasi
                if ($password_baru !== $password_konfirmasi) {
                    header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Password baru dan konfirmasi tidak cocok."));
                    exit;
                }

                // Update nama dan password
                $passHash = password_hash($password_baru, PASSWORD_DEFAULT);
                $sql = "UPDATE users SET nama='$nama', password='$passHash' WHERE nik='$nik_asli'";
            } else {
                // Hanya update nama
                $sql = "UPDATE users SET nama='$nama' WHERE nik='$nik_asli'";
            }
        } else {
            // Admin boleh update semua data termasuk nik, jabatan, password
            if (!$nik_baru || !$nama || !$jabatan) {
                header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Semua data wajib diisi."));
                exit;
            }

            if ($password_baru || $password_konfirmasi) {
                // Kalau ubah password, password baru dan konfirmasi wajib sama dan diisi
                if (!$password_baru || !$password_konfirmasi) {
                    header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Password baru dan konfirmasi wajib diisi."));
                    exit;
                }
                if ($password_baru !== $password_konfirmasi) {
                    header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Password baru dan konfirmasi tidak cocok."));
                    exit;
                }

                $passHash = password_hash($password_baru, PASSWORD_DEFAULT);
                $sql = "UPDATE users SET nik='$nik_baru', nama='$nama', jabatan='$jabatan', password='$passHash' WHERE nik='$nik_asli'";
            } else {
                // Update data tanpa password
                $sql = "UPDATE users SET nik='$nik_baru', nama='$nama', jabatan='$jabatan' WHERE nik='$nik_asli'";
            }
        }

        if (mysqli_query($koneksi, $sql)) {
            $msg = ($logged_jabatan === 'admin') ? "User berhasil diupdate." : "Data berhasil diupdate.";
            header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode($msg));
            exit;
        } else {
            header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Gagal update: " . mysqli_error($koneksi)));
            exit;
        }
    }
}

// Proses hapus user (admin only)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['delete'])) {
    if ($logged_jabatan === 'admin') {
        $nik_delete = mysqli_real_escape_string($koneksi, $_GET['delete']);
        if ($nik_delete === $logged_nik) {
            header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Anda tidak dapat menghapus akun Anda sendiri."));
            exit;
        } else {
            $res = mysqli_query($koneksi, "DELETE FROM users WHERE nik='$nik_delete'");
            if ($res) {
                header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("User berhasil dihapus."));
                exit;
            } else {
                header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Gagal menghapus user."));
                exit;
            }
        }
    } else {
        header("Location: " . $_SERVER['PHP_SELF'] . "?msg=" . urlencode("Anda tidak berhak menghapus user."));
        exit;
    }
}


$title = "Dashboard - User";
require "template/header.php";
require "template/navbar.php";
require "template/sidebar.php";
?>


<div class="content-wrapper p-3">
    <section class="content-header">
        <h1>Users</h1>
    </section>
    <section class="content">
        <div class="container-fluid">

            <?php if ($msg != ''): ?>
                <?php
                $alertClass = 'alert-info';
                $msgLower = strtolower($msg);
                if (strpos($msgLower, 'gagal') !== false || strpos($msgLower, 'error') !== false || strpos($msgLower, 'tidak') !== false) {
                    $alertClass = 'alert-danger';
                } elseif (strpos($msgLower, 'berhasil') !== false) {
                    $alertClass = 'alert-success';
                }
                ?>
                <div class="alert <?= $alertClass ?>" id="msg-alert" role="alert" style="
                        position: fixed;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        z-index: 9999;
                        min-width: 300px;
                        text-align: center;
                        box-shadow: 0 0 10px rgba(0,0,0,0.3);
                    ">
                    <?= htmlspecialchars($msg) ?>
                </div>
            <?php endif; ?>
            <?php if ($logged_jabatan === 'admin'): ?>
                <button id="btnShowAddUser" class="btn btn-success mb-3"><i class="fa-solid fas fa-plus"></i> Tambah User Baru</button>
                <?php if ($logged_jabatan === 'admin') { ?>
                    <button id="btnBulkAddUser" class="btn btn-warning mb-3"><i class="fa-solid fa-paste"></i> Tambah Banyak User</button>
                    <div class="card card-warning mb-3" id="bulkAddForm" style="display:none;">
                        <div class="card-header">
                            <h3 class="card-title">Tambah Banyak User (Copy dari Excel)</h3>
                        </div>
                        <div class="card-body">
                            <form method="post">
                                <input type="hidden" name="bulk_add_user" value="1">
                                <div class="table-responsive mb-2">
                                    <table class="table table-bordered" id="bulkUserTable">
                                        <thead>
                                            <tr>
                                                <th>NIK</th>
                                                <th>Nama</th>
                                                <th>Jabatan</th>
                                                <th>Password</th>
                                            </tr>
                                        </thead>
                                        <tbody contenteditable="true" id="bulkUserTbody">
                                            <tr>
                                                <td><input type="text" name="nik[]" class="form-control" required></td>
                                                <td><input type="text" name="nama[]" class="form-control" required></td>
                                                <td>
                                                    <select name="jabatan[]" class="form-control" required>
                                                        <option value="">Pilih Jabatan</option>
                                                        <option value="admin">Admin</option>
                                                        <option value="crew ccr">Crew CCR</option>
                                                    </select>
                                                </td>
                                                <td><input type="text" name="password[]" class="form-control" required></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <button type="submit" class="btn btn-warning">Simpan Banyak User</button>
                                <button type="button" class="btn btn-secondary" id="btnCancelBulk">Batal</button>
                            </form>
                        </div>
                    </div>
                <?php } ?>

                <div class="card card-primary mb-3" id="formAddUser" style="display:none;">
                    <div class="card-header">
                        <h3 class="card-title">Tambah User</h3>
                    </div>

                    <div class="card-body">
                        <form method="post" autocomplete="off">
                            <input type="hidden" name="add_user" value="1" />
                            <input type="hidden" name="edit_user" value="0" />
                            <div class="form-group">
                                <label for="nik">NIK</label>
                                <input type="text" name="nik" id="nik" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="nama">Nama</label>
                                <input type="text" name="nama" id="nama" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="jabatan">Jabatan</label>
                                <select name="jabatan" id="jabatan" class="form-control" required>
                                    <option value="">-- Pilih Jabatan --</option>
                                    <option value="admin">Admin</option>
                                    <option value="crew ccr">Crew CCR</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" name="password" id="password" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="password_confirm">Konfirmasi Password</label>
                                <input type="password" name="password_confirm" id="password_confirm" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-success">Tambah User</button>
                            <button type="button" class="btn btn-secondary" id="btnCancelAddUser">Batal</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>

            <form method="get" class="form-inline mb-3">
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Cari nama atau NIK" class="form-control mr-2">
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-sm fa-magnifying-glass"></i> Cari</button>
            </form>

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>NIK</th>
                        <th>Nama</th>
                        <th>Jabatan</th>
                        <?php if ($logged_jabatan === 'admin'): ?>
                            <th>Aksi</th>
                        <?php elseif ($where): ?>
                            <th>Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) === 0): ?>
                        <tr>
                            <td colspan="4" class="text-center">Data tidak ditemukan.</td>
                        </tr>
                    <?php else: ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['nik']) ?></td>
                                <td><?= htmlspecialchars($row['nama']) ?></td>
                                <td><?= htmlspecialchars($row['jabatan']) ?></td>
                                <td>
                                    <button class="btn btn-sm btn-info btnEditUser"
                                        data-nik="<?= htmlspecialchars($row['nik']) ?>"
                                        data-nama="<?= htmlspecialchars($row['nama']) ?>"
                                        data-jabatan="<?= htmlspecialchars($row['jabatan']) ?>"
                                        <?= ($logged_jabatan !== 'admin' && $row['nik'] !== $logged_nik) ? 'disabled' : '' ?>>
                                        <i class="fa-solid fa-pen-to-square"></i> Edit
                                    </button>
                                    <?php if ($logged_jabatan === 'admin' && $row['nik'] !== $logged_nik): ?>
                                        <a href="<?= $_SERVER['PHP_SELF'] ?>?delete=<?= urlencode($row['nik']) ?>" onclick="return confirm('Yakin ingin hapus user ini?')" class="btn btn-sm btn-danger"><i class="fa-solid fa-trash"></i> Hapus</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Pagination -->
            <nav>
                <ul class="pagination">
                    <?php if ($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>">Prev</a></li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>">Next</a></li>
                    <?php endif; ?>
                </ul>
            </nav>

            <!-- Form Edit User (hidden by default) -->
            <div class="card card-primary" id="formEditUser" style="display:none;">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-edit"></i></i> Edit User</h3>
                </div>
                <div class="card-body">
                    <form method="post" autocomplete="off">
                        <input type="hidden" name="edit_user" value="1" />
                        <input type="hidden" name="add_user" value="0" />
                        <input type="hidden" name="nik" value= />
                        <div class="form-group">
                            <label for="edit_nik">NIK</label>

                            <!-- Hidden NIK yang akan digunakan untuk WHERE saat update -->
                            <input type="hidden" name="edit_hidden_nik" id="edit_hidden_nik">
                            <?php if ($logged_jabatan === 'admin'): ?>
                                <input type="text" name="nik" id="edit_nik" class="form-control" required>
                            <?php else: ?>
                                <input type="text" id="edit_nik" class="form-control" readonly>
                                <input type="hidden" name="nik" id="hidden_nik_user" value="<?= htmlspecialchars($logged_nik) ?>">
                            <?php endif; ?>
                        </div>


                        <div class="form-group">
                            <label for="edit_nama">Nama</label>
                            <input type="text" name="nama" id="edit_nama" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_jabatan">Jabatan</label>
                            <?php if ($logged_jabatan === 'admin'): ?>
                                <select name="jabatan" id="edit_jabatan" class="form-control" required>
                                    <option value="admin">Admin</option>
                                    <option value="crew ccr">Crew CCR</option>
                                </select>
                            <?php else: ?>
                                <input type="text" class="form-control" readonly value="<?= htmlspecialchars($logged_jabatan) ?>">
                                <input type="hidden" name="jabatan" value="<?= htmlspecialchars($logged_jabatan) ?>">
                            <?php endif; ?>
                        </div>
                        <hr>
                        <p><strong>Ganti Password (Opsional)</strong></p>
                        <?php if ($logged_jabatan === 'admin'): ?>
                            <div class="form-group">
                                <label for="edit_password_lama">Password Lama (kosongkan jika reset tanpa lama)</label>
                                <input type="password" name="password_lama" id="edit_password_lama" class="form-control">
                            </div>
                        <?php else: ?>
                            <div class="form-group">
                                <label for="edit_password_lama">Password Lama</label>
                                <input type="password" name="password_lama" id="edit_password_lama" class="form-control" required>
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <label for="edit_password_baru">Password Baru</label>
                            <input type="password" name="password_baru" id="edit_password_baru" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="edit_password_konfirmasi">Konfirmasi Password Baru</label>
                            <input type="password" name="password_konfirmasi" id="edit_password_konfirmasi" class="form-control">
                        </div>

                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        <button type="button" id="btnCancelEdit" class="btn btn-secondary">Batal</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
    // Pesan otomatis hilang
    setTimeout(() => {
        const msg = document.getElementById('msg-alert');
        if (msg) msg.style.display = 'none';
    }, 3000);

    // Show/Hide form tambah user
    const btnShowAddUser = document.getElementById('btnShowAddUser');
    const formAddUser = document.getElementById('formAddUser');
    const btnCancelAddUser = document.getElementById('btnCancelAddUser');

    if (btnShowAddUser) {
        btnShowAddUser.addEventListener('click', () => {
            formAddUser.style.display = 'block';
            btnShowAddUser.style.display = 'none';
        });
    }
    if (btnCancelAddUser) {
        btnCancelAddUser.addEventListener('click', () => {
            formAddUser.style.display = 'none';
            btnShowAddUser.style.display = 'inline-block';
        });
    }

    // Edit user button click
    const btnEditUsers = document.querySelectorAll('.btnEditUser');
    const formEditUser = document.getElementById('formEditUser');
    const btnCancelEdit = document.getElementById('btnCancelEdit');

    btnEditUsers.forEach(btn => {
        btn.addEventListener('click', () => {
            const nik = btn.dataset.nik;
            const nama = btn.dataset.nama;
            const jabatan = btn.dataset.jabatan;

            document.getElementById('edit_hidden_nik').value = nik; // <-- ini penting!
            document.getElementById('edit_nik').value = nik;
            document.getElementById('edit_nama').value = nama;

            <?php if ($logged_jabatan === 'admin'): ?>
                document.getElementById('edit_jabatan').value = jabatan;
            <?php endif; ?>

            // Reset password fields
            document.getElementById('edit_password_lama').value = '';
            document.getElementById('edit_password_baru').value = '';
            document.getElementById('edit_password_konfirmasi').value = '';

            formEditUser.style.display = 'block';

            // Scroll to form
            formEditUser.scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    if (btnCancelEdit) {
        btnCancelEdit.addEventListener('click', () => {
            formEditUser.style.display = 'none';
        });
    }
</script>
<script>
    const btnBulk = document.getElementById('btnBulkAddUser');
    const formBulk = document.getElementById('bulkAddForm');
    const btnCancelBulk = document.getElementById('btnCancelBulk');

    if (btnBulk) {
        btnBulk.addEventListener('click', () => {
            formBulk.style.display = 'block';
            btnBulk.style.display = 'none';
        });
    }
    if (btnCancelBulk) {
        btnCancelBulk.addEventListener('click', () => {
            formBulk.style.display = 'none';
            btnBulk.style.display = 'inline-block';
        });
    }

    document.getElementById('bulkUserTbody').addEventListener('paste', function(e) {
        e.preventDefault();
        const clipboardData = e.clipboardData || window.clipboardData;
        const pastedData = clipboardData.getData('Text');

        const rows = pastedData.trim().split('\n');
        const tbody = document.getElementById('bulkUserTbody');
        tbody.innerHTML = '';

        rows.forEach(row => {
            const cols = row.split('\t');
            if (cols.length >= 4) {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                <td><input type="text" name="nik[]" class="form-control" value="${cols[0].trim()}" required></td>
                <td><input type="text" name="nama[]" class="form-control" value="${cols[1].trim()}" required></td>
                <td>
                    <select name="jabatan[]" class="form-control" required>
                        <option value="">Pilih Jabatan</option>
                        <option value="admin" ${cols[2].trim().toLowerCase() === 'admin' ? 'selected' : ''}>Admin</option>
                        <option value="crew ccr" ${cols[2].trim().toLowerCase() === 'crew ccr' ? 'selected' : ''}>Crew CCR</option>
                    </select>
                </td>
                <td><input type="text" name="password[]" class="form-control" value="${cols[3].trim()}" required></td>
            `;
                tbody.appendChild(tr);
            }
        });
    });
</script>

<?php
require "template/footer.php";
?>