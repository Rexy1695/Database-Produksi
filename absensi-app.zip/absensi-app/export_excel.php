<?php
include 'config.php';
session_start();

if (!isset($_SESSION['nik'])) {
    header("Location: login.php");
    exit;
}

$start  = $_GET['start_date'] ?? date('Y-m-d', strtotime('-2 days'));
$end    = $_GET['end_date'] ?? date('Y-m-d');
$search = $_GET['search'] ?? '';

$user_nik     = $_SESSION['nik'];
$user_jabatan = $_SESSION['jabatan'] ?? '';

// Amankan input
$start_esc  = mysqli_real_escape_string($koneksi, $start);
$end_esc    = mysqli_real_escape_string($koneksi, $end);
$search_esc = mysqli_real_escape_string($koneksi, $search);

$search_sql = '';
if (!empty($search_esc)) {
    $search_sql = "AND (a.nik LIKE '%$search_esc%' OR u.nama LIKE '%$search_esc%' OR a.area_kerja LIKE '%$search_esc%')";
}

// Nama file export
$filename = "laporan_absensi_{$start}_{$end}.xls";

// Set header untuk Excel download
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: no-cache");
header("Expires: 0");

// Mulai output tabel
echo "<table border='1'>";
echo "<tr>
        <th>Tanggal</th>
        <th>NIK</th>
        <th>Nama</th>
        <th>Shift</th>
        <th>Area Kerja</th>
      </tr>";

// Query data sesuai role
if ($user_jabatan === 'admin') {
    $query = "SELECT a.nik, u.nama, a.tanggal_kerja, a.shift, a.area_kerja
              FROM absensi a
              JOIN users u ON a.nik = u.nik
              WHERE a.tanggal_kerja BETWEEN '$start_esc' AND '$end_esc' $search_sql
              ORDER BY a.tanggal_kerja ASC";
} else {
    $query = "SELECT a.nik, u.nama, a.tanggal_kerja, a.shift, a.area_kerja
              FROM absensi a
              JOIN users u ON a.nik = u.nik
              WHERE a.tanggal_kerja BETWEEN '$start_esc' AND '$end_esc'
                AND a.nik = '$user_nik' $search_sql
              ORDER BY a.tanggal_kerja ASC";
}

$result = mysqli_query($koneksi, $query);

// Output data baris per baris
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row['tanggal_kerja']) . "</td>";
    echo "<td>" . htmlspecialchars($row['nik']) . "</td>";
    echo "<td>" . htmlspecialchars($row['nama']) . "</td>";
    echo "<td>" . htmlspecialchars($row['shift']) . "</td>";
    echo "<td>" . htmlspecialchars($row['area_kerja']) . "</td>";
    echo "</tr>";
}
echo "</table>";

// Jangan ada header redirect, jangan ada output tambahan, langsung exit
exit;
