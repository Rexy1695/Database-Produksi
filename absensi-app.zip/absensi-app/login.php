<?php
session_start();
include 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $nik = htmlspecialchars(trim($_POST['nik']));
    $password = trim($_POST['password']);

    $stmt = mysqli_prepare($koneksi, "SELECT * FROM users WHERE nik = ?");
    mysqli_stmt_bind_param($stmt, "s", $nik);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);
        if (password_verify($password, $user['password'])) {
            $_SESSION['nik'] = $user['nik'];
            $_SESSION['nama'] = $user['nama'];
            $_SESSION['jabatan'] = $user['jabatan'];
            header('Location: index.php');
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "NIK tidak ditemukan!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login Absensi</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- AdminLTE & FontAwesome -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <link rel="icon" href="asset/logo.png" type="image/x-icon">

  <style>
    html, body {
      height: 100%;
      margin: 0;
    }

    body {
      background: url('asset/bg.png') no-repeat center center fixed;
      background-size: cover;
      display: flex;
      flex-direction: column;
    }

    #loading {
      position: fixed;
      z-index: 9999;
      background: #fff;
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .main-content {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      transform: translateY(50px);
      transition: all 0.5s ease;
    }

    .main-content.show {
      opacity: 1;
      transform: translateY(0);
    }

    .login-box {
      width: 100%;
      max-width: 400px;
      background: rgba(255, 255, 255, 0.95);
      padding: 20px;
      border-radius: 10px;
    }

    .login-logo {
      font-size: 22px;
      font-weight: bold;
      text-align: center;
      margin-bottom: 15px;
      color: #007bff;
    }

    footer {
      text-align: center;
      background: rgba(255,255,255,0.8);
      padding: 10px;
      font-size: 14px;
    }
  </style>
</head>

<body>

  <!-- Loading Spinner -->
  <div id="loading">
    <div class="spinner-border text-primary" role="status">
      <span class="sr-only">Loading...</span>
    </div>
  </div>

  <!-- Konten Login -->
  <div class="main-content" id="mainContent">
    <div class="login-box">
      <div class="login-logo">
        <i class="fas fa-fingerprint"></i> Login Absensi
      </div>
      <div class="card-body login-card-body">
        <?php if (!empty($error)): ?>
          <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <form method="post" autocomplete="off">
          <div class="input-group mb-3">
            <input type="text" name="nik" class="form-control" placeholder="NIK" required>
            <div class="input-group-append">
              <div class="input-group-text"><i class="fas fa-id-badge"></i></div>
            </div>
          </div>

          <div class="input-group mb-3">
            <input type="password" name="password" class="form-control" placeholder="Password" required>
            <div class="input-group-append">
              <div class="input-group-text"><i class="fas fa-lock"></i></div>
            </div>
          </div>

          <button type="submit" name="login" class="btn btn-primary btn-block">Masuk</button>
        </form>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer>
    <?= date('Y') ?> &copy; <strong>CCR Departemen</strong>
  </footer>

  <!-- Script -->
  <script>
    window.addEventListener("load", () => {
      // Tampilkan form setelah loading
      document.getElementById("loading").style.display = "none";
      document.getElementById("mainContent").classList.add("show");
    });
  </script>

  <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>
