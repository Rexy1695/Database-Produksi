<?php
include 'config.php';
session_start();
if (!isset($_SESSION['nik'], $_SESSION['nama'], $_SESSION['jabatan'])) header("Location: login.php");
$notif=''; 

if ($_SERVER['REQUEST_METHOD']==='POST') {
  $jab = $_SESSION['jabatan'];
  $nik = $jab==='admin' ? $_POST['nik'] : $_SESSION['nik'];
  $tanggal = $_POST['tanggalKerja'];
  $shift = $_POST['shift'];
  $area = $_POST['areaKerja'];

  if ($jab==='admin') {
    $stmtu = $koneksi->prepare("SELECT nama FROM users WHERE nik = ?");
    $stmtu->bind_param('s', $nik);
    $stmtu->execute();
    $resu = $stmtu->get_result();
    if ($resu->num_rows) {
      $nama = $resu->fetch_assoc()['nama'];
    } else {
      $notif = '<div class="alert alert-danger">NIK tidak ditemukan!</div>';
    }
  } else {
    $nama = $_SESSION['nama'];
  }

  if (!$notif && ($nik && $nama && $tanggal && $shift && $area)) {
    $stmtc = $koneksi->prepare("SELECT * FROM absensi WHERE nik=? AND tanggal_kerja=? AND shift=?");
    $stmtc->bind_param('sss', $nik,$tanggal,$shift);
    $stmtc->execute();
    if ($stmtc->get_result()->num_rows) {
      $notif = '<div class="alert alert-warning">Anda Sudah absen Hari ini.</div>';
    } else {
      $stmti = $koneksi->prepare("INSERT INTO absensi(nik,tanggal_kerja,shift,area_kerja) VALUES(?,?,?,?)");
      $stmti->bind_param('ssss', $nik,$tanggal,$shift,$area);
      $notif = $stmti->execute() ? '<div class="alert alert-success">Absen berhasil!</div>' : '<div class="alert alert-danger">Gagal menyimpan absen.</div>';
    }
  } elseif (!$notif) {
    $notif = '<div class="alert alert-warning">Lengkapi semua data.</div>';
  }
}

$title="Form Absen";
require "template/header.php";
require "template/navbar.php";
require "template/sidebar.php";
?>
<div class="content-wrapper p-3">
  <h1>Form Absen</h1>
  <?= $notif ?>
  <div class="card card-info">
    <div class="card-header"><h3>Isi Kehadiran</h3></div>
    <form method="post" class="m-3" onsubmit="this.submitBtn.disabled=true">
      <div class="form-group row">
        <label class="col-sm-2">NIK</label>
        <div class="col-sm-10">
          <?php if ($_SESSION['jabatan']==='admin'): ?>
            <input name="nik" id="nik" class="form-control" required>
          <?php else: ?>
            <input name="nik" class="form-control" readonly value="<?= htmlspecialchars($_SESSION['nik']) ?>">
          <?php endif; ?>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2">Nama</label>
        <div class="col-sm-10">
          <?php if ($_SESSION['jabatan']==='admin'): ?>
            <input id="nama" class="form-control" readonly>
          <?php else: ?>
            <input class="form-control" readonly value="<?= htmlspecialchars($_SESSION['nama']) ?>">
          <?php endif; ?>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2">Tanggal Kerja</label>
        <div class="col-sm-10">
          <input type="date" name="tanggalKerja" class="form-control" required
                 value="<?= date('Y-m-d') ?>">
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2">Shift</label>
        <div class="col-sm-10">
          <div class="form-check form-check-inline">
            <input type="radio" name="shift" value="Shift 1" required> Shift 1
          </div>
          <div class="form-check form-check-inline">
            <input type="radio" name="shift" value="Shift 2"> Shift 2
          </div>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2">Area Kerja</label>
        <div class="col-sm-10">
          <select name="areaKerja" class="form-control" required>
            <option value="">-- Pilih Area --</option>
              <option>Halte Km 98</option>
              <option>Dispatch Km 38 MP</option>
              <option>Dispatch Km 38 SN</option>
              <option>Halte Km 6 SN</option>
              <option>Halte Km 10 MP</option>
              <option>WB Km 10 MP</option>
              <option>WB Km 6 SN</option>
          </select>
        </div>
      </div>
      <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
          <button name="submitBtn" type="submit" class="btn btn-info">Simpan Absen</button>
        </div>
      </div>
    </form>
  </div>
</div>
<?php require "template/footer.php"; ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<?php if ($_SESSION['jabatan']==='admin'): ?>
<script>
$('#nik').on('input',function(){
  $.post('get_nama.php',{nik:this.value}).done(function(res){
    $('#nama').val(res);
  });
});
</script>
<?php endif; ?>
