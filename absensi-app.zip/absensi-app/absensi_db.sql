-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 29, 2026 at 01:40 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `absensi_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `absensi`
--

CREATE TABLE `absensi` (
  `id` int NOT NULL,
  `nik` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `tanggal_kerja` date NOT NULL,
  `shift` enum('Shift 1','Shift 2') COLLATE utf8mb4_general_ci NOT NULL,
  `area_kerja` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `absensi`
--

INSERT INTO `absensi` (`id`, `nik`, `tanggal_kerja`, `shift`, `area_kerja`) VALUES
(36, '11915', '2025-07-01', 'Shift 1', 'Dispatch Km 38 SN'),
(37, '6496', '2025-07-01', 'Shift 1', 'Halte Km 10 MP'),
(38, '10283', '2025-07-01', 'Shift 1', 'WB Km 6 SN'),
(39, '6916', '2025-07-01', 'Shift 1', 'Halte Km 98'),
(40, '6894', '2025-07-01', 'Shift 1', 'Halte Km 98'),
(41, '10097', '2025-07-01', 'Shift 1', 'Halte Km 6 SN'),
(50, '8315', '2025-07-01', 'Shift 2', 'Halte Km 10 MP'),
(51, 'Magang1', '2025-07-01', 'Shift 2', 'Halte Km 98'),
(52, '5605', '2025-07-01', 'Shift 2', 'Halte Km 98'),
(53, '10476', '2025-07-01', 'Shift 2', 'Dispatch Km 38 MP'),
(54, 'Magang3', '2025-07-01', 'Shift 2', 'Dispatch Km 38 SN'),
(55, '4288', '2025-07-01', 'Shift 2', 'Halte Km 6 SN'),
(56, '10078', '2025-07-01', 'Shift 2', 'WB Km 10 MP'),
(58, '6498', '2025-07-02', 'Shift 1', 'Halte Km 98'),
(59, '6916', '2025-07-02', 'Shift 1', 'Halte Km 98'),
(60, '5538', '2025-07-02', 'Shift 1', 'Halte Km 10 MP'),
(61, '10855', '2025-07-02', 'Shift 1', 'Dispatch Km 38 SN'),
(62, '11624', '2025-07-02', 'Shift 1', 'Dispatch Km 38 MP'),
(63, '6496', '2025-07-02', 'Shift 1', 'WB Km 10 MP'),
(64, '10097', '2025-07-02', 'Shift 1', 'Halte Km 6 SN'),
(65, '5393', '2025-07-02', 'Shift 1', 'WB Km 6 SN'),
(66, '8315', '2025-07-02', 'Shift 2', 'Dispatch Km 38 MP'),
(67, '10078', '2025-07-02', 'Shift 2', 'WB Km 10 MP'),
(68, 'Magang3', '2025-07-02', 'Shift 2', 'Dispatch Km 38 SN'),
(69, '10476', '2025-07-02', 'Shift 2', 'Halte Km 10 MP'),
(70, '11915', '2025-07-02', 'Shift 2', 'Halte Km 98'),
(71, '10283', '2025-07-02', 'Shift 2', 'WB Km 6 SN'),
(72, '6894', '2025-07-02', 'Shift 2', 'Halte Km 98'),
(73, '4288', '2025-07-02', 'Shift 2', 'Halte Km 6 SN'),
(74, '5605', '2025-07-03', 'Shift 1', 'Halte Km 98'),
(75, '5393', '2025-07-03', 'Shift 1', 'WB Km 6 SN'),
(76, '10097', '2025-07-03', 'Shift 1', 'Halte Km 6 SN'),
(77, '11624', '2025-07-03', 'Shift 1', 'Halte Km 10 MP'),
(78, '5538', '2025-07-03', 'Shift 1', 'WB Km 10 MP'),
(79, '6496', '2025-07-03', 'Shift 1', 'Dispatch Km 38 MP'),
(80, 'Magang1', '2025-07-03', 'Shift 1', 'Dispatch Km 38 SN'),
(81, '6498', '2025-07-03', 'Shift 1', 'Halte Km 98'),
(84, '7963', '2025-07-01', 'Shift 2', 'WB Km 6 SN');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `nik` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `nama` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `jabatan` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'crew ccr',
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nik`, `nama`, `jabatan`, `password`) VALUES
(7, '4617', 'Rexi Irawan', 'admin', '$2y$10$MhQ2Am9NVrDGQKQdDHTaROZWhTFi3FVNxcnOeP6eMjFOtPp3mhafe'),
(23, 'admin', 'admin', 'admin', '$2y$10$krPgFnQLHCCcMh3tu1/kE.YJxcjzGH8rExFeTi5lv5kW1lxs4XrL2'),
(59, '6498', 'Aldianor Saputra', 'crew ccr', '$2y$10$qb6mZ22c455PZoN4DAtUTO.fI0L6A6VFWhBM3Zp.1C.tDRFJC7X0W'),
(60, '10079', 'Alfred Rumanda Furba', 'crew ccr', '$2y$10$c.Vm1JEsYhp7x1t8ThgdKumyOrKJc.u.YOWL2pm445ofZOVQ2iHki'),
(61, '7963', 'Alvin Pratama Putra', 'crew ccr', '$2y$10$Y8MCDRKvF8R09S6K.0pC8uemXoLi2vi7m0m3wp4ukz7xd4ZiwcnP2'),
(62, '4107', 'Ari Alpan Pratama Tarigan', 'admin', '$2y$10$23m8Mag/8YjLhafG5ZkPBe2Z2jGN3THPNXFByV6ckkx2E2QLkyOA2'),
(63, '4061', 'Benny Sulianto', 'admin', '$2y$10$zQ/lSmhDIrT8w2xM2Rsj6ux9z24jqQMlY6CmUErI6A7ZXkauKFUzy'),
(64, '4288', 'Eggi Aditiya', 'crew ccr', '$2y$10$B1ICB6mzzs2jS2DthlotYOlsmF5pvW2OTQHVW8ilQWanr2ZGLNO3K'),
(65, '6497', 'Farhan Ranggita Jayanto', 'crew ccr', '$2y$10$V5XTfQmYYukiq.G7UsMxUeQctIxi87vPvfilhckIS2AI1Ij4OWpvu'),
(66, '9697', 'I Wayan Eka Mertha', 'admin', '$2y$10$TbUfHl0.w5ZHkRkBpVEF7ujbbnXLMw39otqV3h8TftyLRQpsuDRrm'),
(67, '5605', 'Irvan Saputra', 'crew ccr', '$2y$10$xAJR/h8alkb0160Q5qBTWeOE6YX2ix83NNxviaJ915YKS8HhWOkem'),
(68, '10097', 'Kevin Tandilangi', 'crew ccr', '$2y$10$SYdECBIeAPSv3YfnDCYeu.ab4w/CpXZXCoxg2QxD5O.zIi5A4CabG'),
(69, '6893', 'Muhammad Rasyad Sultansyah', 'crew ccr', '$2y$10$YgW20NDBBNOZzLX/PcCso.PuIAEVBhic2aAnZKMjPTcAoqEHrcosC'),
(70, '10077', 'Neki Oktavianus Mustamu', 'crew ccr', '$2y$10$PyWo01JNdtWaVGdDIby02up/NGMcl4uxfCU236LUPshVfl9j9HWbW'),
(71, '10020', 'Nur Habibi', 'admin', '$2y$10$OCo.F7vlLjzONnVV79ypuufZt1f9.51afai1Sm8e/YM3WwAU2J6n6'),
(72, '4633', 'Ramadhan Maulana Tarhalim', 'crew ccr', '$2y$10$CQ6hvcLPL68Cx20uwm09oe.kHI.E0aInnR6yghRywaSXCwUt0TuEm'),
(73, '8144', 'Rasyid', 'admin', '$2y$10$Chn70GZBJAln7CZ18vNQjOqCFlVuu/Y7tzOrtgNAX66EI2qirgZE.'),
(74, '6496', 'Samuel Nainggolan', 'crew ccr', '$2y$10$9249qZqKirUYQ7ZPWoTZruuCQKJtUmHhrzZfAtDTtIIT7eszWZa2C'),
(75, '5538', 'Sayyidul Ahkam', 'crew ccr', '$2y$10$5PcmvI/yxdIBagoJfZ/aAujjeHs.zKIs1Dku2SyqKOBH1esZKPDiC'),
(76, '10078', 'Sony Firmansyah', 'crew ccr', '$2y$10$FlhphLljUDQQrJ9xejIXvedmuZKZBIMUJLKfRhasn90WhGUbHIEhO'),
(77, '8315', 'Taufik Hidayat', 'crew ccr', '$2y$10$1zRTtZc9BwUwe9W75P4KreMqS4ys5YO99kycztL34id/DQyhVMWZ6'),
(78, '6894', 'Taufik Syahrubi', 'crew ccr', '$2y$10$UyXi3VaRMQ1D1MLtYqD28OvL/cJT.DoehkfityMxsgvz0bF8W90i2'),
(79, '6916', 'Wawan Supaji', 'crew ccr', '$2y$10$WAKYo5ENS8ZMSaPOcIZUcO.WfNkLjKmDMqMX97R.fxW31uIHP4Xie'),
(80, '4757', 'Widhi Nugraha Yogie Djatmiko', 'admin', '$2y$10$5nHhelkhy8fkFSUV8QsdFOweRKa945nJUzycMGV2HiQuTl5F3PSou'),
(81, '10476', 'Rian Pratiwi', 'crew ccr', '$2y$10$GJX/yBiEY/9czPqX0sXVVuhsFniYaUB3y89vxLYu8L3iA8.BaO0US'),
(82, '10854', 'Muhammad Fahmi Irfan Ramadhan', 'crew ccr', '$2y$10$nG4CUeUlyEoMGRxtr0.2DuZmUaD6R/kAimyANRwKdcQk5AXLEH0RC'),
(83, '10855', 'Muhammad Naufal Haidar Rasyid', 'crew ccr', '$2y$10$6pYAULze.NH4UN8rcbQg9uv.qSSdQb0ioKj0ENqd0z7aOauF7Idqu'),
(84, '10283', 'Cristionaldo', 'crew ccr', '$2y$10$lwvWB2/m1ZPwQ443.0xkDONa9WmUfXfDFbt5Ae7PbS2iMUxbHPKPq'),
(85, 'Magang1', 'M. Vanronald Rezky S', 'crew ccr', '$2y$10$AL89RLtLobpe2aIRqy4xJuR2SqSF0.QwnQnw7lxMGAN6nhKvEMalm'),
(86, '11915', 'Zidan Ramadan', 'crew ccr', '$2y$10$3truywlwuO9H44WHD2.mjOM3TP8.A6KZjSlkuwvOkYEG6RSD7OeDS'),
(87, 'Magang2', 'Anwar Fathoni', 'crew ccr', '$2y$10$1kMxHkjRe8hCqXmsZYTsmOW7OVISfy10KFH8ZVKPC/nt57vlLfKe6'),
(90, 'Magang3', 'Kevin Ps Karang', 'crew ccr', '$2y$10$o8yaBw/70p2ce8XHuo22xObrvf6wGvTH/B9msb0zAAusDWfFxNrPC'),
(96, 'Tamu', 'Tamu', 'crew ccr', '$2y$10$LXy77MEHRQiQSGfdTDhJpOu.eTe8TPqLmXzVonCM4S.BhUVCLm5LS'),
(97, '5393', 'Alfian Nur', 'crew ccr', '$2y$10$cqxyzyh6W5oM7FBcxzOWcOCofe4OXY97mmbdkm9qfG5vKX.sFQFTG'),
(98, '11624', 'Abdul Chair', 'crew ccr', '$2y$10$O9in9RLrQu.b6nCL.zRC0ua6kVLr/772wsHmiF2D9YcuyscJvWjVi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nik` (`nik`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nik` (`nik`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `absensi`
--
ALTER TABLE `absensi`
  ADD CONSTRAINT `absensi_ibfk_1` FOREIGN KEY (`nik`) REFERENCES `users` (`nik`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
