<?php
// config.php
date_default_timezone_set('Asia/Makassar');
$host     = 'localhost';
$username = 'root';
$password = '';
$database = 'absensi_db';

// Membuat koneksi ke database
$koneksi = mysqli_connect($host, $username, $password, $database);

// Cek koneksi
// if (!$koneksi) {
//     die('Koneksi gagal: ' . mysqli_connect_error());
// }

$main_url = "http://localhost/absensi-app";
?>
