<?php
include 'config.php';
session_start();

if (!isset($_SESSION['nik'])) {
  header("Location: login.php");
  exit;
}

// Set timezone
date_default_timezone_set('Asia/Makassar');
$now = new DateTime('now', new DateTimeZone('Asia/Makassar'));
$today7am = new DateTime($now->format('Y-m-d') . ' 07:00:00', new DateTimeZone('Asia/Makassar'));

if ($now < $today7am) {
  $absenDate = (clone $today7am)->modify('-1 day');
} else {
  $absenDate = $today7am;
}

$absenDateFormatted = $absenDate->format('Y-m-d'); // untuk ajax
$absenDateDisplay   = $absenDate->format('d M Y'); // untuk tampilan

$title = "Dashboard - Absensi";
require "template/header.php";
require "template/navbar.php";
require "template/sidebar.php";
?>

<style>
  /* Reminder popup tengah layar */
  #reminder-popup {
    position: fixed;
    top: 50%;
    left: 50%;
    max-width: 360px;
    background: #333;
    color: #fff;
    padding: 20px 25px 30px 25px;
    /* ruang bawah utk tombol */
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.4);
    font-size: 15px;
    z-index: 2000;
    font-style: normal;
    transform: translate(-50%, -50%);
    box-sizing: border-box;
  }

  #reminder-popup strong {
    color: #f0ad4e;
    /* highlight warna */
  }

  #reminder-popup .close-btn {
    position: absolute;
    top: 10px;
    right: 12px;
    background: transparent;
    border: none;
    color: #fff;
    font-weight: bold;
    font-size: 22px;
    cursor: pointer;
    line-height: 1;
    padding: 0;
  }

  #reminder-popup .close-btn:hover {
    color: #f0ad4e;
  }
</style>

<div class="content-wrapper p-3">
  <h1>Dashboard</h1>
  <p><strong>Tanggal:</strong> <?= $absenDateDisplay ?></p>

  <div id="reminder-popup" style="display:none;">
    <button class="close-btn" title="Tutup Reminder">&times;</button>
    <div class="content"></div>
  </div>

  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Grafik Kehadiran per Shift & Area</h3>
    </div>
    <div class="card-body">
      <canvas id="chartKehadiran" style="max-height: 350px;"></canvas>
      <div id="error-message" style="color:red; margin-top:10px;"></div>
    </div>
  </div>
</div>

<?php require "template/footer.php"; ?>

<!-- Chart.js & jQuery -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Plugin datalabels -->
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>

<script>
  $(document).ready(function() {
    const reminderPopup = $('#reminder-popup');
    const reminderContent = reminderPopup.find('.content');

    // Tombol close tetap berfungsi untuk sembunyikan popup tapi reminder akan muncul lagi otomatis
    reminderPopup.find('.close-btn').off('click').on('click', function() {
      reminderPopup.fadeOut();
    });

    const shiftLabels = ['Shift 1', 'Shift 2'];
    const areaColors = {
      "Halte Km 98": "#E74C3C",
      "Dispatch Km 38 MP": "#2980B9",
      "Dispatch Km 38 SN": "#F39C12",
      "Halte Km 6 SN": "#16A085",
      "Halte Km 10 MP": "#8E44AD",
      "WB Km 10 MP": "#D35400",
      "WB Km 6 SN": "#7F8C8D"
    };

    const areaList = [
      "Halte Km 98",
      "Dispatch Km 38 MP",
      "Dispatch Km 38 SN",
      "Halte Km 6 SN",
      "Halte Km 10 MP",
      "WB Km 10 MP",
      "WB Km 6 SN"
    ];

    function isNightShiftNow() {
      const now = new Date();
      const hour = now.getHours();
      return (hour >= 19 || hour < 7);
    }

    function isDayShiftNow() {
      const now = new Date();
      const hour = now.getHours();
      return (hour >= 7 && hour < 19);
    }

    function getMissingShifts(data) {
      let missing = [];

      if (isNightShiftNow()) {
        // Shift malam: cek Shift 2 dan Shift 1
        areaList.forEach(area => {
          const shift2Filled = data.find(e => e.shift === 'Shift 2' && e.area_kerja === area && parseInt(e.jumlah) > 0);
          if (!shift2Filled) {
            missing.push({
              shift: 'Shift 2',
              area
            });
          }
          const shift1Filled = data.find(e => e.shift === 'Shift 1' && e.area_kerja === area && parseInt(e.jumlah) > 0);
          if (!shift1Filled) {
            missing.push({
              shift: 'Shift 1',
              area
            });
          }
        });
      } else if (isDayShiftNow()) {
        // Shift siang: cek hanya Shift 1
        areaList.forEach(area => {
          const found = data.find(e => e.shift === 'Shift 1' && e.area_kerja === area && parseInt(e.jumlah) > 0);
          if (!found) {
            missing.push({
              shift: 'Shift 1',
              area
            });
          }
        });
      }

      return missing;
    }

    function updateReminder(data) {
      console.log("Data masuk updateReminder:", data);

      // Kalau response bukan array, kemungkinan pesan debug dari server
      if (!Array.isArray(data)) {
        if (data.debug) {
          reminderContent.html('<strong>Reminder:</strong><br>Belum ada absen sama sekali hari ini!');
          reminderPopup.fadeIn();
          return false;
        } else {
          reminderPopup.fadeOut();
          return true;
        }
      }

      if (data.length === 0) {
        reminderContent.html('<strong>Reminder:</strong><br>Belum ada absen sama sekali hari ini!');
        reminderPopup.fadeIn();
        return false;
      }

      const totalJumlah = data.reduce((sum, e) => sum + (parseInt(e.jumlah) || 0), 0);
      if (totalJumlah === 0) {
        reminderContent.html('<strong>Reminder:</strong><br>Belum ada absen sama sekali hari ini!');
        reminderPopup.fadeIn();
        return false;
      }

      const missing = getMissingShifts(data);

      if (missing.length === 0) {
        reminderPopup.fadeOut();
        return true;
      }

      const lines = missing.map(item => `<strong>${item.shift}</strong> di <strong>${item.area}</strong> belum mengisi absen`);
      reminderContent.html('<strong>Reminder:</strong><br>' + lines.join('<br>'));
      reminderPopup.fadeIn();

      return false;
    }

    function updateChart(data) {
      const datasets = areaList.map(area => {
        const baseColor = areaColors[area] || '#999999';
        const barColor = shadeColor(baseColor, -40);
        return {
          label: area,
          backgroundColor: barColor,
          borderColor: baseColor,
          borderWidth: 1,
          data: shiftLabels.map(shift => {
            const match = data.find(e => e.shift === shift && e.area_kerja === area);
            return match ? parseInt(match.jumlah) : 0;
          }),
        };
      });

      if (window.myChart) window.myChart.destroy();

      const ctx = document.getElementById('chartKehadiran').getContext('2d');
      window.myChart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: shiftLabels,
          datasets: datasets
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              display: false
            },
            datalabels: {
              display: true,
              color: 'white',
              font: {
                weight: 'bold',
                size: 14
              },
              anchor: 'end',
              align: 'start',
              rotation: -90,
              formatter: function(value, ctx) {
                return ctx.dataset.label;
              },
              padding: 4
            },
            title: {
              display: true,
              text: 'Kehadiran Hari Ini per Area & Shift (07:00–06:59 WITA)'
            }
          },
          scales: {
            x: {
              stacked: false,
              ticks: {
                display: true,
                font: {
                  weight: 'bold'
                }
              }
            },
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: 'Jumlah Hadir'
              }
            }
          }
        },
        plugins: [ChartDataLabels]
      });
    }

    function shadeColor(color, percent) {
      let f = parseInt(color.slice(1), 16),
        t = percent < 0 ? 0 : 255,
        p = Math.abs(percent) / 100,
        R = f >> 16,
        G = (f >> 8) & 0x00FF,
        B = f & 0x0000FF;
      return "#" + (0x1000000 +
        (Math.round((t - R) * p) + R) * 0x10000 +
        (Math.round((t - G) * p) + G) * 0x100 +
        (Math.round((t - B) * p) + B)
      ).toString(16).slice(1);
    }

    let reminderVisible = false;
    let toggleInterval = 5000; // 5 detik muncul
    let toggleTimeout;

    function toggleReminderVisibility() {
      if (reminderVisible) {
        reminderPopup.fadeOut();
        reminderVisible = false;
        toggleInterval = 30000; // 30 detik hilang
      } else {
        reminderPopup.fadeIn();
        reminderVisible = true;
        toggleInterval = 30000; // 30 detik muncul
      }
      toggleTimeout = setTimeout(toggleReminderVisibility, toggleInterval);
    }

    function loadData() {
      $.ajax({
        url: 'data_absen.php',
        dataType: 'json',
        method: 'GET',
        data: {
          tanggal: '<?= $absenDateFormatted ?>'
        },
        success: function(data) {
          $('#error-message').text('');
          const semuaTerisi = updateReminder(data);
          updateChart(data);

          if (semuaTerisi) {
            clearTimeout(toggleTimeout);
            reminderPopup.fadeOut();
          } else if (!toggleTimeout) {
            toggleReminderVisibility();
          }
        },
        error: function(xhr, status, error) {
          $('#error-message').text('Gagal memuat data kehadiran: ' + error);
          reminderPopup.hide();
        }
      });
    }

    loadData();
    setInterval(loadData, 30000); // refresh tiap 30 detik
  });
</script>