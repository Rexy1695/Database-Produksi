<?php
include 'config.php';
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['nik']) || $_SESSION['jabatan'] !== 'admin') {
    die("Akses ditolak. Anda bukan admin.");
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID tidak valid.");
}

$id = intval($_GET['id']); // aman untuk integer

$query = "DELETE FROM absensi WHERE id = $id LIMIT 1";
$result = mysqli_query($koneksi, $query);

if (!$result) {
    die("Gagal menghapus data absensi: " . mysqli_error($koneksi));
} else {
    header("Location: laporan.php?msg=hapus_berhasil");
    exit;
}
