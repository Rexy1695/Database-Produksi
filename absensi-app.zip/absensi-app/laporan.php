<?php
include 'config.php';
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['nik'])) {
  header("Location: login.php");
  exit;
}

// Ambil filter dari GET
$start  = $_GET['start_date'] ?? date('Y-m-d', strtotime('-2 days'));
$end    = $_GET['end_date'] ?? date('Y-m-d');
$search = $_GET['search'] ?? '';

$user_nik     = $_SESSION['nik'];
$user_jabatan = $_SESSION['jabatan'] ?? '';

require "template/header.php";
require "template/navbar.php";
require "template/sidebar.php";

// Pagination setup
$limit  = 10;
$page   = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;

// Amankan input untuk query
$start_esc  = mysqli_real_escape_string($koneksi, $start);
$end_esc    = mysqli_real_escape_string($koneksi, $end);
$search_esc = mysqli_real_escape_string($koneksi, $search);

// Buat filter search SQL
$search_sql = '';
if (!empty($search_esc)) {
  $search_sql = "AND (a.nik LIKE '%$search_esc%' OR u.nama LIKE '%$search_esc%' OR a.area_kerja LIKE '%$search_esc%')";
}

// Hitung total data
if ($user_jabatan == 'admin') {
  $count_sql = "SELECT COUNT(*) as total FROM absensi a
                  JOIN users u ON a.nik = u.nik
                  WHERE a.tanggal_kerja BETWEEN '$start_esc' AND '$end_esc' $search_sql";
} else {
  $count_sql = "SELECT COUNT(*) as total FROM absensi a
                  JOIN users u ON a.nik = u.nik
                  WHERE a.tanggal_kerja BETWEEN '$start_esc' AND '$end_esc'
                    AND a.nik = '$user_nik' $search_sql";
}
$count_res = mysqli_query($koneksi, $count_sql);
$total_rows = mysqli_fetch_assoc($count_res)['total'];
$total_pages = ceil($total_rows / $limit);

// Ambil data absensi dengan limit dan filter
if ($user_jabatan == 'admin') {
  $query = "SELECT a.id, a.nik, u.nama, a.tanggal_kerja, a.shift, a.area_kerja
              FROM absensi a
              JOIN users u ON a.nik = u.nik
              WHERE a.tanggal_kerja BETWEEN '$start_esc' AND '$end_esc' $search_sql
              ORDER BY a.tanggal_kerja ASC
              LIMIT $limit OFFSET $offset";
} else {
  $query = "SELECT a.id, a.nik, u.nama, a.tanggal_kerja, a.shift, a.area_kerja
              FROM absensi a
              JOIN users u ON a.nik = u.nik
              WHERE a.tanggal_kerja BETWEEN '$start_esc' AND '$end_esc'
                AND a.nik = '$user_nik' $search_sql
              ORDER BY a.tanggal_kerja ASC
              LIMIT $limit OFFSET $offset";
}

$result = mysqli_query($koneksi, $query);
?>

<div class="content-wrapper p-3">
  <h2>Laporan Absensi</h2>

  <?php if (isset($_GET['msg']) && $_GET['msg'] === 'hapus_berhasil'): ?>
    <div class="alert alert-success">Data absensi berhasil dihapus.</div>
  <?php endif; ?>

  <form method="GET" class="d-flex align-items-center mb-3 flex-wrap" style="gap:10px;">
    <label class="mb-0" for="start_date">Dari:</label>
    <input type="date" name="start_date" id="start_date" value="<?= htmlspecialchars($start) ?>" class="form-control" style="width: 130px;" required>

    <label class="mb-0" for="end_date">Sampai:</label>
    <input type="date" name="end_date" id="end_date" value="<?= htmlspecialchars($end) ?>" class="form-control" style="width: 130px;" required>

    <input type="text" name="search" placeholder="Cari NIK / Nama / Lokasi" value="<?= htmlspecialchars($search) ?>" class="form-control" style="width: 200px; min-width: 150px;">

    <button type="submit" class="btn btn-primary" style="white-space: nowrap;">
      <i class="fas fa-filter"></i> Tampilkan
    </button>

    <a href="export_excel.php?start_date=<?= urlencode($start) ?>&end_date=<?= urlencode($end) ?>&search=<?= urlencode($search) ?>"
      target="_blank"
      class="btn btn-success" style="white-space: nowrap;">
      <i class="fas fa-file-excel"></i> Export Excel
    </a>


    <a href="<?= basename($_SERVER['PHP_SELF']) ?>" class="btn btn-secondary" style="white-space: nowrap;">
      <i class="fas fa-times"></i> Clear Filter
    </a>
  </form>

  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Data Absensi (<?= htmlspecialchars($start) ?> s.d <?= htmlspecialchars($end) ?>)</h3>
    </div>
    <div class="card-body table-responsive p-0">
      <table class="table table-hover text-nowrap">
        <thead>
          <tr>
            <th>Tanggal</th>
            <th>NIK</th>
            <th>Nama</th>
            <th>Shift</th>
            <th>Area Kerja</th>
            <?php if ($user_jabatan == 'admin'): ?>
              <th>Aksi</th>
            <?php endif; ?>
          </tr>
        </thead>
        <tbody>
          <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
              <tr>
                <td><?= htmlspecialchars($row['tanggal_kerja']) ?></td>
                <td><?= htmlspecialchars($row['nik']) ?></td>
                <td><?= htmlspecialchars($row['nama']) ?></td>
                <td><?= htmlspecialchars($row['shift']) ?></td>
                <td><?= htmlspecialchars($row['area_kerja']) ?></td>
                <?php if ($user_jabatan == 'admin'): ?>
                  <td>
                    <a href="hapus_absen.php?id=<?= $row['id'] ?>"
                      onclick="return confirm('Yakin ingin menghapus data ini?');"
                      class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Hapus</a>
                  </td>
                <?php endif; ?>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr>
              <td colspan="<?= $user_jabatan == 'admin' ? 6 : 5 ?>" class="text-center">Tidak ada data absensi.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <div class="card-footer text-center">
      <ul class="pagination pagination-sm justify-content-center m-0">
        <?php
        $url = basename($_SERVER['PHP_SELF']) . "?start_date=" . urlencode($start) . "&end_date=" . urlencode($end) . "&search=" . urlencode($search);
        if ($page > 1) {
          echo '<li class="page-item"><a class="page-link" href="' . $url . '&page=' . ($page - 1) . '">«</a></li>';
        }
        for ($i = 1; $i <= $total_pages; $i++) {
          $active = ($i == $page) ? 'active' : '';
          echo '<li class="page-item ' . $active . '"><a class="page-link" href="' . $url . '&page=' . $i . '">' . $i . '</a></li>';
        }
        if ($page < $total_pages) {
          echo '<li class="page-item"><a class="page-link" href="' . $url . '&page=' . ($page + 1) . '">»</a></li>';
        }
        ?>
      </ul>
    </div>
  </div>
</div>

<?php require "template/footer.php"; ?>