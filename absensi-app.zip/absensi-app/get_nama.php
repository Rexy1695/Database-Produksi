<?php
include 'config.php';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['nik'])) {
  $nik = $_POST['nik'];
  $stmt = $koneksi->prepare("SELECT nama FROM users WHERE nik = ?");
  $stmt->bind_param('s', $nik);
  $stmt->execute();
  $stmt->bind_result($nama);
  echo $stmt->fetch() ? $nama : '';
}
