<?php
include 'config.php';
session_start();

$isAdmin = isset($_SESSION['jabatan']) && $_SESSION['jabatan'] === 'admin';
$title = "Laporan Kehadiran WA";

require "template/header.php";
require "template/navbar.php";
require "template/sidebar.php";

function formatTanggalIndo($tanggal)
{
    $bulan = [
        1 => 'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    ];
    $parts = explode('-', $tanggal);
    return (int)$parts[2] . ' ' . $bulan[(int)$parts[1]] . ' ' . $parts[0];
}

if (!$isAdmin) {
    $showAlert = true;
} else {
    $showAlert = false;

    $tanggalDipilih = $_GET['tanggal'] ?? date('Y-m-d');
    $reportText = '';
    $totalRows = 0;

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggalDipilih)) {
        die("Format tanggal tidak valid.");
    }

    $shiftList = ['Shift 1', 'Shift 2'];
    $areaKerjaList = [];

    $areaQuery = $koneksi->query("SELECT DISTINCT area_kerja FROM absensi ORDER BY area_kerja");
    while ($row = $areaQuery->fetch_assoc()) {
        $areaKerjaList[] = $row['area_kerja'];
    }

    if ($_GET) {
        $stmt = $koneksi->prepare("
            SELECT a.area_kerja, a.shift, u.nama
            FROM absensi a
            JOIN users u ON u.nik = a.nik
            WHERE DATE(a.tanggal_kerja) = ?
            ORDER BY a.shift, a.area_kerja, u.nama
        ");

        if (!$stmt) {
            echo '<div class="alert alert-danger">Query prepare error: ' . $koneksi->error . '</div>';
        } else {
            $stmt->bind_param('s', $tanggalDipilih);
            $stmt->execute();
            $res = $stmt->get_result();

            $data = [];
            $totalRows = $res->num_rows;

            while ($row = $res->fetch_assoc()) {
                $shift = $row['shift'];
                $area = $row['area_kerja'];
                $nama = $row['nama'];

                if (!isset($data[$shift][$area])) {
                    $data[$shift][$area] = [];
                }
                $data[$shift][$area][] = $nama;
            }

            $tanggalFormatted = formatTanggalIndo($tanggalDipilih);
            $reportText .= "*Laporan Kehadiran — $tanggalFormatted*\n\n";

            foreach ($shiftList as $shift) {
                $reportText .= "*$shift*\n";

                foreach ($areaKerjaList as $area) {
                    if (isset($data[$shift][$area]) && count($data[$shift][$area]) > 0) {
                        $namaList = implode(' & ', $data[$shift][$area]);
                        $reportText .= "• $area: $namaList\n";
                    } else {
                        $reportText .= "• $area: -\n";
                    }
                }

                $reportText .= "\n";
            }
        }
    }
}
?>

<div class="content-wrapper p-3">
    <h1><?= $title ?></h1>

    <?php if ($showAlert): ?>
        <div id="alert-notification" class="alert alert-danger alert-dismissible fade show" role="alert"
            style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
                z-index: 9999; min-width: 300px; max-width: 90%; text-align: center;">
            Anda tidak berhak mengakses halaman ini
        </div>
        <script>
            setTimeout(() => {
                const alertElem = document.getElementById('alert-notification');
                if (alertElem) {
                    alertElem.classList.remove('show');
                    setTimeout(() => alertElem.remove(), 500);
                }
            }, 10000);
        </script>
    <?php endif; ?>

    <?php if ($isAdmin): ?>
        <form method="get" class="form-inline mb-3">
            <label for="tanggal" class="mr-2">Pilih Tanggal:</label>
            <input type="date" id="tanggal" name="tanggal" value="<?= htmlspecialchars($tanggalDipilih) ?>" class="form-control mr-2" required>
            <button type="submit" class="btn btn-primary">Tampilkan</button>
        </form>

        <div>
            <p><strong>Tanggal dipilih:</strong> <?= htmlspecialchars(formatTanggalIndo($tanggalDipilih)) ?></p>
            <p><strong>Total data absensi ditemukan:</strong> <?= $totalRows ?></p>
        </div>

        <button type="button" class="btn btn-secondary mb-2" onclick="copyReport()">Salin Teks</button>
        <textarea rows="15" class="form-control" readonly id="reportText" onclick="this.select()"><?= htmlspecialchars($reportText) ?></textarea>

        <script>
            function copyReport() {
                const textarea = document.getElementById('reportText');
                textarea.select();
                document.execCommand('copy');
                alert('Laporan disalin ke clipboard!');
            }
        </script>
    <?php else: ?>
        <p class="text-muted">Silakan hubungi administrator jika Anda memerlukan akses.</p>
    <?php endif; ?>
</div>

<?php require "template/footer.php"; ?>