<?php
$current_page = basename($_SERVER['PHP_SELF']);
$nama_user = $_SESSION['nama'] ?? 'Guest';
?>
<nav class="main-header navbar navbar-expand navbar-white navbar-light" id="main-navbar">
  <div class="container-fluid d-flex justify-content-between align-items-center flex-wrap">

    <!-- KIRI: Burger + menu dinamis -->
    <ul class="navbar-nav nav-main-menu d-flex align-items-center flex-wrap">
      <!-- Burger Button: SELALU TAMPIL -->
      <li class="nav-item">
        <a href="#" id="toggleSidebarBtn" class="nav-link" style="z-index:1051;"><i class="fas fa-bars"></i></a>
      </li>

      <!-- Dynamic items (hanya tampil saat navbar-only) -->
      <li class="nav-item dynamic-item">
        <a href="index.php" class="nav-link <?= ($current_page == 'index.php') ? 'active' : '' ?>">Dashboard</a>
      </li>
      <li class="nav-item dynamic-item">
        <a href="users.php" class="nav-link <?= ($current_page == 'users.php') ? 'active' : '' ?>">Users</a>
      </li>
      <li class="nav-item dynamic-item">
        <a href="absen.php" class="nav-link <?= ($current_page == 'absen.php') ? 'active' : '' ?>">Absen</a>
      </li>
      <li class="nav-item dynamic-item">
        <a href="laporan.php" class="nav-link <?= ($current_page == 'laporan.php') ? 'active' : '' ?>">Laporan</a>
      </li>
      <li class="nav-item dynamic-item">
        <a href="report_wa.php" class="nav-link <?= ($current_page == 'report_wa.php') ? 'active' : '' ?>">Laporan Wa</a>
      </li>
    </ul>


    <!-- KANAN: User + Logout (hanya tampil di navbar-only) -->
    <ul class="navbar-nav ml-auto d-flex align-items-center dynamic-item">
      <li class="nav-item">
        <span class="nav-link"><i class="fas fa-user"></i> <?= htmlspecialchars($nama_user) ?></span>
      </li>
      <li class="nav-item">
        <a href="logout.php" class="nav-link text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </li>
    </ul>

  </div>
</nav>