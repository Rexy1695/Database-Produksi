<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= $title ?? 'Absensi' ?></title>

  <!-- CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

  <!-- JS -->
  <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <!-- Favicon -->
  <link rel="icon" type="image/x-icon" href="<?= $main_url ?>/asset/logo.png">

  <!-- Mode Sidebar/Navbar: pasang class sebelum halaman tampil -->
  <script>
    const savedMode = localStorage.getItem('mode');
    if (savedMode === 'sidebar') {
      document.documentElement.classList.add('sidebar-only');
    } else {
      document.documentElement.classList.add('navbar-only');
    }
  </script>

  <!-- STYLE PERBAIKAN LENGKAP -->
  <style>
    /* Sidebar hilang saat navbar-only */
    body.navbar-only .main-sidebar {
      display: none !important;
    }

    /* Navbar melebar penuh saat sidebar tidak aktif */
    body.navbar-only .main-header {
      width: 100% !important;
      margin-left: 0 !important;
      left: 0 !important;
    }

    /* Sidebar aktif: navbar menyesuaikan */
    body.sidebar-only .main-header {
      width: calc(100% - 250px);
      margin-left: 250px;
    }

    /* Konten bergeser sesuai mode */
    body.navbar-only .content-wrapper {
      margin-left: 0 !important;
    }

    body.sidebar-only .content-wrapper {
      margin-left: 250px !important;
    }

    /* Transisi layout dan fade-in halaman */
    .main-header,
    .content-wrapper {
      transition: all 0.3s ease-in-out;
    }

    body {
      opacity: 0;
      transition: opacity 0.3s ease;
    }

    body.fade-in {
      opacity: 1;
    }

    /* Sembunyikan semua isi navbar kecuali burger saat sidebar aktif */
    body.sidebar-only .nav-main-menu .dynamic-item,
    body.sidebar-only .navbar-nav.ml-auto {
      display: none !important;
    }

    /* Burger button jangan pernah disembunyikan */
    body.sidebar-only .nav-main-menu .nav-item:first-child {
      display: block !important;
    }

    /* Responsive layout */
    .navbar-nav .nav-item {
      margin-right: 0.5rem;
      margin-bottom: 0.3rem;
    }

    .navbar-nav,
    .container-fluid {
      flex-wrap: wrap !important;
    }

    /* Pastikan burger di atas sidebar */
    #toggleSidebarBtn {
      z-index: 1051 !important;
      position: relative;
    }

    @media (max-width: 768px) {
      body.sidebar-only .main-sidebar {
        display: block !important;
        position: fixed;
        z-index: 1050;
        width: 250px;
        left: 0;
        top: 0;
        height: 100%;
        background-color: #343a40;
      }

      body.sidebar-only .content-wrapper,
      body.sidebar-only .main-header {
        margin-left: 0 !important;
        width: 100% !important;
      }
    }
  </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed" id="body">
  <div class="wrapper">