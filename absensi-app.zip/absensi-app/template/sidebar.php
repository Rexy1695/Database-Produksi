<?php
// sidebar.php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<aside class="main-sidebar sidebar-dark-primary elevation-4" id="main-sidebar">
  <!-- Brand Logo -->
  <a href="index.php" class="brand-link">
    <img src="asset/logo.png" alt="Logo" class="brand-image" style="opacity: .8">
    <span class="brand-text font-weight-light">CCR Absensi</span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex align-items-center">
      <div class="image">
        <i class="fas fa-user-circle fa-2x text-white"></i>
      </div>
      <div class="info ml-2">
        <a href="#" class="d-block text-white">
          <?= htmlspecialchars($_SESSION['nama'] ?? 'Guest') ?>
        </a>
      </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
        <li class="nav-item">
          <a href="index.php" class="nav-link <?= ($current_page == 'index.php') ? 'active' : '' ?>">
            <i class="nav-icon fas fa-home"></i>
            <p>Dashboard</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="users.php" class="nav-link <?= ($current_page == 'users.php') ? 'active' : '' ?>">
            <i class="nav-icon fas fa-users"></i>
            <p>Users</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="absen.php" class="nav-link <?= ($current_page == 'absen.php') ? 'active' : '' ?>">
            <i class="nav-icon fas fa-calendar-check"></i>
            <p>Absen</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="laporan.php" class="nav-link <?= ($current_page == 'laporan.php') ? 'active' : '' ?>">
            <i class="nav-icon fas fa-file-alt"></i>
            <p>Laporan</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="report_wa.php" class="nav-link <?= ($current_page == 'report_wa.php') ? 'active' : '' ?>">
            <i class="nav-icon fas fa-brands fa-whatsapp"></i>
            <p>Report To Wa</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="logout.php" class="nav-link <?= ($current_page == 'logout.php') ? 'active' : '' ?>">
            <i class="nav-icon fas fa-power-off"></i>
            <p>Logout</p>
          </a>
        </li>
      </ul>
    </nav>
  </div>
</aside>