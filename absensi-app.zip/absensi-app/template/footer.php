<footer class="main-footer text-center">
    <?= date('Y') ?> &copy; CCR Departemen
</footer>

<!-- JS Library -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

<!-- Script Sidebar Toggle & Transisi -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const body = document.body;
        const toggleBtn = document.getElementById('toggleSidebarBtn');
        const sidebar = document.querySelector('.main-sidebar');

        const isMobile = () => window.innerWidth <= 768;

        // Set mode awal dari localStorage
        const savedMode = localStorage.getItem('mode');
        if (savedMode === 'sidebar') {
            body.classList.add('sidebar-only');
            if (isMobile()) body.classList.add('sidebar-open');
        } else {
            body.classList.add('navbar-only');
            body.classList.remove('sidebar-open');
        }

        // Toggle sidebar <-> navbar
        if (toggleBtn) {
            toggleBtn.addEventListener('click', () => {
                const isSidebar = body.classList.contains('sidebar-only');
                if (isSidebar) {
                    body.classList.remove('sidebar-only', 'sidebar-open');
                    body.classList.add('navbar-only');
                    localStorage.setItem('mode', 'navbar');
                } else {
                    body.classList.remove('navbar-only');
                    body.classList.add('sidebar-only');
                    if (isMobile()) body.classList.add('sidebar-open');
                    localStorage.setItem('mode', 'sidebar');
                }
            });
        }

        // Klik di luar sidebar → tutup sidebar & kembalikan navbar
        document.addEventListener('click', function(e) {
            const isSidebarActive = body.classList.contains('sidebar-only') && body.classList.contains('sidebar-open');

            if (
                isMobile() &&
                isSidebarActive &&
                !sidebar.contains(e.target) && // bukan klik sidebar
                !e.target.closest('#toggleSidebarBtn') // bukan klik burger
            ) {
                body.classList.remove('sidebar-open', 'sidebar-only');
                body.classList.add('navbar-only');
                localStorage.setItem('mode', 'navbar');
            }
        });

        // Efek transisi antar halaman
        body.classList.add('fade-in');
        document.querySelectorAll('a[href]').forEach(link => {
            const isInternal = link.hostname === window.location.hostname;
            link.addEventListener('click', function(e) {
                if (isInternal && !link.href.includes('#') && !link.target) {
                    e.preventDefault();
                    body.classList.remove('fade-in');
                    body.style.opacity = 0;
                    setTimeout(() => {
                        window.location.href = link.href;
                    }, 200);
                }
            });
        });

        // Responsif saat resize layar
        window.addEventListener('resize', () => {
            if (body.classList.contains('sidebar-only')) {
                if (isMobile()) {
                    body.classList.add('sidebar-open');
                } else {
                    body.classList.remove('sidebar-open');
                }
            }
        });
    });
</script>

<!-- Efek Fade Transisi -->
<style>
    body {
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    body.fade-in {
        opacity: 1;
    }
</style>
</body>

</html>