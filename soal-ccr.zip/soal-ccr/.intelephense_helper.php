<?php
// File ini hanya untuk membantu VS Code mengenali variabel global
$koneksi = new mysqli();