<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */

// 1. Cek keamanan: Pastikan user sudah login
if (!isset($_SESSION['user'])) {
    header("Location: ../otentikasi/login.php");
    exit;
}

// ==========================================
// OPSI A: HAPUS SEMUA DATA (aksi=semua)
// ==========================================
if (isset($_GET['aksi']) && $_GET['aksi'] === 'semua') {
    
    // Ambil semua gambar soal untuk dibersihkan dari direktori server
    $query_gambar = mysqli_query($koneksi, "SELECT gambar FROM tbl_soal WHERE gambar IS NOT NULL AND gambar != ''");
    while ($data = mysqli_fetch_assoc($query_gambar)) {
        $path_gambar = "../assets/img/soal/" . $data['gambar'];
        if (file_exists($path_gambar)) {
            unlink($path_gambar);
        }
    }

    // Kosongkan tabel soal
    $truncate = mysqli_query($koneksi, "TRUNCATE TABLE tbl_soal");

    if ($truncate) {
        header("Location: data_soal.php?status=berhasil&pesan=Semua soal dan berkas gambar berhasil dikosongkan.");
    } else {
        header("Location: data_soal.php?status=gagal&pesan=Gagal mengosongkan bank soal: " . mysqli_error($koneksi));
    }
    exit();
}

// ==========================================
// OPSI B: HAPUS SATUAN BERSARKAN ID (?id=...)
// ==========================================
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);

    // Ambil nama file gambar terlebih dahulu sebelum datanya dihapus
    $cek_gambar = mysqli_query($koneksi, "SELECT gambar FROM tbl_soal WHERE id = '$id'");
    if ($cek_gambar && mysqli_num_rows($cek_gambar) > 0) {
        $data = mysqli_fetch_assoc($cek_gambar);
        $nama_gambar = $data['gambar'];

        // Jika ada file gambar, hapus dari direktori server
        if (!empty($nama_gambar)) {
            $path_gambar = "../assets/img/soal/" . $nama_gambar;
            if (file_exists($path_gambar)) {
                unlink($path_gambar);
            }
        }
    }

    // Eksekusi perintah hapus baris di database
    $query = mysqli_query($koneksi, "DELETE FROM tbl_soal WHERE id = '$id'");

    if ($query) {
        header("Location: data_soal.php?status=berhasil&pesan=Soal berhasil dihapus.");
    } else {
        $error = mysqli_error($koneksi);
        header("Location: data_soal.php?status=gagal&pesan=Gagal menghapus data: " . urlencode($error));
    }
    exit();
}

// Jika diakses tanpa parameter id maupun aksi, lempar kembali ke halaman utama
header("Location: data_soal.php");
exit();
?>