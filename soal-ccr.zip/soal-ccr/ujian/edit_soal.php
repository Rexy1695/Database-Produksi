<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */

if (!isset($_SESSION['user'])) {
    header("Location: ../otentikasi/login.php");
    exit;
}

// 1. Ambil ID dari URL dan bersihkan dari spasi
$id = isset($_GET['id']) ? trim(mysqli_real_escape_string($koneksi, $_GET['id'])) : '';

if (empty($id)) {
    echo "<script>alert('Akses Ditolak: Parameter ID tidak ditemukan!'); window.location='data_soal.php';</script>";
    exit;
}

// 2. Gunakan TRIM(id) untuk mengabaikan spasi tersembunyi di database
$query = mysqli_query($koneksi, "SELECT * FROM tbl_soal WHERE TRIM(id) = '$id'");
$d = mysqli_fetch_assoc($query);

// 3. Jika data tetap tidak lolos (Antisipasi berlapis)
if (!$d) {
    echo "<script>alert('Data tidak ditemukan! Silakan muat ulang halaman data soal.'); window.location='data_soal.php';</script>";
    exit;
}

// 4. Standarisasi Tipe Soal dan Kunci untuk menghindari bug spasi di komponen form
$tipe_soal = strtoupper(trim($d['tipe_soal'] ?? ''));
$kunci_jawaban = strtoupper(trim($d['kunci'] ?? ''));

$title = "Project Control - Edit Soal";
require "../template/header.php";
require "../template/navbar.php";
require "../template/sidebar.php";
?>

<div class="page-wrapper">
    <div class="container-fluid pt-4">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0 fw-bold text-primary">
                    <i class="fas fa-edit me-2"></i> Edit Soal [<?= htmlspecialchars($tipe_soal) ?>]
                </h5>
            </div>
            <div class="card-body">
                <form action="proses_edit_soal.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?= htmlspecialchars($d['id']) ?>">
                    <input type="hidden" name="tipe_soal" value="<?= htmlspecialchars($tipe_soal) ?>">
                    <input type="hidden" name="gambar_base64" id="gambar_base64">
                    <!-- Input flag untuk menandai apakah gambar lama dihapus oleh user -->
                    <input type="hidden" name="hapus_gambar_aktif" id="hapus_gambar_aktif" value="0">

                    <div class="row">
                        <!-- KOLOM UTAMA DATA FORM -->
                        <div class="col-md-7">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Kategori</label>
                                <select name="kategori" class="form-select" required>
                                    <option value="Dispatch" <?= trim($d['kategori'] ?? '') == 'Dispatch' ? 'selected' : '' ?>>Dispatch</option>
                                    <option value="Monitoring CCTV" <?= trim($d['kategori'] ?? '') == 'Monitoring CCTV' ? 'selected' : '' ?>>Monitoring CCTV</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Pertanyaan</label>
                                <textarea name="pertanyaan" id="area-pertanyaan" class="form-control" rows="5" placeholder="Klik di sini lalu tekan Ctrl+V untuk paste gambar..." required><?= htmlspecialchars($d['pertanyaan'] ?? '') ?></textarea>
                                <small class="text-danger">*Anda bisa mengganti gambar dengan cara melakukan <b>Paste (Ctrl+V)</b> di dalam kotak ini.</small>
                            </div>

                            <?php if ($tipe_soal == 'PG'): ?>
                                <div class="row">
                                    <div class="col-md-6 mb-2">
                                        <label class="small fw-bold">Opsi A</label>
                                        <input type="text" name="opsi_a" class="form-control" value="<?= htmlspecialchars($d['opsi_a'] ?? '') ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <label class="small fw-bold">Opsi B</label>
                                        <input type="text" name="opsi_b" class="form-control" value="<?= htmlspecialchars($d['opsi_b'] ?? '') ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <label class="small fw-bold">Opsi C</label>
                                        <input type="text" name="opsi_c" class="form-control" value="<?= htmlspecialchars($d['opsi_c'] ?? '') ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <label class="small fw-bold">Opsi D</label>
                                        <input type="text" name="opsi_d" class="form-control" value="<?= htmlspecialchars($d['opsi_d'] ?? '') ?>" required>
                                    </div>
                                    <div class="col-md-12 mt-2">
                                        <label class="fw-bold text-success">Kunci Jawaban</label>
                                        <select name="kunci_pg" class="form-select border-success">
                                            <?php foreach (['A', 'B', 'C', 'D'] as $k): ?>
                                                <option value="<?= $k ?>" <?= $kunci_jawaban == $k ? 'selected' : '' ?>>Pilihan <?= $k ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- KOLOM KANAN PREVIEW MEDIA -->
                        <div class="col-md-5">
                            <label class="form-label fw-bold">Gambar Soal</label>
                            <div class="border rounded p-3 text-center bg-light position-relative">
                                <div id="preview-container">
                                    <?php if (!empty($d['gambar'])): ?>
                                        <img src="../assets/img/soal/<?= $d['gambar'] ?>" id="img-preview" class="img-fluid rounded shadow-sm mb-2" style="max-height: 250px; cursor: pointer;" data-bs-toggle="modal" data-bs-target="#modalPreview" onclick="updateModalSrc(this.src)">
                                        <p id="no-img-text" class="text-muted py-5 d-none">Belum ada gambar</p>
                                    <?php else: ?>
                                        <img id="img-preview" class="img-fluid rounded shadow-sm mb-2 d-none" style="max-height: 250px; cursor: pointer;" data-bs-toggle="modal" data-bs-target="#modalPreview" onclick="updateModalSrc(this.src)">
                                        <p id="no-img-text" class="text-muted py-5">Belum ada gambar</p>
                                    <?php endif; ?>
                                </div>

                                <!-- Tombol Hapus Gambar Dinamis -->
                                <button type="button" id="btn-hapus-gambar" class="btn btn-danger btn-sm w-100 mb-2 <?= empty($d['gambar']) ? 'd-none' : '' ?>" onclick="hapusGambar()">
                                    <i class="fas fa-trash me-1"></i> Hapus Gambar
                                </button>

                                <input type="file" name="gambar_soal" id="gambar_soal" class="form-control mt-2" onchange="previewFile(this)">
                                <small class="text-muted d-block mt-1">Klik gambar untuk memperbesar</small>
                            </div>
                        </div>
                    </div>

                    <div class="mt-4 pt-3 border-top">
                        <button type="submit" name="update" class="btn btn-primary px-5">Simpan Perubahan</button>
                        <a href="data_soal.php" class="btn btn-light border px-4">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- CONTAINER MODAL LIGHTBOX -->
<div class="modal fade" id="modalPreview" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-dark border-0">
            <div class="modal-header border-0">
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center p-0 pb-3">
                <img src="" id="img-modal" class="img-fluid rounded shadow">
            </div>
        </div>
    </div>
</div>

<script>
    function updateModalSrc(src) {
        document.getElementById('img-modal').src = src;
    }

    function previewFile(input) {
        const preview = document.getElementById('img-preview');
        const noImgText = document.getElementById('no-img-text');
        const btnHapus = document.getElementById('btn-hapus-gambar');
        const file = input.files[0];
        const reader = new FileReader();

        reader.onloadend = function() {
            preview.src = reader.result;
            preview.classList.remove('d-none');
            btnHapus.classList.remove('d-none');
            if (noImgText) noImgText.classList.add('d-none');

            // Kosongkan base64 jika user beralih mengunggah file biasa
            document.getElementById('gambar_base64').value = '';
            document.getElementById('hapus_gambar_aktif').value = '0';
        }
        if (file) {
            reader.readAsDataURL(file);
        }
    }

    // Event Handler Paste Gambar dari Clipboard (Ctrl + V)
    document.getElementById('area-pertanyaan').addEventListener('paste', function(e) {
        const items = (e.clipboardData || e.originalEvent.clipboardData).items;
        for (let index in items) {
            const item = items[index];
            if (item.kind === 'file') {
                const blob = item.getAsFile();
                const reader = new FileReader();
                reader.onload = function(event) {
                    const base64Data = event.target.result;
                    const preview = document.getElementById('img-preview');
                    const btnHapus = document.getElementById('btn-hapus-gambar');

                    preview.src = base64Data;
                    preview.classList.remove('d-none');
                    btnHapus.classList.remove('d-none');

                    if (document.getElementById('no-img-text')) {
                        document.getElementById('no-img-text').classList.add('d-none');
                    }

                    document.getElementById('gambar_base64').value = base64Data;
                    document.getElementById('gambar_soal').value = ''; // Reset input file jika ada
                    document.getElementById('hapus_gambar_aktif').value = '0';
                };
                reader.readAsDataURL(blob);
            }
        }
    });

    // Fungsi aksi tombol hapus gambar
    function hapusGambar() {
        const preview = document.getElementById('img-preview');
        const noImgText = document.getElementById('no-img-text');
        const btnHapus = document.getElementById('btn-hapus-gambar');

        // Reset element view
        preview.src = '';
        preview.classList.add('d-none');
        btnHapus.classList.add('d-none');
        if (noImgText) noImgText.classList.remove('d-none');

        // Reset element data value
        document.getElementById('gambar_soal').value = '';
        document.getElementById('gambar_base64').value = '';
        document.getElementById('hapus_gambar_aktif').value = '1'; // Kirim tanda ke PHP backend untuk hapus gambar lama
    }
</script>

<?php require "../template/footer.php"; ?>