<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */

if (!isset($_SESSION['user'])) {
    header("Location: ../otentikasi/login.php");
    exit;
}

$title = "Project Control - Daftar Soal";
require "../template/header.php";
require "../template/navbar.php";
require "../template/sidebar.php";
?>

<div class="page-wrapper">
    <div class="container-fluid pt-4">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h5 class="mb-0 fw-bold text-primary">
                    <i class="fas fa-list-ul me-2"></i> Daftar Soal Tersedia
                </h5>

                <div class="btn-group gap-2">
                    <!-- Tombol Hapus Semua -->
                    <a href="hapus_soal.php?aksi=semua"
                        class="btn btn-danger btn-sm shadow-sm"
                        onclick="return confirm('PERINGATAN!\n\nYakin ingin menghapus SEMUA soal?\nSemua data dan gambar soal akan dihapus permanen!');">
                        <i class="fas fa-trash-alt me-1"></i>
                        Kosongkan Bank Soal
                    </a>

                    <a href="input.php" class="btn btn-primary btn-sm shadow-sm">
                        <i class="fas fa-plus me-1"></i>
                        Tambah Soal
                    </a>
                </div>
            </div>

            <div class="card-body">

                <?php if (isset($_GET['status'])) : ?>
                    <div class="alert <?= ($_GET['status'] == 'berhasil') ? 'alert-success' : 'alert-danger'; ?> alert-dismissible fade show">
                        <?= htmlspecialchars($_GET['pesan']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th width="5%">No</th>
                                <th width="15%">Kategori</th>
                                <th width="10%">Tipe</th>
                                <th>Pertanyaan</th>
                                <th width="10%" class="text-center">Gambar</th>
                                <th width="12%" class="text-center">Aksi</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php
                            $query = mysqli_query(
                                $koneksi,
                                "SELECT * FROM tbl_soal
                             ORDER BY FIELD(tipe_soal,'PG','Essay'), id DESC"
                            );

                            $no = 1;

                            if (mysqli_num_rows($query) > 0) :
                                while ($row = mysqli_fetch_assoc($query)) :
                            ?>

                                    <tr>

                                        <td><?= $no++; ?></td>

                                        <td>
                                            <span class="badge rounded-pill <?= ($row['kategori'] == 'Monitoring CCTV') ? 'bg-warning text-dark' : 'bg-info text-dark'; ?>">
                                                <?= htmlspecialchars($row['kategori']); ?>
                                            </span>
                                        </td>

                                        <td>
                                            <span class="badge <?= ($row['tipe_soal'] == 'PG') ? 'bg-primary' : 'bg-success'; ?>">
                                                <?= htmlspecialchars($row['tipe_soal']); ?>
                                            </span>
                                        </td>

                                        <td>
                                            <div
                                                style="max-width:350px"
                                                class="text-truncate"
                                                title="<?= htmlspecialchars($row['pertanyaan']); ?>">
                                                <?= htmlspecialchars($row['pertanyaan']); ?>
                                            </div>
                                        </td>

                                        <td class="text-center">

                                            <?php if (!empty($row['gambar'])) : ?>

                                                <img
                                                    src="../assets/img/soal/<?= htmlspecialchars($row['gambar']); ?>"
                                                    class="img-thumbnail"
                                                    style="width:50px;height:40px;object-fit:cover;cursor:pointer;"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#modalPreview"
                                                    onclick="previewGambar('../assets/img/soal/<?= htmlspecialchars($row['gambar']); ?>')">

                                            <?php else : ?>

                                                <span class="text-muted small">No Image</span>

                                            <?php endif; ?>

                                        </td>

                                        <td class="text-center">

                                            <div class="btn-group shadow-sm">

                                                <a href="edit_soal.php?id=<?= $row['id']; ?>"
                                                    class="btn btn-warning btn-sm text-white">
                                                    <i class="fas fa-edit"></i>
                                                </a>

                                                <a href="hapus_soal.php?id=<?= $row['id']; ?>"
                                                    class="btn btn-danger btn-sm"
                                                    onclick="return confirm('Yakin ingin menghapus soal ini?');">
                                                    <i class="fas fa-trash"></i>
                                                </a>

                                            </div>

                                        </td>

                                    </tr>

                                <?php
                                endwhile;
                            else :
                                ?>

                                <tr>
                                    <td colspan="6" class="text-center py-4 text-muted">
                                        Belum ada soal yang tersedia.
                                    </td>
                                </tr>

                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Modal Preview -->
<div class="modal fade" id="modalPreview" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-dark border-0">

            <div class="modal-header border-0">
                <button
                    type="button"
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal">
                </button>
            </div>

            <div class="modal-body text-center">
                <img src="" id="img-modal" class="img-fluid rounded">
            </div>

        </div>
    </div>
</div>

<script>
    function previewGambar(src) {
        document.getElementById("img-modal").src = src;
    }
</script>

<?php require "../template/footer.php"; ?>