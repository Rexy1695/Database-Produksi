<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: otentikasi/login.php");
    exit;
}
require "../config.php";
$title = "Project Control - Input Soal";
require "../template/header.php";
require "../template/navbar.php";
require "../template/sidebar.php";
?>

<div class="page-breadcrumb">
    <div class="row align-items-center">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="page-title mb-0 p-0">Input Soal</h3>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <div class="text-end upgrade-btn">
                <a href="data_soal.php" class="btn btn-info text-white">
                    <i class="fas fa-list me-1"></i> Daftar Soal
                </a>
            </div>
        </div>
    </div>
</div>

<div class="page-wrapper">
    <div class="container-fluid pt-4">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white py-3">
                        <h5 class="card-title mb-0 text-white"><i class="fas fa-edit me-2"></i> Tambah Soal Baru</h5>
                    </div>
                    <div class="card-body p-4">

                        <?php if (isset($_GET['status'])) : ?>
                            <div class="alert <?= $_GET['status'] == 'berhasil' ? 'alert-success' : 'alert-danger' ?> alert-dismissible fade show" role="alert">
                                <strong><?= $_GET['status'] == 'berhasil' ? 'Berhasil!' : 'Gagal!' ?></strong> <?= htmlspecialchars($_GET['pesan']) ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <form action="proses_soal.php" method="POST" enctype="multipart/form-data">
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Pilih Kategori</label>
                                    <select class="form-select shadow-none border-2" name="kategori" required>
                                        <option value="" selected disabled>-- Pilih Kategori --</option>
                                        <option value="Dispatch">Dispatch</option>
                                        <option value="Monitoring CCTV">Monitoring CCTV</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Pilih Tipe Soal</label>
                                    <select class="form-select shadow-none border-2" name="tipe_soal" id="tipe_soal" onchange="aturForm()" required>
                                        <option value="" selected disabled>-- Pilih Tipe --</option>
                                        <option value="PG">Pilihan Ganda</option>
                                        <option value="Essay">Essay</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold">Pertanyaan Soal</label>
                                <textarea class="form-control shadow-none" name="pertanyaan" rows="4" placeholder="Tuliskan pertanyaan Anda..." required></textarea>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold text-primary"><i class="fas fa-image me-1"></i> Lampiran Gambar (Opsional)</label>
                                <div class="border p-3 rounded bg-light">
                                    <input type="file" name="gambar_soal" id="gambar_soal" class="form-control mb-2" accept="image/*">
                                    <small class="text-muted">
                                        Tips: Bisa upload file atau <strong>Paste (Ctrl+V)</strong> gambar langsung di halaman ini.
                                    </small>

                                    <div id="preview-container" class="mt-3 d-none text-center">
                                        <img id="img-preview" src="#" alt="Preview" class="img-fluid rounded border shadow-sm" style="max-height: 250px;">
                                        <input type="hidden" name="gambar_base64" id="gambar_base64">
                                        <div class="mt-2">
                                            <button type="button" class="btn btn-sm btn-danger" onclick="hapusGambar()">Hapus Gambar</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div id="area_pg" style="display: none;">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <h6 class="fw-bold text-primary border-bottom pb-2">Opsi Jawaban (A - D)</h6>
                                    </div>
                                    <?php foreach (['A', 'B', 'C', 'D'] as $p) : ?>
                                        <div class="col-md-6">
                                            <div class="input-group mb-2">
                                                <span class="input-group-text bg-light fw-bold"><?= $p ?></span>
                                                <input type="text" class="form-control input-opsi shadow-none" name="opsi_<?= strtolower($p) ?>" placeholder="Jawaban <?= $p ?>">
                                            </div>
                                        </div>
                                    <?php endforeach; ?>

                                    <div class="col-md-4 mt-3">
                                        <label class="form-label fw-bold text-success">Kunci Jawaban Benar</label>
                                        <select class="form-select border-success shadow-none" name="kunci_pg" id="kunci_pg">
                                            <option value="" selected disabled>Pilih Kunci...</option>
                                            <option value="A">A</option>
                                            <option value="B">B</option>
                                            <option value="C">C</option>
                                            <option value="D">D</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div id="area_essay" style="display: none;">
                                <div class="alert alert-light border-start border-info border-4 shadow-sm text-dark">
                                    <i class="fas fa-info-circle text-info me-2"></i> Mode <strong>Essay</strong> aktif. Tidak memerlukan input opsi jawaban.
                                </div>
                            </div>

                            <div class="mt-5 border-top pt-4 text-end">
                                <a href="data_soal.php" class="btn btn-light px-4 me-2 border">Kembali</a>
                                <button type="submit" name="simpan" class="btn btn-primary px-5 shadow">
                                    <i class="fas fa-save me-2"></i> Simpan Soal
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function aturForm() {
        const tipe = document.getElementById('tipe_soal').value;
        const areaPG = document.getElementById('area_pg');
        const areaEssay = document.getElementById('area_essay');
        const inputs = document.querySelectorAll('.input-opsi');
        const kunci = document.getElementById('kunci_pg');

        if (tipe === 'PG') {
            areaPG.style.display = 'block';
            areaEssay.style.display = 'none';
            inputs.forEach(i => i.required = true);
            kunci.required = true;
        } else {
            areaPG.style.display = 'none';
            areaEssay.style.display = 'block';
            inputs.forEach(i => {
                i.required = false;
                i.value = '';
            });
            kunci.required = false;
            kunci.value = '';
        }
    }

    // Handler Paste Gambar dari Clipboard
    document.addEventListener('paste', function(e) {
        const items = (e.clipboardData || e.originalEvent.clipboardData).items;
        for (let index in items) {
            const item = items[index];
            if (item.kind === 'file') {
                const blob = item.getAsFile();
                const reader = new FileReader();
                reader.onload = function(event) {
                    document.getElementById('img-preview').src = event.target.result;
                    document.getElementById('gambar_base64').value = event.target.result;
                    document.getElementById('preview-container').classList.remove('d-none');
                };
                reader.readAsDataURL(blob);
            }
        }
    });

    function hapusGambar() {
        document.getElementById('gambar_soal').value = "";
        document.getElementById('gambar_base64').value = "";
        document.getElementById('preview-container').classList.add('d-none');
    }
</script>

<?php require "../template/footer.php"; ?>