<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */

if (!isset($_SESSION['user'])) {
    header("Location: ../otentikasi/login.php");
    exit;
}

if (isset($_POST['update'])) {
    // 1. Ambil inputan dan bersihkan dengan TRIM
    $id = trim(mysqli_real_escape_string($koneksi, $_POST['id']));
    $kategori = trim(mysqli_real_escape_string($koneksi, $_POST['kategori']));
    $pertanyaan = mysqli_real_escape_string($koneksi, $_POST['pertanyaan']);
    $tipe_soal = strtoupper(trim($_POST['tipe_soal']));
    
    // 2. Validasi awal: Pastikan data lama benar-benar eksis di DB (Gunakan TRIM pada Query)
    $check_query = mysqli_query($koneksi, "SELECT * FROM tbl_soal WHERE TRIM(id) = '$id'");
    $data_lama = mysqli_fetch_assoc($check_query);

    if (!$data_lama) {
        echo "<script>alert('Gagal Menyimpan: Data dengan ID tersebut tidak ditemukan di database!'); window.location='data_soal.php';</script>";
        exit;
    }

    // Menggunakan ID asli dari database hasil query agar sinkron saat UPDATE
    $id_valid = $data_lama['id'];
    $nama_gambar = $data_lama['gambar']; // Default pakai gambar lama jika tidak diganti

    // 3. LOGIC PENGELOLAAN MEDIA GAMBAR (Upload Biasa vs Paste Clipboard Base64)
    if (!empty($_POST['gambar_base64'])) {
        // Jika user mengganti gambar lewat metode Paste (Ctrl+V)
        $base64_string = $_POST['gambar_base64'];
        
        // Hapus file lama jika ada untuk menghemat ruang server
        if (!empty($nama_gambar) && file_exists("../assets/img/soal/" . $nama_gambar)) {
            @unlink("../assets/img/soal/" . $nama_gambar);
        }

        // Dekode data base64 menjadi file fisik .png
        define('UPLOAD_DIR', '../assets/img/soal/');
        $img = str_replace('data:image/png;base64,', '', $base64_string);
        $img = str_replace('data:image/jpeg;base64,', '', $img);
        $img = str_replace(' ', '+', $img);
        $data_dekode = base64_decode($img);
        
        // Generate nama unik baru
        $nama_gambar = "soal_" . time() . "_" . uniqid() . ".png";
        file_put_contents(UPLOAD_DIR . $nama_gambar, $data_dekode);

    } elseif (isset($_FILES['gambar_soal']) && $_FILES['gambar_soal']['error'] === 0) {
        // Jika user mengganti gambar lewat tombol Pilih File konvensional
        $nama_file = $_FILES['gambar_soal']['name'];
        $ukuran_file = $_FILES['gambar_soal']['size'];
        $tmp_name = $_FILES['gambar_soal']['tmp_name'];
        
        $ekstensi_valid = ['jpg', 'jpeg', 'png', 'webp'];
        $ekstensi_file = strtolower(pathinfo($nama_file, PATHINFO_EXTENSION));

        if (in_array($ekstensi_file, $ekstensi_valid)) {
            if ($ukuran_file <= 5 * 1024 * 1024) { // Batas maksimal 5MB
                // Hapus file lama jika ada
                if (!empty($nama_gambar) && file_exists("../assets/img/soal/" . $nama_gambar)) {
                    @unlink("../assets/img/soal/" . $nama_gambar);
                }
                
                // Generate nama file baru
                $nama_gambar = "soal_" . time() . "_" . uniqid() . "." . $ekstensi_file;
                move_uploaded_file($tmp_name, "../assets/img/soal/" . $nama_gambar);
            } else {
                echo "<script>alert('Ukuran file terlalu besar! Maksimal 5MB.'); window.history.back();</script>";
                exit;
            }
        }
    }

    // 4. LOGIC PERUBAHAN BERDASARKAN TIPE SOAL (PG / ESSAY)
    if ($tipe_soal === 'PG') {
        $opsi_a = mysqli_real_escape_string($koneksi, $_POST['opsi_a']);
        $opsi_b = mysqli_real_escape_string($koneksi, $_POST['opsi_b']);
        $opsi_c = mysqli_real_escape_string($koneksi, $_POST['opsi_c']);
        $opsi_d = mysqli_real_escape_string($koneksi, $_POST['opsi_d']);
        $kunci = strtoupper(trim(mysqli_real_escape_string($koneksi, $_POST['kunci_pg'])));

        $update_query = "UPDATE tbl_soal SET 
                            kategori = '$kategori',
                            pertanyaan = '$pertanyaan',
                            opsi_a = '$opsi_a',
                            opsi_b = '$opsi_b',
                            opsi_c = '$opsi_c',
                            opsi_d = '$opsi_d',
                            kunci = '$kunci',
                            gambar = '$nama_gambar'
                         WHERE id = '$id_valid'";
    } else {
        // Jika bertipe Essay / diluar Pilihan Ganda
        $update_query = "UPDATE tbl_soal SET 
                            kategori = '$kategori',
                            pertanyaan = '$pertanyaan',
                            gambar = '$nama_gambar'
                         WHERE id = '$id_valid'";
    }

    // 5. Eksekusi Query Update ke Database
    if (mysqli_query($koneksi, $update_query)) {
        echo "<script>alert('Data soal berhasil diperbarui!'); window.location='data_soal.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui database: " . mysqli_error($koneksi) . "'); window.history.back();</script>";
    }
} else {
    // Jika diakses langsung tanpa method POST submit
    header("Location: data_soal.php");
    exit;
}
?>