<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */
if (!isset($_SESSION['user'])) {
    header("Location: ../otentikasi/login.php");
    exit;
}

if (isset($_POST['simpan'])) {
    // Pastikan folder tujuan sudah ada
    $target_dir = "../assets/img/soal/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $kategori   = mysqli_real_escape_string($koneksi, $_POST['kategori']);
    $tipe_soal  = mysqli_real_escape_string($koneksi, $_POST['tipe_soal']);
    $pertanyaan = mysqli_real_escape_string($koneksi, $_POST['pertanyaan']);
    $nama_gambar = NULL;

    // 1. Cek jika ada gambar dari Clipboard (Base64)
    if (!empty($_POST['gambar_base64'])) {
        $data = $_POST['gambar_base64'];
        if (preg_match('/^data:image\/(\w+);base64,/', $data, $type)) {
            $data = substr($data, strpos($data, ',') + 1);
            $type = strtolower($type[1]); // png, jpg, etc
            $data = base64_decode($data);
            $nama_gambar = 'img_' . time() . '.' . $type;
            file_put_contents($target_dir . $nama_gambar, $data);
        }
    }
    // 2. Cek jika ada gambar dari Upload File Biasa
    elseif (!empty($_FILES['gambar_soal']['name'])) {
        $ext = pathinfo($_FILES['gambar_soal']['name'], PATHINFO_EXTENSION);
        $nama_gambar = time() . '.' . $ext;
        move_uploaded_file($_FILES['gambar_soal']['tmp_name'], $target_dir . $nama_gambar);
    }

    // 3. Eksekusi Query
    if ($tipe_soal == 'PG') {
        $opsi_a = mysqli_real_escape_string($koneksi, $_POST['opsi_a']);
        $opsi_b = mysqli_real_escape_string($koneksi, $_POST['opsi_b']);
        $opsi_c = mysqli_real_escape_string($koneksi, $_POST['opsi_c']);
        $opsi_d = mysqli_real_escape_string($koneksi, $_POST['opsi_d']);
        $kunci  = mysqli_real_escape_string($koneksi, $_POST['kunci_pg']);

        $query = "INSERT INTO tbl_soal (kategori, tipe_soal, pertanyaan, gambar, opsi_a, opsi_b, opsi_c, opsi_d, kunci) 
                  VALUES ('$kategori', '$tipe_soal', '$pertanyaan', '$nama_gambar', '$opsi_a', '$opsi_b', '$opsi_c', '$opsi_d', '$kunci')";
    } else {
        // Mode Essay
        $query = "INSERT INTO tbl_soal (kategori, tipe_soal, pertanyaan, gambar, opsi_a, opsi_b, opsi_c, opsi_d, kunci) 
                  VALUES ('$kategori', '$tipe_soal', '$pertanyaan', '$nama_gambar', NULL, NULL, NULL, NULL, NULL)";
    }

    if (mysqli_query($koneksi, $query)) {
        $pesan = urlencode("Data soal berhasil disimpan.");
        header("Location: input.php?status=berhasil&pesan=$pesan");
    } else {
        $msg = urlencode(mysqli_error($koneksi));
        header("Location: input.php?status=gagal&pesan=$msg");
    }
} else {
    header("Location: input.php");
}
exit();
