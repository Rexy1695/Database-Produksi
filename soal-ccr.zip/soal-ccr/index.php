<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: otentikasi/login.php");
    exit;
}

require "config.php";
// Judul halaman
$title = "Project Control - Dashboard";

// Ambil data statistik dari database
$query_user = mysqli_query($koneksi, "SELECT * FROM users");
$jml_user = mysqli_num_rows($query_user);

$query_pg = mysqli_query($koneksi, "SELECT * FROM tbl_soal WHERE tipe_soal = 'PG'");
$jml_pg = mysqli_num_rows($query_pg);

$query_essay = mysqli_query($koneksi, "SELECT * FROM tbl_soal WHERE tipe_soal = 'Essay'");
$jml_essay = mysqli_num_rows($query_essay);

// Load template
require "template/header.php";
require "template/navbar.php";
require "template/sidebar.php";
?>

<div class="page-wrapper">
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-md-6 col-8 align-self-center">
                <h3 class="page-title mb-0 p-0">Dashboard</h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>

    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-12">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body">
                        <h4 class="card-title text-primary">Selamat Datang, <?= $_SESSION['user']['nama'] ?>!</h4>
                        <p class="text-muted small">Anda masuk sebagai <strong><?= $_SESSION['user']['role'] ?></strong>. Gunakan menu di bawah atau sidebar untuk mengelola kuis.</p>
                        <hr>
                        <div class="d-flex justify-content-start gap-2">
                            <?php if ($_SESSION['user']['role'] === 'Admin') : ?>
                                <a href="user/user.php" class="btn btn-outline-primary btn-sm rounded-pill px-3">
                                    <i class="fas fa-users me-1"></i> Kelola User
                                </a>    
                            <?php endif; ?>

                            <?php if ($_SESSION['user']['role'] === 'Admin' || $_SESSION['user']['role'] === 'Pengawas') : ?>
                                <a href="ujian/input.php" class="btn btn-outline-success btn-sm rounded-pill px-3">
                                    <i class="fas fa-plus me-1"></i> Tambah Soal
                                </a>
                            <?php endif; ?>

                            <?php if ($_SESSION['user']['role'] === 'User') : ?>
                                <a href="test/ujian.php" class="btn btn-primary btn-sm rounded-pill px-3">
                                    <i class="fas fa-edit me-1"></i> Mulai Ujian
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h4 class="card-title text-muted">Total User</h4>
                        <div class="text-end">
                            <h2 class="font-light mb-0"><i class="fa fa-users text-primary"></i> <?= $jml_user ?></h2>
                            <span class="text-muted">Pengguna terdaftar</span>
                        </div>
                        <div class="progress mt-3" style="height: 6px;">
                            <div class="progress-bar bg-primary" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h4 class="card-title text-muted">Soal Pilihan Ganda</h4>
                        <div class="text-end">
                            <h2 class="font-light mb-0"><i class="fa fa-list-ol text-success"></i> <?= $jml_pg ?></h2>
                            <span class="text-muted">Jumlah Soal PG</span>
                        </div>
                        <div class="progress mt-3" style="height: 6px;">
                            <div class="progress-bar bg-success" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h4 class="card-title text-muted">Soal Essay</h4>
                        <div class="text-end">
                            <h2 class="font-light mb-0"><i class="fa fa-file-alt text-info"></i> <?= $jml_essay ?></h2>
                            <span class="text-muted">Jumlah Soal Essay</span>
                        </div>
                        <div class="progress mt-3" style="height: 6px;">
                            <div class="progress-bar bg-info" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php
require "template/footer.php";
?>