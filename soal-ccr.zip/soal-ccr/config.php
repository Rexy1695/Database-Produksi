<?php

date_default_timezone_set('Asia/Kuala_Lumpur');

// Konfigurasi Database
$host   = 'localhost';
$user   = 'root';
$pass   = '';
$dbname = 'db_soal';

// Koneksi Database
$koneksi = mysqli_connect($host, $user, $pass, $dbname);

// Cek koneksi
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Menentukan protocol (HTTP / HTTPS)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') ? 'https://' : 'http://';

// Nama folder project
$project_folder = 'soal-ccr';

// Base URL otomatis
$main_url = $protocol . $_SERVER['HTTP_HOST'] . '/' . $project_folder;
