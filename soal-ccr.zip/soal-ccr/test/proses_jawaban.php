<?php
session_start();
require "../config.php";

/** @var mysqli $koneksi */
if (!isset($_SESSION['user'])) {
    header("Location: ../otentikasi/login.php");
    exit;
}

if (isset($_POST['jawaban']) && is_array($_POST['jawaban'])) {
    $jawaban_user = $_POST['jawaban'];
    $id_user = $_SESSION['user']['id'];

    // Ambil kategori dari soal pertama yang dijawab
    reset($jawaban_user);
    $first_id_soal = mysqli_real_escape_string($koneksi, key($jawaban_user));
    $cek_kat = mysqli_query($koneksi, "SELECT kategori FROM tbl_soal WHERE id = '$first_id_soal'");
    $data_kat = mysqli_fetch_assoc($cek_kat);
    $kategori_kuis = $data_kat['kategori'];

    $total_soal_pg = 0;
    $jawaban_benar_pg = 0;

    // 1. Inisialisasi awal di tbl_nilai
    $simpan_nilai = mysqli_query($koneksi, "INSERT INTO tbl_nilai (id_user, kategori, jumlah_benar, skor, tanggal_kerja) 
                                           VALUES ('$id_user', '$kategori_kuis', 0, 0, NOW())");

    if (!$simpan_nilai) die("Gagal inisialisasi: " . mysqli_error($koneksi));

    $id_nilai_baru = mysqli_insert_id($koneksi);

    // Tarik semua soal berdasarkan kategori aktif
    $query_semua_soal = mysqli_query($koneksi, "SELECT id, tipe_soal, kunci FROM tbl_soal WHERE kategori = '$kategori_kuis'");

    while ($soal = mysqli_fetch_assoc($query_semua_soal)) {
        $id_soal = $soal['id'];
        
        if (isset($jawaban_user[$id_soal])) {
            $jawaban_mentah = mysqli_real_escape_string($koneksi, $jawaban_user[$id_soal]);
            
            // Antisipasi jika di DB ditulis 'PG', 'pg', 'Pilihan Ganda', atau 'pilihan ganda'
            $tipe_soal_clean = strtoupper(trim($soal['tipe_soal']));

            if ($tipe_soal_clean == 'PG' || strpos($tipe_soal_clean, 'PILIHAN') !== false) {
                $total_soal_pg++;

                // Bersihkan kunci DB dari segala spasi/karakter aneh, lalu ambil huruf pertama
                $kunci_clean = preg_replace('/\s+/', '', $soal['kunci']);
                $huruf_kunci = strtoupper(substr($kunci_clean, 0, 1));
                
                // Bersihkan jawaban user dari segala spasi/karakter aneh, lalu ambil huruf pertama
                $user_clean = preg_replace('/\s+/', '', $jawaban_mentah);
                $huruf_user = strtoupper(substr($user_clean, 0, 1));

                // Cocokkan karakter tunggal secara identik
                if ($huruf_user === $huruf_kunci && !empty($huruf_kunci)) {
                    $status_jawaban = 1;
                    $jawaban_benar_pg++; 
                } else {
                    $status_jawaban = 0;
                }

                // Simpan ke tbl_jawaban
                mysqli_query($koneksi, "INSERT INTO tbl_jawaban (id_nilai, id_soal, jawaban_user, status_jawaban) 
                                        VALUES ('$id_nilai_baru', '$id_soal', '$jawaban_mentah', '$status_jawaban')");

            } else {
                // Default masuk ke Essay jika tidak memenuhi kriteria PG
                mysqli_query($koneksi, "INSERT INTO tbl_jawaban (id_nilai, id_soal, jawaban_user, status_jawaban) 
                                        VALUES ('$id_nilai_baru', '$id_soal', '$jawaban_mentah', 0)");
            }
        }
    }

    // Hitung Skor Akhir
    $skor = ($total_soal_pg > 0) ? round(($jawaban_benar_pg / $total_soal_pg) * 100, 2) : 0;

    // 2. Update hasil ke database
    $update_nilai = mysqli_query($koneksi, "UPDATE tbl_nilai SET jumlah_benar = '$jawaban_benar_pg', skor = '$skor' WHERE id = '$id_nilai_baru'");

    if ($update_nilai) {
        $_SESSION['terakhir_skor'] = $skor;
        header("Location: hasil_kuis.php?id=$id_nilai_baru");
    } else {
        echo "Gagal simpan skor: " . mysqli_error($koneksi);
    }
} else {
    header("Location: ujian.php");
}
exit();
?>