<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */
if (!isset($_SESSION['user'])) {
    header("Location: ../otentikasi/login.php");
    exit;
}

// Ambil ID dari URL
$id_nilai = isset($_GET['id']) ? mysqli_real_escape_string($koneksi, $_GET['id']) : '';

if (empty($id_nilai)) {
    header("Location: index.php");
    exit;
}

// Query disesuaikan dengan nama tabel 'users' sesuai gambar database kamu
$query = mysqli_query($koneksi, "SELECT n.*, u.nama 
                                 FROM tbl_nilai n 
                                 JOIN users u ON n.id_user = u.id 
                                 WHERE n.id = '$id_nilai'");
$data = mysqli_fetch_assoc($query);

// Proteksi akses: hanya pemilik nilai atau admin yang bisa melihat
if (!$data || (
    $data['id_user'] != $_SESSION['user']['id'] && 
    strtolower($_SESSION['user']['role']) != 'admin' && 
    strtolower($_SESSION['user']['role']) != 'pengawas'
)) {
    echo "<script>alert('Data tidak ditemukan atau akses dilarang!'); window.location='index.php';</script>";
    exit;
}

$title = "Project Control - Hasil Kuis";
require "../template/header.php";
require "../template/navbar.php";
require "../template/sidebar.php";

// Logika tampilan warna dan status
$skor = $data['skor'];
$lulus = $skor >= 70;
?>

<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row justify-content-center pt-5">
            <div class="col-md-7">
                <div class="card shadow-lg border-0 overflow-hidden" style="border-radius: 20px;">
                    <div class="py-5 text-center text-white <?= $lulus ? 'bg-success' : 'bg-danger' ?>"
                        style="background: <?= $lulus ? 'linear-gradient(45deg, #28a745, #1e7e34)' : 'linear-gradient(45deg, #dc3545, #a71d2a)' ?> !important;">
                        <i class="fas <?= $lulus ? 'fa-trophy' : 'fa-times-circle' ?> fa-5x mb-3"></i>
                        <h1 class="fw-bold mb-0"><?= $lulus ? 'SELAMAT!' : 'COBA LAGI!' ?></h1>
                        <p class="opacity-75">Anda telah menyelesaikan kuis kategori **<?= htmlspecialchars($data['kategori']) ?>**</p>
                    </div>

                    <div class="card-body p-5 text-center">
                        <h4 class="text-muted mb-4">Halo, <strong><?= htmlspecialchars($data['nama']) ?></strong></h4>

                        <div class="row justify-content-center mb-4">
                            <div class="col-auto">
                                <div class="display-1 fw-bold text-dark" style="font-size: 6rem; line-height: 1;"><?= number_format($skor, 0) ?></div>
                                <div class="text-muted fw-bold">SKOR AKHIR</div>
                            </div>
                        </div>

                        <div class="row g-3 mb-5">
                            <div class="col-6">
                                <div class="p-3 border rounded bg-light">
                                    <small class="text-muted d-block mb-1">JAWABAN BENAR</small>
                                    <h3 class="mb-0 text-success fw-bold"><?= $data['jumlah_benar'] ?> <small class="fs-6">Soal</small></h3>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="p-3 border rounded bg-light">
                                    <small class="text-muted d-block mb-1">STATUS AKHIR</small>
                                    <h3 class="mb-0 <?= $lulus ? 'text-primary' : 'text-danger' ?> fw-bold"><?= $lulus ? 'LULUS' : 'REMEDIAL' ?></h3>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex flex-wrap justify-content-center gap-3">
                            <a href="../index.php" class="btn btn-lg btn-primary rounded-pill px-5 shadow">
                                <i class="fas fa-home me-2"></i>Dashboard
                            </a>
                        </div>
                    </div>

                    <div class="card-footer bg-light border-0 py-3 text-center">
                        <small class="text-muted">
                            <i class="fas fa-calendar-alt me-1"></i> Waktu Selesai:
                            <?= date('d/m/Y H:i', strtotime($data['tanggal_kerja'])) ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require "../template/footer.php"; ?>