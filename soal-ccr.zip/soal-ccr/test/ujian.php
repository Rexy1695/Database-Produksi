<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: otentikasi/login.php");
    exit;
}
require "../config.php";
/** @var mysqli $koneksi */
$title = "Project Control - Kerjakan Soal";
require "../template/header.php";
require "../template/navbar.php";
require "../template/sidebar.php";

// 1. Ambil semua soal dari database
$query_soal = mysqli_query($koneksi, "SELECT * FROM tbl_soal");

$soal_pg = [];
$soal_essay = [];

while ($row = mysqli_fetch_assoc($query_soal)) {

    if ($row['tipe_soal'] === 'PG') {
        $soal_pg[] = $row;
    } else {
        $soal_essay[] = $row;
    }
}

// Acak masing-masing kelompok
shuffle($soal_pg);
shuffle($soal_essay);

// Gabungkan kembali: PG tetap di atas, Essay tetap di bawah
$semua_soal = array_merge($soal_pg, $soal_essay);
?>

<div class="page-wrapper">
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-md-6 col-8 align-self-center">
                <h3 class="page-title mb-0 p-0">Kerjakan Soal</h3>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div id="tampilan_pilih_kategori" class="row justify-content-center">
            <div class="col-md-10 text-center">
                <div class="card shadow-sm border-0 py-5">
                    <div class="card-body">
                        <i class="fas fa-layer-group fa-4x text-primary mb-3"></i>
                        <h2>Pilih Kategori Kuis</h2>
                        <p class="text-muted mb-4">Silakan pilih kategori soal yang ingin Anda kerjakan hari ini.</p>

                        <div class="row g-3 justify-content-center">
                            <div class="col-md-5">
                                <div class="card h-100 border-2 card-hover" onclick="filterKategori('Dispatch')" style="cursor: pointer;">
                                    <div class="card-body py-4">
                                        <i class="fas fa-truck-loading fa-3x text-info mb-3"></i>
                                        <h4 class="fw-bold">Dispatch</h4>
                                        <button class="btn btn-info text-white mt-2">Pilih</button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="card h-100 border-2 card-hover" onclick="filterKategori('Monitoring CCTV')" style="cursor: pointer;">
                                    <div class="card-body py-4">
                                        <i class="fas fa-video fa-3x text-warning mb-3"></i>
                                        <h4 class="fw-bold">Monitoring CCTV</h4>
                                        <button class="btn btn-warning text-white mt-2">Pilih</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="tampilan_mulai" class="row justify-content-center" style="display: none;">
            <div class="col-md-8 text-center">
                <div class="card shadow-sm border-0 py-5">
                    <div class="card-body">
                        <i class="fas fa-file-signature fa-4x text-primary mb-3"></i>
                        <h2 id="judul_siap">Siap untuk memulai?</h2>
                        <p class="text-muted">Kategori: <span id="kategori_terpilih" class="badge bg-primary fs-6"></span></p>
                        <p class="text-muted">Terdapat total <strong id="jumlah_soal_filter">0</strong> soal (PG & Essay).</p>
                        <div class="d-flex justify-content-center gap-2">
                            <button class="btn btn-light border px-4" onclick="location.reload()">Ganti Kategori</button>
                            <button class="btn btn-primary btn-lg px-5 shadow" onclick="mulaiKuis()">
                                <i class="fas fa-play me-2"></i> Mulai Sekarang
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="tampilan_kuis" style="display: none;">
            <form action="proses_jawaban.php" method="POST" id="form_kuis">
                <input type="hidden" name="kategori_kuis" id="input_kategori_hidden">

                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <?php foreach ($semua_soal as $s) : ?>
                            <div class="card shadow-sm soal-item" data-kategori="<?= $s['kategori'] ?>" style="display: none;">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <h5 class="fw-bold text-primary">Soal <span class="nomor-tampilan"></span></h5>
                                        <span class="badge bg-light text-dark border"><?= $s['tipe_soal'] == 'PG' ? 'Pilihan Ganda' : 'Essay' ?></span>
                                    </div>

                                    <?php if (!empty($s['gambar'])): ?>
                                        <div class="text-center my-3">
                                            <img src="../assets/img/soal/<?= $s['gambar'] ?>" class="img-fluid rounded border shadow-sm" style="max-height: 300px; cursor: pointer;" onclick="window.open(this.src)">
                                        </div>
                                    <?php endif; ?>

                                    <p class="fs-5 mt-3"><?= htmlspecialchars($s['pertanyaan']) ?></p>
                                    <hr>

                                    <?php if ($s['tipe_soal'] == 'PG') : ?>
                                        <div class="opsi-jawaban">
                                            <?php foreach (['a', 'b', 'c', 'd'] as $opsi) : ?>
                                                <div class="form-check mb-2">
                                                    <input class="form-check-input" type="radio"
                                                        name="jawaban[<?= $s['id'] ?>]"
                                                        id="soal<?= $s['id'] . $opsi ?>"
                                                        value="<?= strtoupper($opsi) ?>">
                                                    <label class="form-check-label w-100 p-2 border rounded" for="soal<?= $s['id'] . $opsi ?>">
                                                        <strong><?= strtoupper($opsi) ?>.</strong> <?= htmlspecialchars($s['opsi_' . $opsi]) ?>
                                                    </label>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else : ?>
                                        <div class="form-group">
                                            <label class="form-label fw-bold">Jawaban Essay Anda:</label>
                                            <textarea class="form-control" name="jawaban[<?= $s['id'] ?>]" rows="4" placeholder="Tuliskan jawaban lengkap di sini..."></textarea>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <div class="d-flex justify-content-between align-items-center mt-4 mb-5">
                            <button type="button" class="btn btn-outline-secondary px-4" id="btn_prev" onclick="changePage(-1)" disabled>
                                <i class="fas fa-chevron-left me-1"></i> Sebelumnya
                            </button>

                            <span class="fw-bold" id="info_halaman">Halaman 1</span>

                            <button type="button" class="btn btn-outline-secondary px-4" id="btn_next" onclick="changePage(1)">
                                Berikutnya <i class="fas fa-chevron-right ms-1"></i>
                            </button>

                            <button type="submit" class="btn btn-success px-5 shadow" id="btn_selesai" style="display: none;">
                                <i class="fas fa-check-circle me-1"></i> Selesai & Kirim
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    .card-hover:hover {
        border-color: #0d6efd !important;
        transform: translateY(-5px);
        transition: all 0.3s ease;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }

    .form-check-input:checked+.form-check-label {
        background-color: #e7f1ff;
        border-color: #0d6efd !important;
        font-weight: bold;
    }

    .soal-item {
        transition: all 0.3s ease;
        margin-bottom: 20px;
    }
</style>

<script>
    let currentPage = 1;
    let totalPages = 1;
    let kategoriGlobal = "";
    const soalPerPage = 5;

    function filterKategori(kat) {
        kategoriGlobal = kat;
        document.getElementById('input_kategori_hidden').value = kat;

        const soalSesuai = document.querySelectorAll(`.soal-item[data-kategori="${kat}"]`);

        if (soalSesuai.length === 0) {
            alert("Maaf, belum ada soal untuk kategori ini.");
            return;
        }

        document.getElementById('tampilan_pilih_kategori').style.display = 'none';
        document.getElementById('tampilan_mulai').style.display = 'flex';
        document.getElementById('kategori_terpilih').innerText = kat;
        document.getElementById('jumlah_soal_filter').innerText = soalSesuai.length;

        totalPages = Math.ceil(soalSesuai.length / soalPerPage);

        document.querySelectorAll('.soal-item').forEach(s => {
            s.className = s.className.replace(/\bfilter-page-\d+/g, "");
        });

        // Penomoran ulang sesuai urutan yang sudah difilter kategori
        soalSesuai.forEach((s, index) => {
            s.querySelector('.nomor-tampilan').innerText = (index + 1);
            const p = Math.ceil((index + 1) / soalPerPage);
            s.classList.add('filter-page-' + p);
        });
    }

    function mulaiKuis() {
        document.getElementById('tampilan_mulai').style.display = 'none';
        document.getElementById('tampilan_kuis').style.display = 'block';
        currentPage = 1; // Reset ke halaman 1
        showPage(1);
    }

    function showPage(page) {
        document.querySelectorAll('.soal-item').forEach(s => s.style.display = 'none');

        const currentSoal = document.querySelectorAll(`.soal-item[data-kategori="${kategoriGlobal}"].filter-page-${page}`);
        currentSoal.forEach(s => s.style.display = 'block');

        document.getElementById('info_halaman').innerText = `Halaman ${page} dari ${totalPages}`;
        document.getElementById('btn_prev').disabled = (page === 1);

        if (page === totalPages) {
            document.getElementById('btn_next').style.display = 'none';
            document.getElementById('btn_selesai').style.display = 'block';
        } else {
            document.getElementById('btn_next').style.display = 'block';
            document.getElementById('btn_selesai').style.display = 'none';
        }

        window.scrollTo(0, 0);
    }

    function changePage(step) {
        currentPage += step;
        showPage(currentPage);
    }
</script>

<?php require "../template/footer.php"; ?>