<?php
session_start();

require "../config.php";

/**
 * Pastikan koneksi tersedia
 */
if (!isset($koneksi)) {
    die("Koneksi database tidak ditemukan. Periksa file config.php");
}

/**
 * Cek login
 */
if (!isset($_SESSION['user'])) {
    header("Location: ../otentikasi/login.php");
    exit;
}


/**
 * Cek data POST
 */
if (!isset($_POST['nik_lama']) || empty($_POST['nik_lama'])) {
    header("Location: user.php?status=gagal&pesan=Data tidak valid");
    exit;
}


$nik_lama     = trim($_POST['nik_lama']);
$nama         = trim($_POST['nama']);
$password     = $_POST['password'];
$confpassword = $_POST['confpassword'];


/**
 * Ambil role
 */
if ($_SESSION['user']['role'] == "Admin") {

    $role = $_POST['role'];

} else {

    // User biasa tidak boleh mengganti role
    $stmtRole = $koneksi->prepare(
        "SELECT role FROM users WHERE nik=?"
    );

    $stmtRole->bind_param(
        "s",
        $nik_lama
    );

    $stmtRole->execute();

    $dataRole = $stmtRole->get_result()->fetch_assoc();

    $role = $dataRole['role'];

}



/**
 * Validasi password
 */
if (!empty($password)) {


    if ($password !== $confpassword) {

        header(
            "Location: edit.php?nik=$nik_lama&status=gagal&pesan=Password tidak cocok"
        );

        exit;
    }


    $password_hash = password_hash(
        $password,
        PASSWORD_DEFAULT
    );


    $stmt = $koneksi->prepare(
        "UPDATE users 
         SET nama=?, password=?, role=? 
         WHERE nik=?"
    );


    $stmt->bind_param(
        "ssss",
        $nama,
        $password_hash,
        $role,
        $nik_lama
    );


} else {


    $stmt = $koneksi->prepare(
        "UPDATE users 
         SET nama=?, role=? 
         WHERE nik=?"
    );


    $stmt->bind_param(
        "sss",
        $nama,
        $role,
        $nik_lama
    );

}



/**
 * Eksekusi
 */
if ($stmt->execute()) {


    if ($stmt->affected_rows > 0) {


        header(
            "Location: user.php?status=berhasil&pesan=Data berhasil diperbarui"
        );


    } else {


        header(
            "Location: user.php?status=berhasil&pesan=Tidak ada perubahan data"
        );


    }


} else {


    header(
        "Location: edit.php?nik=$nik_lama&status=gagal&pesan=Database error"
    );

}


$stmt->close();

exit;