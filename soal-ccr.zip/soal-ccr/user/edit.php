<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: otentikasi/login.php");
    exit;
}

require "../config.php";
/** @var mysqli $koneksi */
$title = "Project Control - Edit User";

require "../template/header.php";
require "../template/navbar.php";
require "../template/sidebar.php";

// Tangkap NIK dari URL
if (!isset($_GET['nik'])) {
    header("Location: user.php");
    exit;
}

$nik = $_GET['nik'];

// Ambil data user dari database
$stmt = $koneksi->prepare("SELECT * FROM users WHERE nik = ?");
$stmt->bind_param("s", $nik);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    header("Location: user.php?status=gagal&pesan=User tidak ditemukan");
    exit;
}
?>

<div class="page-wrapper">

    <!-- Breadcrumb -->
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-md-6 col-8 align-self-center">
                <h3 class="page-title mb-0 p-0">Edit User</h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?= $main_url ?>/index.php">Home</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?= $main_url ?>/user/user.php">Data User</a>
                        </li>
                        <li class="breadcrumb-item active">Edit User</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>

    <!-- Alert -->
    <?php if (isset($_GET['status'])) : ?>
        <?php if ($_GET['status'] == 'berhasil') : ?>
            <div id="alert" class="alert alert-success alert-dismissible fade show">
                <strong>Berhasil!</strong> <?= htmlspecialchars($_GET['pesan'] ?? 'User berhasil diupdate.') ?>
            </div>
        <?php elseif ($_GET['status'] == 'gagal') : ?>
            <div id="alert" class="alert alert-danger alert-dismissible fade show">
                <strong>Gagal!</strong> <?= htmlspecialchars($_GET['pesan'] ?? 'Terjadi kesalahan.') ?>
            </div>
        <?php endif; ?>

        <script>
            setTimeout(function() {
                var alert = document.getElementById('alert');
                if (alert) {
                    alert.classList.remove('show');
                    alert.classList.add('fade');
                    alert.style.display = 'none';
                }
            }, 3000);
        </script>
    <?php endif; ?>

    <!-- Content -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="card-title mb-4">Form Edit User</h4>

                        <form action="proses_edit.php" method="post">
                            <input type="hidden" name="nik_lama" value="<?= $user['nik'] ?>">

                            <input type="hidden" name="nik" value="<?= $user['nik'] ?>">

                            <div class="form-group">
                                <label>NIK</label>
                                <input type="text" class="form-control" value="<?= htmlspecialchars($user['nik']) ?>" disabled>
                            </div>
                            <div class="form-group">
                                <label>Nama</label>
                                <input type="text"
                                    name="nama"
                                    class="form-control"
                                    value="<?= htmlspecialchars($user['nama']) ?>"
                                    <?= $_SESSION['user']['role'] == 'Admin' ? '' : 'readonly' ?>>
                            </div>

                            <div class="form-group">
                                <label>Password Baru</label>
                                <input type="password" name="password" class="form-control" placeholder="Kosongkan jika tidak ingin diganti">
                            </div>

                            <div class="form-group">
                                <label>Konfirmasi Password Baru</label>
                                <input type="password" name="confpassword" class="form-control" placeholder="Kosongkan jika tidak ingin diganti">
                            </div>

                            <div class="form-group">
                                <label>Role</label>
                                <?php if ($_SESSION['user']['role'] == 'Admin') : ?>
                                    <select name="role" class="form-control" required>
                                        <option value="">-- Pilih Role --</option>
                                        <option value="Admin" <?= $user['role'] == 'Admin' ? 'selected' : '' ?>>Admin</option>
                                        <option value="User" <?= $user['role'] == 'User' ? 'selected' : '' ?>>User</option>
                                        <option value="Pengawas" <?= $user['role'] == 'Pengawas' ? 'selected' : '' ?>>Pengawas</option>
                                    </select>
                                <?php else : ?>
                                    <select class="form-control" disabled>
                                        <option value="Admin" <?= $user['role'] == 'Admin' ? 'selected' : '' ?>>Admin</option>
                                        <option value="User" <?= $user['role'] == 'User' ? 'selected' : '' ?>>User</option>
                                        <option value="Pengawas" <?= $user['role'] == 'Pengawas' ? 'selected' : '' ?>>Pengawas</option>
                                    </select>
                                    <input type="hidden" name="role" value="<?= $user['role'] ?>">
                                <?php endif; ?>
                            </div>

                            <div class="mt-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Simpan
                                </button>
                                <a href="user.php" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Kembali
                                </a>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php require "../template/footer.php"; ?>