<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: user.php");
    exit;
}

// ==========================================
// LOGIKA 1: PROSES TAMBAH BANYAK (MASSAL)
// ==========================================
if (isset($_POST['simpan_banyak'])) {
    $niks  = $_POST['nik']; // Ini berupa array
    $namas = $_POST['nama'];
    $roles = $_POST['role'];

    $berhasil = 0;
    $gagal = 0;

    foreach ($niks as $i => $raw_nik) {
        $nik  = trim($raw_nik);
        $nama = trim($namas[$i]);
        $role = $roles[$i];

        // Skip jika baris kosong
        if (empty($nik) || empty($nama)) continue;

        // Cek duplikat NIK
        $cek = $koneksi->prepare("SELECT nik FROM users WHERE nik = ?");
        $cek->bind_param("s", $nik);
        $cek->execute();
        $cek->store_result();

        if ($cek->num_rows == 0) {
            // Password default disamakan dengan NIK untuk input massal
            $password_hash = password_hash($nik, PASSWORD_DEFAULT);

            $stmt = $koneksi->prepare("INSERT INTO users (nik, nama, password, role) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $nik, $nama, $password_hash, $role);

            if ($stmt->execute()) {
                $berhasil++;
            } else {
                $gagal++;
            }
        } else {
            $gagal++;
        }
    }

    header("Location: user.php?status=berhasil&pesan=$berhasil user berhasil diimport, $gagal gagal/duplikat.");
    exit;
}

// ==========================================
// LOGIKA 2: PROSES TAMBAH SATUAN (ASLI)
// ==========================================
$nik          = trim($_POST['nik']);
$nama         = trim($_POST['nama']);
$password     = $_POST['password'];
$confpassword = $_POST['confpassword'];
$role         = $_POST['role'];

// 1. Cek NIK sudah ada atau belum
$cek = $koneksi->prepare("SELECT nik FROM users WHERE nik = ?");
$cek->bind_param("s", $nik);
$cek->execute();
$cek->store_result();

if ($cek->num_rows > 0) {
    header("Location: tambah_user.php?status=gagal&pesan=NIK sudah terdaftar");
    exit;
}

// 2. Validasi Password
if (empty($password)) {
    header("Location: tambah_user.php?status=gagal&pesan=Password wajib diisi");
    exit;
}

if ($password !== $confpassword) {
    header("Location: tambah_user.php?status=gagal&pesan=Konfirmasi password tidak cocok");
    exit;
}

$password_hash = password_hash($password, PASSWORD_DEFAULT);

// 3. Simpan ke Database
$stmt = $koneksi->prepare("INSERT INTO users (nik, nama, password, role) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $nik, $nama, $password_hash, $role);

if ($stmt->execute()) {
    header("Location: user.php?status=berhasil&pesan=User berhasil ditambahkan");
} else {
    header("Location: tambah_user.php?status=gagal&pesan=Gagal menyimpan data");
}
