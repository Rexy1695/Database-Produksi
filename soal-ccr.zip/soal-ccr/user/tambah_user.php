<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: otentikasi/login.php");
    exit;
}
require "../config.php";
$title = "Project Control - Tambah User";
require "../template/header.php";
require "../template/navbar.php";
require "../template/sidebar.php";
?>

<div class="page-wrapper">
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-md-6 col-8 align-self-center">
                <h3 class="page-title mb-0 p-0" id="page-title">Tambah User</h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= $main_url ?>/index.php">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?= $main_url ?>/user/user.php">Data User</a></li>
                        <li class="breadcrumb-item active">Tambah User</li>
                    </ol>
                </nav>
            </div>
            <div class="col-md-6 col-4 text-end">
                <button type="button" class="btn btn-info text-white shadow-sm" id="btn-toggle" onclick="toggleForm()">
                    <i class="fas fa-users me-1"></i> Tambah Banyak User
                </button>
            </div>
        </div>
    </div>

    <?php if (isset($_GET['status'])) : ?>
        <div class="container-fluid mb-0 pb-0">
            <div id="alert" class="alert <?= $_GET['status'] == 'berhasil' ? 'alert-success' : 'alert-danger' ?> alert-dismissible fade show">
                <strong><?= $_GET['status'] == 'berhasil' ? 'Berhasil!' : 'Gagal!' ?></strong> <?= htmlspecialchars($_GET['pesan']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
    <?php endif; ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card shadow-sm border-0">
                    <div class="card-body">

                        <div id="form-satuan">
                            <h4 class="card-title mb-4">Form Tambah User</h4>
                            <form action="proses_tambah.php" method="post">
                                <div class="form-group mb-3">
                                    <label class="">NIK</label>
                                    <input type="text" name="nik" class="form-control" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="">Nama</label>
                                    <input type="text" name="nama" class="form-control" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="">Password</label>
                                    <input type="password" name="password" class="form-control" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="">Konfirmasi Password</label>
                                    <input type="password" name="confpassword" class="form-control" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="">Role</label>
                                    <select name="role" class="form-control" required>
                                        <option value="">-- Pilih Role --</option>
                                        <option value="Admin">Admin</option>
                                        <option value="User">User</option>
                                        <option value="Pengawas">Pengawas</option>
                                    </select>
                                </div>
                                <div class="mt-4 border-top pt-3">
                                    <button type="submit" class="btn btn-primary px-4"><i class="fas fa-save me-1"></i> Simpan</button>
                                    <a href="user.php" class="btn btn-secondary px-4"><i class="fas fa-arrow-left me-1"></i> Kembali</a>
                                </div>
                            </form>
                        </div>

                        <div id="form-banyak" style="display: none;">
                            <h4 class="card-title mb-4 text-primary">Input Multiple User (Copy-Paste Excel)</h4>
                            <div class="alert alert-light border-start border-info border-4 shadow-sm mb-4">
                                <i class="fas fa-info-circle text-info me-2"></i>
                                <strong>Cara Input:</strong> Copy 3 kolom di Excel (NIK, Nama, Role) lalu <strong>Paste</strong> pada kolom di bawah ini.
                            </div>

                            <form action="proses_tambah.php" method="post">
                                <div class="table-responsive">
                                    <table class="table table-bordered align-middle">
                                        <thead class="table-light">
                                            <tr class="text-center">
                                                <th width="5%">No</th>
                                                <th>NIK</th>
                                                <th>Nama Lengkap</th>
                                                <th width="20%">Role</th>
                                                <th width="5%">Hapus</th>
                                            </tr>
                                        </thead>
                                        <tbody id="tbody-user">
                                            <tr>
                                                <td class="text-center">1</td>
                                                <td><input type="text" name="nik[]" class="form-control border-0 input-nik" placeholder="Paste NIK di sini..."></td>
                                                <td><input type="text" name="nama[]" class="form-control border-0" placeholder="Nama lengkap..."></td>
                                                <td>
                                                    <select name="role[]" class="form-select border-0">
                                                        <option value="User">User</option>
                                                        <option value="Admin">Admin</option>
                                                        <option value="Pengawas">Pengawas</option>
                                                    </select>
                                                </td>
                                                <td class="text-center"><button type="button" class="btn btn-link text-danger" onclick="hapusBaris(this)"><i class="fas fa-trash"></i></button></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="mt-3 border-top pt-3 d-flex justify-content-between">
                                    <button type="button" class="btn btn-outline-primary" onclick="tambahBaris()"><i class="fas fa-plus"></i> Tambah Baris</button>
                                    <div>
                                        <a href="user.php" class="btn btn-secondary me-2">Batal</a>
                                        <button type="submit" name="simpan_banyak" class="btn btn-success px-4">Simpan Semua User</button>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function toggleForm() {
        const fs = document.getElementById('form-satuan');
        const fb = document.getElementById('form-banyak');
        const btn = document.getElementById('btn-toggle');
        const title = document.getElementById('page-title');

        if (fs.style.display === 'none') {
            fs.style.display = 'block';
            fb.style.display = 'none';
            btn.innerHTML = '<i class="fas fa-users me-1"></i> Tambah Banyak User';
            btn.className = 'btn btn-info text-white shadow-sm';
            title.innerText = 'Tambah User';
        } else {
            fs.style.display = 'none';
            fb.style.display = 'block';
            btn.innerHTML = '<i class="fas fa-user me-1"></i> Input Satuan';
            btn.className = 'btn btn-secondary text-white shadow-sm';
            title.innerText = 'Input Massal User';
        }
    }

    function tambahBaris() {
        const tbody = document.getElementById('tbody-user');
        const rowCount = tbody.rows.length + 1;
        const row = `<tr>
        <td class="text-center">${rowCount}</td>
        <td><input type="text" name="nik[]" class="form-control border-0 input-nik"></td>
        <td><input type="text" name="nama[]" class="form-control border-0"></td>
        <td>
            <select name="role[]" class="form-select border-0">
                <option value="User">User</option>
                <option value="Admin">Admin</option>
                <option value="Pengawas">Pengawas</option>
            </select>
        </td>
        <td class="text-center"><button type="button" class="btn btn-link text-danger" onclick="hapusBaris(this)"><i class="fas fa-trash"></i></button></td>
    </tr>`;
        tbody.insertAdjacentHTML('beforeend', row);
        initPasteListener();
    }

    function hapusBaris(btn) {
        if (document.getElementById('tbody-user').rows.length > 1) {
            btn.closest('tr').remove();
        }
    }

    function initPasteListener() {
        document.querySelectorAll('.input-nik').forEach(input => {
            input.addEventListener('paste', function(e) {
                e.preventDefault();
                const text = (e.clipboardData || window.clipboardData).getData('Text');
                const rows = text.split(/\r?\n/);
                let currentRow = this.closest('tr');

                rows.forEach(rowData => {
                    if (rowData.trim() === '') return;
                    const cols = rowData.split('\t');

                    if (!currentRow) {
                        tambahBaris();
                        currentRow = document.getElementById('tbody-user').lastElementChild;
                    }

                    const inputs = currentRow.querySelectorAll('input, select');
                    if (cols[0]) inputs[0].value = cols[0].trim();
                    if (cols[1]) inputs[1].value = cols[1].trim();
                    if (cols[2]) inputs[2].value = cols[2].trim();

                    currentRow = currentRow.nextElementSibling;
                });
            });
        });
    }

    document.addEventListener('DOMContentLoaded', initPasteListener);

    setTimeout(function() {
        var alert = document.getElementById('alert');
        if (alert) {
            alert.classList.remove('show');
            alert.style.display = 'none';
        }
    }, 3000);
</script>

<?php require "../template/footer.php"; ?>