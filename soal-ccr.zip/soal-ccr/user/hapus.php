<?php
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['user'])) {
    header("Location: ../otentikasi/login.php");
    exit;
}

require "../config.php";
/** @var mysqli $koneksi */

// Ambil ID dari URL
$id = $_GET['id'];

if (isset($id)) {
    // Gunakan Prepared Statement untuk keamanan
    $stmt = mysqli_prepare($koneksi, "DELETE FROM users WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    
    if (mysqli_stmt_execute($stmt)) {
        // Jika berhasil, arahkan kembali dengan status berhasil
        header("Location: user.php?status=berhasil&pesan=Data berhasil dihapus");
    } else {
        // Jika gagal, arahkan kembali dengan pesan error
        $error = mysqli_error($koneksi);
        header("Location: user.php?status=gagal&pesan=" . urlencode("Gagal menghapus data: " . $error));
    }
    
    mysqli_stmt_close($stmt);
} else {
    // Jika ID tidak ditemukan di URL
    header("Location: user.php");
}

exit;
?>