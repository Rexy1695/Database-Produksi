<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: otentikasi/login.php");
    exit;
}

// Hapus pengecekan Admin ketat agar semua role bisa masuk ke halaman ini
require "../config.php";
/** @var mysqli $koneksi */
$title = "Project Control - Data User";

// Ambil data dari session untuk filter
$user_id = $_SESSION['user']['id'];
$user_role = $_SESSION['user']['role'];

// --- LOGIKA PENCARIAN & PAGINASI ---
$batas = 15;
$halaman = isset($_GET['pagi']) ? (int)$_GET['pagi'] : 1;
$halaman_awal = ($halaman > 1) ? ($halaman * $batas) - $batas : 0;

$cari = isset($_GET['cari']) ? mysqli_real_escape_string($koneksi, $_GET['cari']) : '';

// --- LOGIKA FILTER ROLE ---
// Jika Admin: Tarik semua data. Jika bukan Admin: Tarik data ID dia sendiri saja.
if ($user_role === 'Admin') {
    $where_clause = "(nama LIKE '%$cari%' OR nik LIKE '%$cari%')";
} else {
    $where_clause = "id = '$user_id'";
}

// Query hitung total
$query_hitung = "SELECT * FROM users WHERE $where_clause";
$res_hitung = mysqli_query($koneksi, $query_hitung);
$jumlah_data = mysqli_num_rows($res_hitung);
$total_halaman = ceil($jumlah_data / $batas);

// Query data utama
$query_data = "SELECT * FROM users WHERE $where_clause ORDER BY id DESC LIMIT $halaman_awal, $batas";
$res_data = mysqli_query($koneksi, $query_data);
// ------------------------------------

require "../template/header.php";
require "../template/navbar.php";
require "../template/sidebar.php";
?>

<div class="page-wrapper">
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-md-6 col-8 align-self-center">
                <h3 class="page-title mb-0 p-0">User</h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= $main_url ?>/index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <?= ($user_role === 'Admin') ? 'Data User' : 'Profil Saya' ?>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <?php if (isset($_GET['status'])) : ?>

        <?php if ($_GET['status'] == 'berhasil') : ?>

            <div id="alert" class="alert alert-success alert-dismissible fade show">
                <strong>Berhasil!</strong>
                <?= htmlspecialchars($_GET['pesan'] ?? 'Data berhasil disimpan.') ?>
            </div>

        <?php elseif ($_GET['status'] == 'gagal') : ?>

            <div id="alert" class="alert alert-danger alert-dismissible fade show">
                <strong>Gagal!</strong>
                <?= htmlspecialchars($_GET['pesan'] ?? 'Terjadi kesalahan.') ?>
            </div>

        <?php endif; ?>


        <script>
            setTimeout(function() {

                let alertBox = document.getElementById('alert');

                if (alertBox) {

                    alertBox.style.display = "none";

                }

            }, 3000);
        </script>

    <?php endif; ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card shadow-sm border-0">
                    <div class="card-body">

                        <div class="row mb-3 align-items-center">
                            <div class="col-md-4 mb-2 mb-md-0">
                                <h4 class="card-title mb-0">
                                    <?= ($user_role === 'Admin') ? "Data User (Total: $jumlah_data)" : "Detail Profil" ?>
                                </h4>
                            </div>
                            <div class="col-md-8">
                                <div class="d-flex flex-wrap justify-content-md-end gap-2">

                                    <?php if ($user_role === 'Admin') : ?>
                                        <form action="" method="GET" class="d-flex">
                                            <div class="input-group">
                                                <input type="text" name="cari" class="form-control form-control-sm" placeholder="Cari user..." value="<?= htmlspecialchars($cari) ?>">
                                                <button class="btn btn-info btn-sm text-white" type="submit"><i class="fas fa-search"></i></button>
                                                <?php if ($cari != '') : ?>
                                                    <a href="user.php" class="btn btn-outline-secondary btn-sm">Reset</a>
                                                <?php endif; ?>
                                            </div>
                                        </form>
                                        <a href="<?= $main_url ?>/user/tambah_user.php" class="btn btn-primary btn-sm">
                                            <i class="fa fa-plus"></i> Tambah User
                                        </a>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table user-table no-wrap table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th width="5%">NO</th>
                                        <th width="15%">NIK</th>
                                        <th>NAMA</th>
                                        <th width="15%">ROLE</th>
                                        <th width="10%">AKSI</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = $halaman_awal + 1;
                                    if (mysqli_num_rows($res_data) > 0) :
                                        while ($row = mysqli_fetch_assoc($res_data)) :
                                    ?>
                                            <tr>
                                                <td><?= $no++ ?></td>
                                                <td class=""><?= htmlspecialchars($row['nik']) ?></td>
                                                <td><?= htmlspecialchars($row['nama']) ?></td>
                                                <td>
                                                    <span class="">
                                                        <?= htmlspecialchars($row['role']) ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="edit.php?nik=<?= $row['nik'] ?>" class="btn btn-warning btn-sm text-white shadow-sm">
                                                        <i class="fas fa-edit"></i>
                                                    </a>

                                                    <?php if ($user_role === 'Admin') : ?>
                                                        <a href="hapus.php?id=<?= $row['id'] ?>"
                                                            class="btn btn-danger btn-sm shadow-sm"
                                                            onclick="return confirm('Hapus user <?= htmlspecialchars($row['nama']) ?>?')">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endwhile;
                                    else : ?>
                                        <tr>
                                            <td colspan="5" class="text-center py-4 text-muted">Data tidak ditemukan.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <?php if ($total_halaman > 1 && $user_role === 'Admin') : ?>
                            <nav class="mt-4">
                                <ul class="pagination justify-content-center">
                                    <li class="page-item <?= ($halaman <= 1) ? 'disabled' : '' ?>">
                                        <a class="page-link" href="?pagi=<?= $halaman - 1 ?>&cari=<?= $cari ?>">Previous</a>
                                    </li>
                                    <?php for ($i = 1; $i <= $total_halaman; $i++) : ?>
                                        <li class="page-item <?= ($halaman == $i) ? 'active' : '' ?>">
                                            <a class="page-link" href="?pagi=<?= $i ?>&cari=<?= $cari ?>"><?= $i ?></a>
                                        </li>
                                    <?php endfor; ?>
                                    <li class="page-item <?= ($halaman >= $total_halaman) ? 'disabled' : '' ?>">
                                        <a class="page-link" href="?pagi=<?= $halaman + 1 ?>&cari=<?= $cari ?>">Next</a>
                                    </li>
                                </ul>
                            </nav>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require "../template/footer.php"; ?>