-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 29, 2026 at 01:39 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_soal`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jawaban`
--

CREATE TABLE `tbl_jawaban` (
  `id` int NOT NULL,
  `id_nilai` int DEFAULT NULL,
  `id_soal` int DEFAULT NULL,
  `jawaban_user` text,
  `status_jawaban` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_jawaban`
--

INSERT INTO `tbl_jawaban` (`id`, `id_nilai`, `id_soal`, `jawaban_user`, `status_jawaban`) VALUES
(267, 39, 1, 'A', 1),
(268, 39, 2, 'A', 0),
(269, 39, 3, 'A', 1),
(270, 39, 4, 'B', 1),
(271, 39, 5, 'A', 1),
(272, 39, 6, 'B', 1),
(273, 39, 7, 'B', 1),
(274, 39, 8, 'B', 1),
(275, 39, 9, 'B', 1),
(276, 39, 10, 'C', 1),
(277, 39, 11, '- melakukan intercome kepada ybs\r\n- mengambil gambar dan diteruskan kepada pengawas agar ditindaklanjuti oleh pengawas lapangan', 0),
(278, 39, 12, 'Sangat penting, dalam proses investigasi tentu diperlukan bukti berupa rekaman CCTV sebagai bukti yang akan ditelusuri terkait tingkah laku operator dan beberapa hal yang sekiranya diperlukan sehingga bukti rekaman cctv tentu penting', 0),
(279, 39, 13, 'jika terjadi 2 pelanggaran secara bersamaan, maka ditentukan terlebih dahulu prioritasnya, yang diutamakan adalah pelanggaran eye closed, jika salah satunya adalah eye closed tentu akan diprioritaskan dengan menghubungi bapak pengawas sembari menunggu on progress broadcast sedangkan jika keduanya adalah eye closed maka tetap menghubungi bapak pengawas sembari menunggu on progress broadcast.', 0),
(280, 39, 14, 'Terjadinya KTA dimana Operator tidak dalam kondisi fit tetapi mengoperasikan unit, accident & fatality.', 0),
(281, 39, 15, 'unsafe act : tidak memakai seatbelt & menaikkan kaki saat mengoperasikan unit\r\nunsafe condition : hujan deras mengurangi jarak pandang & unit dioperasikan dalam kondisi tidak ready / area front loading slippery', 0),
(282, 39, 16, 'menginformasikan di grup bahwasanya saat itu cctv telah kehilangan sinyal sehingga agar dapat ditingkatkan kewaspadaannya bapak pengawas dan dispatch di jalur untuk selalu memonitor serta aktif radio.', 0),
(283, 39, 17, 'Tetap dilaporkan, perihal grounded bukan urusan monitoring cctv karna terkait grounded itu sudah ranahnya pengawas. ', 0),
(284, 39, 18, 'Tetap dilaporkan saja seperti biasanya tanpa memandang ia rekan kerja', 0),
(285, 39, 19, 'Hasil monitoring CCTV tentu saja dapat memperbaiki budaya keselamatan kerja, dengan adanya monitoring CCTV, operator akan semakin tertuntut menjalankan prosedur pengoperasian unit lebih teratur karna sadar dimonitoring selalu tingkah laku mereka. ', 0),
(286, 39, 20, '- memahami alur kerja\r\n- memahami fatigue management\r\n- memahami contoh gejala fatigue', 0),
(287, 40, 1, 'A', 1),
(288, 40, 2, 'A', 0),
(289, 40, 3, 'A', 1),
(290, 40, 4, 'B', 1),
(291, 40, 5, 'A', 1),
(292, 40, 6, 'B', 1),
(293, 40, 7, 'B', 1),
(294, 40, 8, 'B', 1),
(295, 40, 9, 'B', 1),
(296, 40, 10, 'C', 1),
(297, 40, 11, 'jika temuan tersebut terjadi disaat unit beroperasi atau dalam kondisi jalan saya akan langsung mengintercome ke operator untuk mengingatkan menggunakan seatbelt dan mengambil hasil record pelanggaran dan di berikan ke pengawas produksi untuk di tindak lanjuti agar tidak terjadi case yang sama', 0),
(298, 40, 12, 'untuk memudahkan analisa secara visual dan mencari indikasi sebelum terjadi nya insiden agar dapat tau penyebab dari kecelakaan tersebut\r\ncontoh : unit 123 menabrak tanggul pembatas jalan di jam 01:00 dan analisa dari cctv operator terindikasi micro sleep dan tertidur sebelum terjadinya insiden', 0),
(299, 40, 13, 'mengutamakan pelanggaran yang tertuju pada kondisi operator yang tidak fit terlebih dahulu agar tidak ada case berkelanjutan jika ada terindikasi seperti operator terindikasi mengantuk disaat pengoperasian dan operator melanggar peraturan untuk tidak menggunakan hp di saat pengoperasian unit, maka terlebih dahulu mengutamakan operator yang terindikasi mengantuk untuk segera menepi dan beristirahat agar tidak terjadi case berkelanjutan. setelah itu baru menegur operator yang menggunakan hp disaat pengoperasian tadi dan membuat evident ke pengawas agar di tindak lanjut sesuai golden rules', 0),
(300, 40, 14, 'akan memicu peningkatan resiko kecelakaan yang fatal,keruskan unit dan meningkatnya pelanggaran pelanggaran berikutnya', 0),
(301, 40, 15, 'perbedaan antara unsafe action dan unsafe condition terletak apa penyebanya dan untuk unsafe action biasanya ada pada manusianya seperti tindakan tidak aman dan untuk unsafe condition biasanya terletak pada area atau tempat kondisi yang tidak aman \r\nsebagai contoh :\r\nUnsafe action : Operator menggunakan telepon genggam di saat pengoperasian unit alat berat sehingga fokus pada operator terbagi antara aktifatas di telepon genggam dan aktivitas pengoperasian unit\r\nUnsafe condition : instalasi camera pada unit tidak rapi ataupun ada bagian terkelupas sehingga menyebabkan consleting pada unit ', 0),
(302, 40, 16, 'melaporkan kendala kepada teknisi dan menyampaikan kepada tim hauling di jalur kendala down pada signal agar di bantu peningkatan kepengawasan unit dan operator di jalur', 0),
(303, 40, 17, 'saya melanjutkan laporan tersebut ke atasan departemen saya agar atasan departemen saya menindak lanjuti dan memberi penjelasan terhadap pengawas yang melindungi operator tersebut agar sekiranya tidak ada pelanggaran berlanjut dikarenakan operator tersebuttidak diberikan punishment', 0),
(304, 40, 18, 'tetap melakukan prosedur secara profesional dan menegakan nila keadilan, bersikap transparan serta menyampaikan untuk tidak menyangkut pautkan antara pertemanan dari aturan profesional', 0),
(305, 40, 19, 'hasil dari montoring CCTV dapat digunakan sebagai alat dan dasar perbaikan keselamatan kerja dengan pemantauan kegiatan operasional unit yaitu dengan memantau dan mengaudit perilaku operator di dalam unit dan menegur secara langsung jika ada indikasi pelanggaran dari operator lalu menyampaikan hasil audit perilaku operator ke pengawas. hasil dari monitoring cctv juga dapat menginvestigasi suatu terjadi nya insiden atau nearmis disaat pengoperasian secara langsung dan pemantauan cctv juga dapat mengindentifikasi bahaya lingkungan sekitar area unit disaat pengoperasian.', 0),
(306, 40, 20, 'berpikir secara Kritis,analisa data dan komunikasi yang baik dan strategis \r\nberpikir kritis : dapat menilai situasi,keadaan dan perilaku operator dan dapat mencari tahu pelanggaran ataupun kondisi operator pada saat itu \r\nk analisa data : memastikan data yang dikirim ataupun yang di laporkan itu tepat dengan pelanggaran yang di lakukan operator tersebut agar tidak terjadi kesalah pahaman antara penindak dan operator yang melanggar\r\nBerkomunikasi secara baik dan strategis : memahami siapa lawan bicara di saat intercome unit  dan memberikan kesempatan lawan bicara untuk menjawab pertanyaan disaat intercome setelah itu memberikan dan mengingatkan pesan keselamatan kerja', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nilai`
--

CREATE TABLE `tbl_nilai` (
  `id` int NOT NULL,
  `id_user` int DEFAULT NULL,
  `kategori` varchar(50) DEFAULT NULL,
  `jumlah_benar` int DEFAULT NULL,
  `skor` decimal(5,2) DEFAULT NULL,
  `tanggal_kerja` datetime DEFAULT NULL,
  `tgl_mengerjakan` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_nilai`
--

INSERT INTO `tbl_nilai` (`id`, `id_user`, `kategori`, `jumlah_benar`, `skor`, `tanggal_kerja`, `tgl_mengerjakan`) VALUES
(39, 31, 'Monitoring CCTV', 9, '90.00', '2026-08-03 10:58:33', '2026-08-03 02:58:33'),
(40, 25, 'Monitoring CCTV', 9, '90.00', '2026-08-03 12:03:36', '2026-08-03 04:03:36');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_soal`
--

CREATE TABLE `tbl_soal` (
  `id` int NOT NULL,
  `kategori` varchar(50) DEFAULT NULL,
  `tipe_soal` enum('PG','Essay') NOT NULL,
  `pertanyaan` text NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `opsi_a` text,
  `opsi_b` text,
  `opsi_c` text,
  `opsi_d` text,
  `kunci` varchar(1) DEFAULT NULL,
  `tgl_input` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_soal`
--

INSERT INTO `tbl_soal` (`id`, `kategori`, `tipe_soal`, `pertanyaan`, `gambar`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `kunci`, `tgl_input`) VALUES
(1, 'Monitoring CCTV', 'PG', 'Melalui CCTV Anda melihat operator melepas seatbelt ketika kendaraan berhenti di loading point, namun mesin masih hidup. Apa tindakan yang paling tepat?', '', 'Menegur dan mengingatkan agar saat mengoperasikan memakai seatbelt kembali', 'Mencatat temuan dan melaporkan sesuai SOP DMS', 'Menunggu sampai operator selesai bekerja', 'Menghubungi operator secara pribadi', 'A', '2026-07-19 08:41:49'),
(2, 'Monitoring CCTV', 'PG', 'Seorang operator terlihat menggunakan telepon genggam beberapa detik saat alat sedang idle. Apa yang harus dilakukan manpower monitoring?', '', 'Tidak perlu dilaporkan karena alat tidak bergerak', 'Melaporkan sebagai unsafe act sesuai prosedur', 'Menunggu sampai operator selesai shift', 'Menghapus rekaman agar tidak menimbulkan masalah', 'B', '2026-07-19 08:41:49'),
(3, 'Monitoring CCTV', 'PG', 'Dalam satu jam Anda menemukan tiga pekerja berbeda tidak menggunakan chin strap helm dengan benar. Prioritas tindakan yang paling tepat adalah...', '', 'Melaporkan setiap pelanggaran lengkap dengan waktu dan bukti', 'Menunggu supervisor menemukan sendiri', 'Menghubungi seluruh pekerja satu per satu', 'Menghapus rekaman setelah dicatat', 'A', '2026-07-19 08:41:49'),
(4, 'Monitoring CCTV', 'PG', 'Saat monitoring malam hari terlihat operator menunjukkan tanda-tanda mengantuk (fatigue) berulang kali. Apa keputusan terbaik?', '', 'Menunggu operator benar-benar tertidur', 'Segera melakukan eskalasi sesuai prosedur fatigue management', 'Menganggap hal tersebut normal pada shift malam', 'Mengirim pesan pribadi kepada operator', 'B', '2026-07-19 08:41:49'),
(5, 'Monitoring CCTV', 'PG', 'Unit Melakukan overtaking demi produktifitas, kenapa harus ditegur dan diingatkan ?', '', 'Karena dapat menyebabkan potensi tabrakan', 'Karena kendaraan di didepan lambat', 'Karena memperlambat cycle time jika lambat', 'Karena melanggar jam operasional', 'A', '2026-07-19 08:41:49'),
(6, 'Monitoring CCTV', 'PG', 'Ketika kamera kehilangan sinyal tepat saat terjadi aktivitas berisiko tinggi, tindakan operator monitoring adalah...', NULL, 'Menunggu kamera kembali normal', 'Segera melaporkan gangguan dan mencatat waktu kehilangan sinyal', 'Mengganti kamera sendiri', 'Menghapus laporan monitoring hari itu', 'B', '2026-07-19 08:41:49'),
(7, 'Monitoring CCTV', 'PG', 'Dalam proses monitoring, bukti yang paling kuat untuk mendukung laporan pelanggaran adalah...', NULL, 'Pendapat operator CCTV', 'Rekaman video disertai waktu kejadian', 'Cerita dari pekerja lain', 'Perkiraan supervisor', 'B', '2026-07-19 08:41:49'),
(8, 'Monitoring CCTV', 'PG', 'Dua operator melakukan pelanggaran yang sama, tetapi salah satunya merupakan teman dekat Anda. Apa tindakan profesional yang harus dilakukan?', NULL, 'Tidak melaporkan teman sendiri', 'Melaporkan keduanya secara objektif sesuai bukti', 'Melaporkan hanya satu operator', 'Menghapus rekaman teman sendiri', 'B', '2026-07-19 08:41:49'),
(9, 'Monitoring CCTV', 'PG', 'Saat melakukan review rekaman, Anda menemukan pelanggaran yang sebelumnya terlewat oleh operator shift sebelumnya. Apa tindakan terbaik?', NULL, 'Mengabaikannya karena bukan shift Anda', 'Tetap membuat laporan sesuai prosedur dengan waktu kejadian yang sebenarnya', 'Mengubah waktu kejadian agar sesuai shift Anda', 'Menghapus rekaman tersebut', 'B', '2026-07-19 08:41:49'),
(10, 'Monitoring CCTV', 'PG', 'Tujuan utama monitoring DMS adalah...', '', 'Mencari kesalahan pekerja', 'Mengurangi jumlah pengawas lapangan', 'Mencegah risiko dan meningkatkan kepatuhan terhadap prosedur keselamatan', 'Mengawasi produktivitas dengan memperhatikan keselamatan', 'C', '2026-07-19 08:41:49'),
(11, 'Monitoring CCTV', 'Essay', 'Anda menemukan operator tidak menggunakan seatbelt selama beberapa menit. Jelaskan langkah-langkah yang harus dilakukan sejak menemukan kejadian hingga proses pelaporan selesai.', '', NULL, NULL, NULL, NULL, NULL, '2026-07-19 08:41:49'),
(12, 'Monitoring CCTV', 'Essay', 'Mengapa bukti berupa rekaman CCTV sangat penting dalam proses investigasi suatu insiden? Jelaskan disertai contoh.', '', NULL, NULL, NULL, NULL, NULL, '2026-07-19 08:41:49'),
(13, 'Monitoring CCTV', 'Essay', 'Saat dua pelanggaran terjadi secara bersamaan pada lokasi berbeda, bagaimana Anda menentukan prioritas monitoring dan pelaporan? Jelaskan alasan Anda.', '', NULL, NULL, NULL, NULL, NULL, '2026-07-19 08:41:49'),
(14, 'Monitoring CCTV', 'Essay', 'Jelaskan risiko yang dapat terjadi apabila operator DMS terlambat melaporkan pelanggaran Critical Control.', '', NULL, NULL, NULL, NULL, NULL, '2026-07-19 08:41:49'),
(15, 'Monitoring CCTV', 'Essay', 'Menurut Anda, apa perbedaan antara unsafe act dan unsafe condition? Berikan masing-masing dua contoh yang mungkin ditemukan di area kerja saat ini', '', NULL, NULL, NULL, NULL, NULL, '2026-07-19 08:41:49'),
(16, 'Monitoring CCTV', 'Essay', 'Apabila kamera CCTV kehilangan sinyal saat aktivitas hauling sedang berlangsung, tindakan apa yang harus dilakukan untuk meminimalkan risiko operasional?', '', NULL, NULL, NULL, NULL, NULL, '2026-07-19 08:41:49'),
(17, 'Monitoring CCTV', 'Essay', 'Seorang pengawas meminta Anda untuk tidak melaporkan pelanggaran yang dilakukan salah satu operator karena dianggap akan membuat operator grounded. Apa yang akan Anda lakukan? Jelaskan alasan Anda.', '', NULL, NULL, NULL, NULL, NULL, '2026-07-19 08:41:49'),
(18, 'Monitoring CCTV', 'Essay', 'Bagaimana cara menjaga objektivitas dan integritas sebagai manpower monitoring meskipun pelanggaran dilakukan oleh rekan kerja sendiri?', '', NULL, NULL, NULL, NULL, NULL, '2026-07-19 08:41:49'),
(19, 'Monitoring CCTV', 'Essay', 'Jelaskan bagaimana hasil monitoring CCTV dapat digunakan sebagai dasar perbaikan budaya keselamatan kerja di perusahaan PT MHA !', '', NULL, NULL, NULL, NULL, NULL, '2026-07-19 08:41:49'),
(20, 'Monitoring CCTV', 'Essay', 'Menurut Anda, kompetensi apa saja yang harus dimiliki seorang manpower DMS agar mampu mendeteksi, menganalisis, dan melaporkan pelanggaran secara efektif? Jelaskan.', '', NULL, NULL, NULL, NULL, NULL, '2026-07-19 08:41:49');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `nik` varchar(20) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('Admin','User','Pengawas') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nik`, `nama`, `password`, `role`, `created_at`) VALUES
(1, '4617', 'Rexi Irawan', '$2y$10$SChwgiG2dUuyFxLDuVrseOGjIryAuxKQGmqqPO75V6Og2YDtm35BS', 'User', '2026-01-07 08:58:19'),
(2, '10020', 'Nur Habibi', '$2y$10$.lXvUe0ROwcxgZgjIhxppu8dOkb1KrdLgYIFbQRfbcIXfzhu2yUGS', 'User', '2026-01-07 09:05:52'),
(5, '1', 'Admin', '$2y$10$WpP9/Zyq4DCzlW79TgrSLuSczWQZ5kTZrRmoYczZTV/cE3Y7DWkFW', 'Admin', '2026-01-10 09:58:33'),
(6, 'admin1', 'admin1', '$2y$10$kK5qYDPjuflocmE57mCaEulyFhrK.175ZjpExgW0aL5t4EMW1biLG', 'Admin', '2026-01-11 08:04:03'),
(7, '4061', 'Benny Sulianto', '$2y$10$NFMEOeuFJtQRI4EgD/P9neJaYK3FsXcoe8y8CrCpe2Fcj7Q.Q0Sie', 'Pengawas', '2026-01-11 08:54:52'),
(8, '4288', 'Eggi Aditiya', '$2y$10$z8fPnamEId5Nok5KGLqz1OW/FoQoxO07yxim3nr0g0moce7hhib2O', 'User', '2026-01-11 09:08:45'),
(9, '6498', 'Aldianor Saputra', '$2y$10$Qlawp8mGqQXcB8mo0OrqUO8SDpjTifJzsOyGzQMFZukGZrs8wc5oC', 'User', '2026-01-11 09:10:24'),
(10, '10079', 'Alfred Rumanda Furba', '$2y$10$TlrsP2nyWxtS2cfEXw8BqeiQd4jgja81DzjJiaSVRWqffOZDGFpke', 'User', '2026-01-11 09:10:24'),
(11, '7963', 'Alvin Pratama Putra', '$2y$10$wwHv4p7xHj3PU.RfALU.x.FxiWhg2EA/anLD2FA2mrzQc5Bo27Te2', 'User', '2026-01-11 09:10:24'),
(12, '4107', 'Ari Alpan Pratama Tarigan', '$2y$10$2UldjPVBJmRnDK9ebEn...bfM5BnLBAeCRDDTFAdZd7yPgccv4KPS', 'Pengawas', '2026-01-11 09:10:24'),
(13, '6497', 'Farhan Ranggita Jayanto', '$2y$10$QBGrbgVJF7izMuI/SUsb1OR0olLP7uZp/klF.1.iaBBmT2IUzdbKi', 'User', '2026-01-11 09:10:24'),
(14, '9697', 'I Wayan Eka Mertha', '$2y$10$XsF3Ouey5KTXOqTMhEHyze1dlEZcKwshaVWmvCeR.dk8gXpoHl6rm', 'Pengawas', '2026-01-11 09:10:24'),
(15, '5605', 'Irvan Saputra', '$2y$10$qgqGfQzn9D0ptJBiqhIfAObFPdmGOKHBZ2vz7nlVdZUtlqocdOFnq', 'User', '2026-01-11 09:10:24'),
(16, '10097', 'Kevin Tandilangi', '$2y$10$zA.1uTLFzLoret595lNSZ.6BS1dGaR/4walwaHvu.CZtsSvKDqwdW', 'User', '2026-01-11 09:10:24'),
(17, '6893', 'Muhammad Rasyad Sultansyah', '$2y$10$FHyZt2qr7.17nEQonwYseukC5azIMJx9nsLAb/44jW2yJx.JmF1x6', 'User', '2026-01-11 09:10:24'),
(18, '4633', 'Ramadhan Maulana Tarhalim', '$2y$10$k3TUCQsAfU8NqeYfUpyoYu5e0upeUAk3edN5bfB1WMXTJ/UmbEZF2', 'User', '2026-01-11 09:10:24'),
(19, '8144', 'Rasyid', '$2y$10$kDmrgyFOpnZsmW8Qc8.wDeY.ZHmcN45S/.UTk0yN75hThuq07oC5C', 'Pengawas', '2026-01-11 09:10:24'),
(20, '6496', 'Samuel Nainggolan', '$2y$10$WUlsTgHwMJSAHgnrpcY6/Of6TBxBc5Zgt0TgNYJO4GpI20DMcMtu2', 'User', '2026-01-11 09:10:24'),
(21, '5538', 'Sayyidul Ahkam', '$2y$10$tUBQ8RvkfP3lt/S0y79rTei2oBuXK3KHglUM2TaIDv6RNWy6ZYybS', 'User', '2026-01-11 09:10:24'),
(22, '10078', 'Sony Firmansyah', '$2y$10$EDMyJ/DjEjW3aVx5tQIdYeCOsa0/HNojOtWxjsmEIlgRocFXxmvAS', 'User', '2026-01-11 09:10:24'),
(23, '8315', 'Taufik Hidayat', '$2y$10$HGd2WmAQsuVb1SxENZxzf.UVJSs9VdVIXLyOp.KQoo4BkqvTrQ2h.', 'User', '2026-01-11 09:10:24'),
(24, '6894', 'Taufik Syahrubi', '$2y$10$JgeFgil82V5k3WR8AGiUQOHk19a710kEpHp/hIGf4mu8Ev6yAQMwy', 'User', '2026-01-11 09:10:24'),
(25, '6916', 'Wawan Supaji', '$2y$10$kkavfeJnEY4hOqFO7/sA3uSl6elpHoaBZieMriqCN8eUUAgwaL2p.', 'User', '2026-01-11 09:10:25'),
(26, '4757', 'Widhi Nugraha Yogie Djatmiko', '$2y$10$BZm2aXA.1E9LqVmwCP9ON.fSGIETE.2zTo4scyyElTdOsXLny32AG', 'Pengawas', '2026-01-11 09:10:25'),
(27, '10476', 'Rian Pratiwi', '$2y$10$9y.ZrEvtaYaGS8J..53Z4u3lngoJGuOVmawnWKPQeZOllRb9o.OnW', 'User', '2026-01-11 09:10:25'),
(28, '10855', 'Muhammad Naufal Haidar Rasyid', '$2y$10$EwNdgnrya8ykCDyb.CS/MukD0GxFSGs71SLbgDW43ITaekgsuBLqK', 'User', '2026-01-11 09:10:25'),
(29, '10283', 'Cristionaldo', '$2y$10$RIDWduw1B3ERrFN2C2amp.WHCg2.U17j32Nsg90zNh3nzmILG6UjS', 'User', '2026-01-11 09:10:25'),
(30, '5393', 'Alfian Nur', '$2y$10$2PAWXOHjzCETQ6eMa.jPEujt4COqWX57KOXqFDRljROSoA4VPGXFG', 'User', '2026-01-11 09:10:25'),
(31, '11915', 'Zidan Ramadan', '$2y$10$B98L.JAlzZusD62uz5a6DON5KJcgOCssCYNljeCjDcbMR.5no3gLq', 'User', '2026-01-11 09:10:25'),
(32, '11986', 'Anwar Fathoni', '$2y$10$XIR.DC4mTeDYu2QBQbU13.XHgkYsbnH5.4WfK7IosCuyIK5qvAYO6', 'User', '2026-01-11 09:10:25'),
(33, '12012', 'Muhammad Vanronald Rezky Samosir', '$2y$10$UQLOwo/Lswl3ZsHbKrmcu.anzp6gvofXhkk5kj1gLat8Omik.5/zi', 'User', '2026-01-11 09:10:25'),
(34, '12407', 'Kevin Ps Karang', '$2y$10$YgtcHPiJH9d87wUuMf.2meHiDkkrVSS1WCH.g5OpMvV6JXk0N8fyq', 'User', '2026-01-11 09:10:25'),
(36, '12376', 'Budi Septian', '$2y$10$jRMgIII.fatxyL01LMm83.hwHuNj4iYFdgaeW3LaH0zVHdOv04BBK', 'User', '2026-01-11 09:10:25'),
(37, '12386', 'Achmad Nur Saleh', '$2y$10$rtT45kqK9Ed.WmkLw7nny.MBSzIYvKZ3ae2CoqS2gKR5SnLt72b8e', 'User', '2026-01-11 09:10:25'),
(38, '12414', 'Wiratama Ashari', '$2y$10$PZ9ryx2YCTB.pDOfw2HKUOoYb2q/ymsOG5VrJIFT6XvBf/ZpLhSxm', 'Pengawas', '2026-01-11 09:10:25'),
(39, '12568', 'Siprianus Jumri', '$2y$10$zcS/HObHb.AqYctMJVrDju.n.i5VskZxjNKUUQ1S81EXgw.AF7ZSu', 'User', '2026-01-11 09:10:25'),
(40, '12597', 'Vindysius Dwi Antonio', '$2y$10$1LU1zOHG/QgdQ2uEFKEstOflCvp4vV4YMo3rMHOD/1e5JmJPMtkhm', 'User', '2026-01-12 03:29:44'),
(41, '11624', 'Abdul Chair', '$2y$10$GnW.4dIe.SB.KpuwzcTHoemQbHM0f/7EfaxiuTZ3FU9O57IqzP3sO', 'User', '2026-08-03 05:50:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_jawaban`
--
ALTER TABLE `tbl_jawaban`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_nilai` (`id_nilai`);

--
-- Indexes for table `tbl_nilai`
--
ALTER TABLE `tbl_nilai`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_soal`
--
ALTER TABLE `tbl_soal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nik` (`nik`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_jawaban`
--
ALTER TABLE `tbl_jawaban`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=307;

--
-- AUTO_INCREMENT for table `tbl_nilai`
--
ALTER TABLE `tbl_nilai`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `tbl_soal`
--
ALTER TABLE `tbl_soal`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_jawaban`
--
ALTER TABLE `tbl_jawaban`
  ADD CONSTRAINT `tbl_jawaban_ibfk_1` FOREIGN KEY (`id_nilai`) REFERENCES `tbl_nilai` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
