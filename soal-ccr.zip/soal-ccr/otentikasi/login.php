<?php
session_start();

// Redirect jika sudah login
if (isset($_SESSION['user'])) {
    header("Location: ../index.php");
    exit;
}

require "../config.php";

// Ambil status alert
$status = $_GET['status'] ?? '';
$pesan  = $_GET['pesan'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - Project Control</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="icon" href="../assets/images/logo.png">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

html,
body{
    width:100%;
    height:100%;
    font-family:Arial, Helvetica, sans-serif;
}

body{
    display:flex;
    justify-content:center;
    align-items:center;
    position:relative;
    overflow:hidden;

    /* Background Full Screen */
    background:url("../assets/images/dms-cctv.jpg") no-repeat center center;
    background-size:cover;
    background-attachment:fixed;
}

/* Overlay Gelap */
body::before{
    content:"";
    position:absolute;
    inset:0;
    background:rgba(0,0,0,.60);
    z-index:0;
}

/* Login Card */
.login-card{
    position:relative;
    z-index:2;
    width:100%;
    max-width:420px;
    border:none;
    border-radius:18px;
    background:rgba(255,255,255,.95);
    backdrop-filter:blur(6px);
    box-shadow:0 20px 45px rgba(0,0,0,.45);
}

.card-body{
    padding:35px;
}

.login-header{
    display:flex;
    align-items:center;
    justify-content:center;
    margin-bottom:25px;
}

.login-logo{
    width:50px;
    height:50px;
    object-fit:contain;
    margin-right:12px;
}

.login-header h3{
    margin:0;
    font-weight:bold;
    color:#0d6efd;
}

.form-label{
    font-weight:600;
}

.form-control{
    height:48px;
    border-radius:10px;
}

.form-control:focus{
    box-shadow:none;
    border-color:#0d6efd;
}

.btn-login{
    height:48px;
    border-radius:10px;
    font-weight:bold;
    font-size:16px;
}

.footer-text{
    margin-top:20px;
    text-align:center;
    color:#666;
    font-size:13px;
}

@media(max-width:576px){

    body{
        padding:20px;
    }

    .card-body{
        padding:25px;
    }

}
</style>

</head>
<body>

<div class="card login-card">

    <div class="card-body">

        <div class="login-header">
            <img src="../assets/images/logo.png" class="login-logo" alt="Logo">
            <h3>Project Control</h3>
        </div>

        <?php if($status=='gagal'): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?= htmlspecialchars($pesan) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <form action="proses_login.php" method="POST">

            <div class="mb-3">
                <label class="form-label">NIK</label>
                <input
                    type="text"
                    name="nik"
                    class="form-control"
                    placeholder="Masukkan NIK"
                    required
                >
            </div>

            <div class="mb-4">
                <label class="form-label">Password</label>
                <input
                    type="password"
                    name="password"
                    class="form-control"
                    placeholder="Masukkan Password"
                    required
                >
            </div>

            <button class="btn btn-primary btn-login w-100" type="submit">
                Login
            </button>

        </form>

        <div class="footer-text">
            © <?= date('Y') ?> Project Control
        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>