<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $nik      = mysqli_real_escape_string($koneksi, $_POST['nik']);
    $password = $_POST['password'];

    // Ambil data user dari DB
    $query = mysqli_query($koneksi, "SELECT * FROM users WHERE nik='$nik' LIMIT 1");
    if (mysqli_num_rows($query) == 1) {
        $user = mysqli_fetch_assoc($query);
        var_dump($_POST);
    

        // Cek password
        if (password_verify($password, $user['password'])) {
            // Login berhasil → simpan session
            $_SESSION['user'] = [
                'id'   => $user['id'],
                'nik'  => $user['nik'],
                'nama' => $user['nama'],
                'role' => $user['role']
            ];

            header("Location: ../index.php");
            exit;
        } else {
            // Password salah
            header("Location: login.php?status=gagal&pesan=Password salah");
            exit;
        }
    } else {
        // NIK tidak ditemukan
        header("Location: login.php?status=gagal&pesan=NIK tidak ditemukan");
        exit;
    }
} else {
    header("Location: login.php");
    exit;
}
