<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../otentikasi/login.php");
    exit;
}

require "../config.php";
/** @var mysqli $koneksi */
$title = "Project Control - Daftar Nilai";

$user_id   = $_SESSION['user']['id'];
$user_role = $_SESSION['user']['role'];

// QUERY UTAMA: Join tbl_nilai dengan users
if ($user_role === 'Admin' || $user_role === 'Pengawas') {
    $sql = "SELECT tbl_nilai.*, users.nama, users.nik 
            FROM tbl_nilai 
            INNER JOIN users ON tbl_nilai.id_user = users.id 
            ORDER BY tbl_nilai.id DESC";
} else {
    $sql = "SELECT tbl_nilai.*, users.nama, users.nik 
            FROM tbl_nilai 
            INNER JOIN users ON tbl_nilai.id_user = users.id 
            WHERE tbl_nilai.id_user = '$user_id' 
            ORDER BY tbl_nilai.id DESC";
}

$result = mysqli_query($koneksi, $sql);

require "../template/header.php";
require "../template/navbar.php";
require "../template/sidebar.php";
?>

<div class="page-wrapper">
    <div class="container-fluid pt-4">
        <div class="row">
            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white py-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="card-title mb-0 fw-bold text-primary">
                                <i class="fas fa-clipboard-check me-2"></i> Daftar Nilai Kuis
                            </h4>
                            <div class="d-flex gap-2">
                                <?php if ($user_role !== 'User') : ?>
                                    <a href="ekspor_excel.php" class="btn btn-success btn-sm shadow-sm">
                                        <i class="fas fa-file-excel me-1"></i> Ekspor Excel
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th width="5%">NO</th>
                                        <th width="10%">NIK</th>
                                        <th>NAMA PESERTA</th>
                                        <th width="15%">KATEGORI</th>
                                        <th width="10%" class="text-center">BENAR</th>
                                        <th width="10%" class="text-center">SKOR</th>
                                        <th width="15%">TANGGAL</th>
                                        <th width="10%" class="text-center">AKSI</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    while ($row = mysqli_fetch_assoc($result)) :
                                        $is_lulus = $row['skor'] >= 70;

                                        // Arahkan semua role ke hasil_kuis.php (sesuai ketersediaan file Anda)
                                        // Gunakan ../test/ jika posisi daftar_nilai.php berada di folder admin/pengawas
                                        $link_view = "../test/hasil_kuis.php?id=" . $row['id'];
                                    ?>
                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td><span class="text-muted fw-bold"><?= htmlspecialchars($row['nik'] ?? '-') ?></span></td>
                                            <td>
                                                <div class="fw-bold"><?= htmlspecialchars($row['nama'] ?? 'Tanpa Nama') ?></div>
                                            </td>
                                            <td>
                                                <span class="badge rounded-pill border <?= (isset($row['kategori']) && $row['kategori'] == 'Dispatch') ? 'border-info text-info' : 'border-warning text-warning' ?> px-3">
                                                    <?= htmlspecialchars($row['kategori'] ?? '-') ?>
                                                </span>
                                            </td>
                                            <td class="text-center"><?= $row['jumlah_benar'] ?></td>
                                            <td class="text-center">
                                                <span class="badge <?= $is_lulus ? 'bg-primary' : 'bg-danger' ?> px-3 py-2">
                                                    <?= number_format($row['skor'], 0) ?>
                                                </span>
                                            </td>
                                            <td class="small">
                                                <?= isset($row['tanggal_kerja']) ? date('d/m/Y H:i', strtotime($row['tanggal_kerja'])) : '-' ?>
                                            </td>
                                            <td class="text-center">
                                                <div class="btn-group">
                                                    <a href="<?= $link_view ?>" class="btn btn-info btn-sm text-white" title="Lihat Detail">
                                                        <i class="fas fa-eye"></i>
                                                    </a>

                                                    <a href="cetak_pdf.php?id=<?= $row['id'] ?>" target="_blank" class="btn btn-danger btn-sm" title="Cetak PDF">
                                                        <i class="fas fa-file-pdf"></i>
                                                    </a>

                                                    <?php if ($user_role === 'Admin') : ?>
                                                        <a href="hapus_nilai.php?id=<?= $row['id'] ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Hapus data nilai ini?')" title="Hapus">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>

                                    <?php if (mysqli_num_rows($result) == 0) : ?>
                                        <tr>
                                            <td colspan="8" class="text-center py-4 text-muted small italic">Belum ada data nilai.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require "../template/footer.php"; ?>