<?php
session_start();
require "../config.php";
/** @var mysqli $koneksi */
// Proteksi: Hanya Admin dan Pengawas
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] === 'User') {
    exit("Akses Ditolak!");
}

// Set Header untuk Excel
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Laporan_Evaluasi_Kuis_" . date('Y-m-d_H-i') . ".xls");
?>

<table border="1">
    <thead>
        <tr style="background-color: #1a73e8; color: white; font-weight: bold;">
            <th width="50">NO</th>
            <th width="150">NIK</th>
            <th width="250">NAMA LENGKAP</th>
            <th width="150" style="background-color: #fbbc04; color: black;">KATEGORI</th>
            <th width="100">SKOR PG</th>
            <th width="180">TANGGAL UJIAN</th>
            <th width="120">STATUS</th>
            <th style="background-color: #28a745; color: white; width: 600px;">REVIEW JAWABAN (Pertanyaan -> Jawaban User)</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        // Query disesuaikan dengan tabel 'users' dan mengambil kolom 'kategori'
        $query_nilai = mysqli_query($koneksi, "SELECT n.*, u.nama, u.nik 
                                              FROM tbl_nilai n 
                                              JOIN users u ON n.id_user = u.id 
                                              ORDER BY n.id DESC");

        while ($row = mysqli_fetch_assoc($query_nilai)) {
            $id_nilai = $row['id'];
            $status = ($row['skor'] >= 70) ? "LULUS" : "REMEDIAL";

            // Menggunakan tanggal_kerja yang baru ditambahkan
            $tanggal = isset($row['tanggal_kerja']) ? date('d/m/Y H:i', strtotime($row['tanggal_kerja'])) : '-';

            // Ambil detail pertanyaan dan jawaban untuk kolom review
            $q_jawaban = mysqli_query($koneksi, "SELECT s.pertanyaan, j.jawaban_user, s.tipe_soal 
                                                FROM tbl_jawaban j 
                                                JOIN tbl_soal s ON j.id_soal = s.id 
                                                WHERE j.id_nilai = '$id_nilai' 
                                                ORDER BY s.id ASC");

            $review_list = "";
            $i = 1;
            while ($j = mysqli_fetch_assoc($q_jawaban)) {
                $tipe = ($j['tipe_soal'] == 'PG') ? "[PG]" : "[ESSAY]";
                // Membersihkan tag HTML dan karakter aneh agar tidak merusak format Excel
                $pertanyaan_bersih = htmlspecialchars(strip_tags($j['pertanyaan']));
                $jawaban_bersih = htmlspecialchars($j['jawaban_user']);

                $review_list .= $i . ". " . $tipe . " " . $pertanyaan_bersih . "&#10;   Jwb: " . $jawaban_bersih . "&#10;&#10;";
                $i++;
            }

            echo "<tr>
                <td align='center' valign='top'>$no</td>
                <td valign='top' style='mso-number-format:\"\@\"'>{$row['nik']}</td>
                <td valign='top'>" . strtoupper($row['nama']) . "</td>
                <td align='center' valign='top' style='background-color: #fff9e6;'><b>" . strtoupper($row['kategori']) . "</b></td>
                <td align='center' valign='top'>{$row['skor']}</td>
                <td valign='top' align='center'>$tanggal</td>
                <td align='center' valign='top' style='color: " . ($status == 'LULUS' ? '#28a745' : '#dc3545') . "; font-weight: bold;'>$status</td>
                <td valign='top' style='white-space: pre-wrap; background-color: #f9f9f9; mso-number-format:\"\@\"'>$review_list</td>
            </tr>";
            $no++;
        }
        ?>
    </tbody>
</table>