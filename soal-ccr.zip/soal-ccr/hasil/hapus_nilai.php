<?php
session_start();
require "../config.php";

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'Admin') {
    header("Location: hasil.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);
    if (mysqli_query($koneksi, "DELETE FROM tbl_nilai WHERE id = '$id'")) {
        header("Location: hasil.php?pesan=hapus_sukses");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
