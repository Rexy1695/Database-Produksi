<?php
session_start();
require "../config.php";

/** @var mysqli $koneksi */

// ======================================
// CEK LOGIN
// ======================================
if (!isset($_SESSION['user'])) {
    header("Location: ../otentikasi/login.php");
    exit;
}

// ======================================
// AMBIL ID NILAI
// ======================================
$id_nilai = isset($_GET['id']) ? mysqli_real_escape_string($koneksi, $_GET['id']) : '';

if (empty($id_nilai)) {
    die("ID Nilai tidak ditemukan.");
}

// ======================================
// ROLE USER
// ======================================
$user_role = strtolower($_SESSION['user']['role'] ?? '');
$boleh_lihat_kunci = in_array($user_role, ['admin', 'pengawas']);

// ======================================
// DATA PESERTA
// ======================================
$sql_utama = "
SELECT n.*, u.nama, u.nik
FROM tbl_nilai n
JOIN users u ON n.id_user = u.id
WHERE n.id='$id_nilai'
LIMIT 1
";

$query_utama = mysqli_query($koneksi, $sql_utama);
$data = mysqli_fetch_assoc($query_utama);

if (!$data) {
    die("Data laporan tidak ditemukan!");
}

$kategori_kuis = $data['kategori'];
$is_lulus = ($data['skor'] >= 70);

// ======================================
// AMBIL SOAL
// ======================================
$sql_soal = "
SELECT s.*, j.jawaban_user, j.status_jawaban
FROM tbl_soal s
LEFT JOIN tbl_jawaban j ON s.id=j.id_soal AND j.id_nilai='$id_nilai'
WHERE s.kategori='$kategori_kuis'
ORDER BY FIELD(s.tipe_soal, 'PG', 'Essay'), s.id ASC
";

$query_soal = mysqli_query($koneksi, $sql_soal);
if (!$query_soal) {
    die("Gagal mengambil soal : " . mysqli_error($koneksi));
}

// tampung semua soal ke dalam array untuk mempermudah pemecahan halaman
$semua_soal = [];
while ($row = mysqli_fetch_assoc($query_soal)) {
    $semua_soal[] = $row;
}
$total_soal = count($semua_soal);

// ======================================
// FILTER HTML
// ======================================
function safe_html($text)
{
    return htmlspecialchars($text ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Report    Hasil <?= safe_html($data['nama']) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap');

        * {
            box-sizing: border-box;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #e2e8f0;
            margin: 0;
            padding: 20px 0;
        }

        /* ==========================
        KERTAS A4 & HALAMAN
        ========================== */
        .wrapper {
            background: white;
            width: 210mm;
            min-height: 297mm;
            margin: 0 auto 20px auto;
            padding: 15mm;
            box-shadow: 0 10px 30px rgba(0, 0, 0, .15);
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .page-break-container {
            page-break-after: always;
            break-after: page;
        }

        .main-content {
            width: 100%;
            flex-grow: 1;
        }

        /* ==========================
        HEADER
        ========================== */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #e5e7eb;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-img {
            height: 45px;
            max-width: 80px;
        }

        .brand-info h1 {
            margin: 0;
            font-size: 17px;
            font-weight: 800;
            color: #0f172a;
        }

        .brand-info p {
            margin: 2px 0;
            font-size: 10px;
            color: #64748b;
        }

        .badge-status {
            padding: 7px 12px;
            font-size: 10px;
            font-weight: 800;
            border-radius: 6px;
            border: 2px solid;
        }

        .status-pass {
            background: #dcfce7;
            border-color: #22c55e;
            color: #15803d;
        }

        .status-fail {
            background: #fee2e2;
            border-color: #ef4444;
            color: #b91c1c;
        }

        /* ==========================
        IDENTITAS
        ========================== */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 20px;
        }

        .info-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 10px;
        }

        .info-card label {
            display: block;
            font-size: 9px;
            font-weight: 700;
            color: #64748b;
            margin-bottom: 4px;
        }

        .info-card strong {
            font-size: 12px;
            color: #0f172a;
        }

        /* ==========================
        SOAL
        ========================== */
        .questions-container {
            width: 100%;
        }

        .question-box {
            border: 1px solid #dbe3ef;
            border-radius: 10px;
            padding: 12px;
            margin-bottom: 12px;
            break-inside: avoid;
            page-break-inside: avoid;
        }

        .question-title {
            font-size: 12px;
            font-weight: 700;
            line-height: 1.5;
            margin-bottom: 12px;
            word-break: break-word;
        }

        .option-item {
            padding: 8px 10px;
            border-radius: 6px;
            border: 1px solid #dbe3ef;
            margin-bottom: 7px;
            font-size: 11px;
            line-height: 1.4;
            word-break: break-word;
        }

        .option-user {
            background: #eff6ff;
            border-color: #2563eb;
            font-weight: 700;
        }

        .option-key {
            background: #dcfce7;
            border-color: #16a34a;
            color: #166534;
            font-weight: 700;
        }

        .option-wrong {
            background: #fee2e2;
            border-color: #dc2626;
            color: #991b1b;
        }

        /* ==========================
        ESSAY
        ========================== */
        .essay-box {
            background: #f8fafc;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            padding: 12px;
            font-size: 11px;
            min-height: 80px;
            word-break: break-word;
        }

        /* ==========================
        FOOTER SIGNATURE
        ========================== */
        .footer-signature {
            margin-top: 30px;
            break-inside: avoid;
            page-break-inside: avoid;
            width: 100%;
        }

        .ttd-table {
            width: 100%;
            border-collapse: collapse;
        }

        .ttd-table td {
            text-align: center;
            padding: 10px;
            width: 50%;
        }

        .sign-title {
            display: block;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 45px;
        }

        .sign-line {
            width: 80%;
            border-bottom: 1px solid #000;
            margin: auto;
        }

        .sign-name {
            font-size: 13px;
            font-weight: 800;
            margin-top: 5px;
        }

        .sign-meta {
            font-size: 10px;
            color: #64748b;
        }

        /* ==========================
        BUTTON
        ========================== */
        .print-btn {
            position: fixed;
            right: 25px;
            bottom: 25px;
            background: #0f172a;
            color: white;
            padding: 12px 20px;
            border: 0;
            border-radius: 30px;
            cursor: pointer;
            z-index: 999;
        }

        /* ==========================
        PRINT A4 SPECIFIC STYLE
        ========================== */
        @media print {
            body {
                background: white;
                padding: 0;
            }

            .wrapper {
                width: 210mm;
                height: 297mm;
                margin: 0;
                padding: 15mm;
                box-shadow: none;
                page-break-after: always;
                break-after: page;
            }

            .wrapper:last-child {
                page-break-after: avoid;
                break-after: avoid;
            }

            .print-btn {
                display: none;
            }
        }
    </style>
</head>

<body>

    <button onclick="window.print()" class="print-btn">
        <i class="fas fa-print"></i> CETAK LAPORAN
    </button>

    <?php
    $limit_per_halaman = 5;
    $no = 1;

    // Lakukan pemecahan array soal per 5 item
    for ($i = 0; $i < $total_soal; $i += $limit_per_halaman):
        $soal_halaman_ini = array_slice($semua_soal, $i, $limit_per_halaman);
        $apakah_halaman_terakhir = (($i + $limit_per_halaman) >= $total_soal);
    ?>

        <div class="wrapper <?= !$apakah_halaman_terakhir ? 'page-break-container' : '' ?>">
            <div class="main-content">

                <!-- HEADER HANYA DI HALAMAN PERTAMA -->
                <?php if ($i == 0): ?>
                    <div class="header">
                        <div class="header-left">
                            <img src="../assets/images/logo.png" class="logo-img">
                            <div class="brand-info">
                                <h1>BERITA ACARA HASIL</h1>
                                <p>Digital Assessment Center • Mandiri Services</p>
                            </div>
                        </div>
                        <div class="badge-status <?= $is_lulus ? 'status-pass' : 'status-fail' ?>">
                            <?= $is_lulus ? 'LULUS / PASSED' : 'GAGAL / FAILED' ?>
                        </div>
                    </div>

                    <!-- IDENTITAS PESERTA HANYA DI HALAMAN PERTAMA -->
                    <div class="info-grid">
                        <div class="info-card">
                            <label>NAMA PESERTA</label>
                            <strong><?= safe_html($data['nama']) ?></strong>
                        </div>
                        <div class="info-card">
                            <label>NIK</label>
                            <strong><?= safe_html($data['nik']) ?></strong>
                        </div>
                        <div class="info-card" style="background:#2563eb; border:none;">
                            <label style="color:white">SKOR EVALUASI</label>
                            <strong style="color:white; font-size:16px;">
                                <?= number_format($data['skor'], 0) ?> /100
                            </strong>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Sub Header Ringkas Untuk Halaman 2 dan seterusnya -->
                    <div style="text-align: right; font-size: 10px; color: #94a3b8; border-bottom: 1px solid #e2e8f0; padding-bottom: 5px; margin-bottom: 15px;">
                        Laporan Hasil Assessment - <?= safe_html($data['nama']) ?> (Halaman <?= ($i / $limit_per_halaman) + 1 ?>)
                    </div>
                <?php endif; ?>

                <!-- DAFTAR SOAL PADA HALAMAN INI -->
                <div class="questions-container">
                    <?php
                    foreach ($soal_halaman_ini as $soal):
                        $is_pg = (strtoupper(trim($soal['tipe_soal'])) == "PG");
                    ?>
                        <div class="question-box">
                            <div class="question-title">
                                <?= $no++ ?>. <?= safe_html($soal['pertanyaan']) ?>
                            </div>

                            <?php if ($is_pg): ?>
                                <?php
                                $pilihan = [
                                    "A" => $soal['opsi_a'],
                                    "B" => $soal['opsi_b'],
                                    "C" => $soal['opsi_c'],
                                    "D" => $soal['opsi_d']
                                ];
                                $jawaban_user = strtoupper(trim($soal['jawaban_user'] ?? ''));
                                $kunci = strtoupper(trim($soal['kunci'] ?? ''));

                                foreach ($pilihan as $huruf => $isi):
                                    $is_user = ($jawaban_user == $huruf);
                                    $is_key = ($kunci == $huruf);
                                    $class = "option-item";

                                    if ($boleh_lihat_kunci) {
                                        if ($is_key) {
                                            $class .= " option-key";
                                        } elseif ($is_user && !$is_key) {
                                            $class .= " option-wrong";
                                        }
                                    } else {
                                        if ($is_user) {
                                            $class .= " option-user";
                                        }
                                    }
                                ?>
                                    <div class="<?= $class ?>">
                                        <strong><?= $huruf ?>. </strong> <?= safe_html($isi) ?>

                                        <?php if ($boleh_lihat_kunci && $is_key): ?>
                                            <span style="float:right;font-size:10px"><i class="fas fa-check-circle"></i> KUNCI</span>
                                        <?php endif; ?>

                                        <?php if (!$boleh_lihat_kunci && $is_user): ?>
                                            <span style="float:right;font-size:10px"><i class="fas fa-user-check"></i> JAWABAN ANDA</span>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>

                            <?php else: ?>
                                <!-- ESSAY -->
                                <div class="essay-box">
                                    <div style="font-weight:700; font-size:10px; color:#64748b; margin-bottom:8px;">JAWABAN PESERTA</div>
                                    <?= !empty($soal['jawaban_user']) ? nl2br(safe_html($soal['jawaban_user'])) : "-" ?>
                                </div>

                                <?php if ($boleh_lihat_kunci && !empty($soal['kunci'])): ?>
                                    <div style="margin-top:10px; padding:10px; background:#dcfce7; border:1px solid #16a34a; border-radius:8px; color:#166534; font-size:11px;">
                                        <strong><i class="fas fa-key"></i> STANDAR JAWABAN</strong><br><br>
                                        <?= nl2br(safe_html($soal['kunci'])) ?>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- TANDA TANGAN DIBAWAH HANYA DITAMPILKAN PADA HALAMAN TERAKHIR -->
            <?php if ($apakah_halaman_terakhir): ?>
                <div class="footer-signature">
                    <table class="ttd-table">
                        <tr>
                            <td>
                                <span class="sign-title">Tanda Tangan Peserta,</span>
                                <div class="sign-line"></div>
                                <div class="sign-name"><?= safe_html($data['nama']) ?></div>
                                <div class="sign-meta">NIK. <?= safe_html($data['nik']) ?></div>
                            </td>
                            <td>
                                <span class="sign-title">
                                    Tabang, <?= date('d F Y') ?><br>Admin / Pengawas,
                                </span>
                                <div class="sign-line"></div>
                                <div class="sign-name">
                                    <?= $boleh_lihat_kunci ? safe_html($_SESSION['user']['nama'] ?? 'Admin') : "Pengawas" ?>
                                </div>
                                <div class="sign-meta">Verification System Digital</div>
                            </td>
                        </tr>
                    </table>

                    <div style="text-align:center; margin-top:25px; font-size:10px; color:#94a3b8; border-top:1px dashed #cbd5e1; padding-top:10px;">
                        Dokumen ini sah secara digital.<br>
                        Security Hash : <strong><?= strtoupper(substr(md5($id_nilai), 0, 16)) ?></strong>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    <?php endfor; ?>

</body>

</html>