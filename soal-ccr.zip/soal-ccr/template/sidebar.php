<!-- ============================================================== -->
<!-- End Topbar header -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
<aside class="left-sidebar" data-sidebarbg="skin6">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <!-- User Profile-->
                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                        href="<?= $main_url ?>/index.php" aria-expanded="false"><i class="me-3 far fa-clock fa-fw"
                            aria-hidden="true"></i><span class="hide-menu">Dashboard</span></a></li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link"
                        href="<?= $main_url ?>/user/user.php" aria-expanded="false">
                        <i class="me-3 fas fa-users" aria-hidden="true"></i>
                        <span class="hide-menu"> Users</span>
                    </a>
                </li>
                <?php if ($_SESSION['user']['role'] === 'Admin' || $_SESSION['user']['role'] === 'Pengawas') : ?>
                    <li class="sidebar-item">
                        <a class="sidebar-link waves-effect waves-dark sidebar-link"
                            href="<?= $main_url ?>/ujian/input.php" aria-expanded="false">
                            <i class="me-3 far fa-file-alt" aria-hidden="true"></i>
                            <span class="hide-menu">Input Soal</span>
                        </a>
                    </li>
                <?php endif; ?>
                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                        href="<?= $main_url ?>/test/ujian.php" aria-expanded="false"><i class="me-3 far fa-hourglass"
                            aria-hidden="true"></i><span class="hide-menu">Kerjakan Soal</span></a></li>
                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                        href="<?= $main_url ?>/hasil/hasil.php" aria-expanded="false"><i class="me-3  fas fa-star"
                            aria-hidden="true"></i><span class="hide-menu">Lihat Hasil</span></a></li>
                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                        href="<?= $main_url ?>/otentikasi/logout.php" aria-expanded="false"><i class="me-3 fas fa-history"
                            aria-hidden="true"></i><span class="hide-menu">Logout</span></a></li>
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>