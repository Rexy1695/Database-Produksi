 <footer class="footer text-center">
     © <a href="https://www.wrappixel.com/"></a> Project Control Departemen</a>
 </footer>

 </div>

 </div>
 
 <script src="<?= $main_url ?>/./assets/plugins/jquery/dist/jquery.min.js"></script>
 <!-- Bootstrap tether Core JavaScript -->
 <script src="<?= $main_url ?>/./assets/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
 <script src="<?= $main_url ?>/js/app-style-switcher.js"></script>
 <!--Wave Effects -->
 <script src="<?= $main_url ?>/js/waves.js"></script>
 <!--Menu sidebar -->
 <script src="<?= $main_url ?>/js/sidebarmenu.js"></script>
 <!--Custom JavaScript -->
 <script src="<?= $main_url ?>/js/custom.js"></script>
 <!--This page JavaScript -->
 <!--flot chart-->
 <script src="<?= $main_url ?>/./assets/plugins/flot/jquery.flot.js"></script>
 <script src="<?= $main_url ?>/./assets/plugins/flot.tooltip/js/jquery.flot.tooltip.min.js"></script>
 <script src="<?= $main_url ?>/js/pages/dashboards/dashboard1.js"></script>
 </body>