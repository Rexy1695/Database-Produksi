<?php

/**
 * =========================================================================
 * CCR EXPORT EXCEL REKAP PRODUKSI HAULING
 * FINAL FIX HM/KM SEPARATION
 * =========================================================================
 */

require_once 'config.php';


$tanggal = $_GET['tanggal'] ?? date('Y-m-d');


/**
 * Ambil urutan custom dari textarea
 */
$urutan_input = $_GET['urutan'] ?? '';

$urutanUnitCustom = array_values(
    array_filter(
        array_map(
            'trim',
            preg_split(
                '/[\s,\r\n]+/',
                $urutan_input
            )
        )
    )
);



header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Rekap_HM_All_Area_$tanggal.xls");
header("Pragma: no-cache");
header("Expires: 0");



/**
 * QUERY DATA
 * Jangan gunakan SELECT *
 * agar HM tidak tertukar KM
 */

$sql = "

SELECT

id,
area,
unit_km,

ritase,
night_ritase,


day_nik,
day_nama,
day_unit_hm,
day_hm_start,
day_hm_end,
day_hm_hours,


night_nik,
night_nama,
night_unit_hm,
night_hm_start,
night_hm_end,
night_hm_hours,


day_km_awal,
day_km_akhir,
day_km_total,


night_km_awal,
night_km_akhir,
night_km_total


FROM transaksi_produksi


WHERE tanggal=:tanggal

AND unit_km IS NOT NULL

AND unit_km <> ''


ORDER BY id ASC

";


$stmt = $pdo->prepare($sql);

$stmt->execute([
    ':tanggal' => $tanggal
]);


$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);





/**
 * MASTER UNIT
 */

$masterUnits = [];


foreach ($rows as $row) {


    $unit = trim($row['unit_km']);



    if (!isset($masterUnits[$unit])) {


        $masterUnits[$unit] = [


            'DAY' => [

                'nik' => '',
                'nama' => '',

                'ritase' => 0,

                // HM ASLI
                'hm_start' => 0,
                'hm_end' => 0,
                'hours' => 0,


                // KM ASLI
                'km_awal' => 0,
                'km_akhir' => 0,


                'drivers' => []

            ],



            'NIGHT' => [

                'nik' => '',
                'nama' => '',

                'ritase' => 0,


                // HM ASLI
                'hm_start' => 0,
                'hm_end' => 0,
                'hours' => 0,


                // KM ASLI
                'km_awal' => 0,
                'km_akhir' => 0,


                'drivers' => []

            ]


        ];
    }
}

/**
 * ============================================================
 * PROSES DATA PER UNIT
 * HM DAN KM DIPISAH TOTAL
 * ============================================================
 */

foreach ($rows as $row) {


    $unit = trim($row['unit_km']);



    /*
    ============================================================
    DAY SHIFT
    ============================================================
    */


    $dayStart = (float)$row['day_hm_start'];
    $dayEnd   = (float)$row['day_hm_end'];



    if (
        !empty($row['day_nik'])
        ||
        $dayStart > 0
        ||
        $dayEnd > 0
        ||
        $row['ritase'] > 0
    ) {


        // RITASE DAY
        $masterUnits[$unit]['DAY']['ritase']
            +=
            (float)$row['ritase'];




        /*
         * SIMPAN HM DAY
         * HANYA DARI day_hm_start
         * HANYA DARI day_hm_end
         */

        if ($dayStart > 0) {

            if (
                $masterUnits[$unit]['DAY']['hm_start'] == 0
            ) {

                $masterUnits[$unit]['DAY']['hm_start']
                    =
                    $dayStart;
            }
        }




        if ($dayEnd > 0) {


            if (
                $dayEnd >
                $masterUnits[$unit]['DAY']['hm_end']
            ) {

                $masterUnits[$unit]['DAY']['hm_end']
                    =
                    $dayEnd;
            }
        }




        if ($dayEnd >= $dayStart) {


            $masterUnits[$unit]['DAY']['hours']
                +=
                ($dayEnd - $dayStart);
        }




        if (
            empty($masterUnits[$unit]['DAY']['nik'])
            &&
            !empty($row['day_nik'])
        ) {


            $masterUnits[$unit]['DAY']['nik']
                =
                $row['day_nik'];


            $masterUnits[$unit]['DAY']['nama']
                =
                $row['day_nama'];
        }



        if (!empty($row['day_nik'])) {


            $masterUnits[$unit]['DAY']['drivers'][] = $row;
        }
    }





    /*
    ============================================================
    NIGHT SHIFT
    ============================================================
    */


    $nightStart = (float)$row['night_hm_start'];
    $nightEnd = (float)$row['night_hm_end'];



    if (
        !empty($row['night_nik'])
        ||
        $nightStart > 0
        ||
        $nightEnd > 0
        ||
        $row['night_ritase'] > 0
    ) {



        // RITASE NIGHT

        $masterUnits[$unit]['NIGHT']['ritase']
            +=
            (float)$row['night_ritase'];





        /*
         * SIMPAN HM NIGHT  
         * TIDAK PERNAH MENGAMBIL KM
         */


        if ($nightStart > 0) {



            if (
                $masterUnits[$unit]['NIGHT']['hm_start'] == 0
                ||
                $nightStart <
                $masterUnits[$unit]['NIGHT']['hm_start']
            ) {


                $masterUnits[$unit]['NIGHT']['hm_start']
                    =
                    $nightStart;
            }
        }





        if ($nightEnd > 0) {



            if (
                $nightEnd >
                $masterUnits[$unit]['NIGHT']['hm_end']
            ) {


                $masterUnits[$unit]['NIGHT']['hm_end']
                    =
                    $nightEnd;
            }
        }





        if ($nightEnd >= $nightStart) {


            $masterUnits[$unit]['NIGHT']['hours']
                +=
                ($nightEnd - $nightStart);
        }





        if (
            empty($masterUnits[$unit]['NIGHT']['nik'])
            &&
            !empty($row['night_nik'])
        ) {


            $masterUnits[$unit]['NIGHT']['nik']
                =
                $row['night_nik'];


            $masterUnits[$unit]['NIGHT']['nama']
                =
                $row['night_nama'];
        }




        if (!empty($row['night_nik'])) {


            $masterUnits[$unit]['NIGHT']['drivers'][] = $row;
        }
    }





    /*
    ============================================================
    KM DAY
    ============================================================
    */


    $dayKmAwal = (float)$row['day_km_awal'];
    $dayKmAkhir = (float)$row['day_km_akhir'];



    if ($dayKmAwal > 0) {


        if (
            $masterUnits[$unit]['DAY']['km_awal'] == 0
            ||
            $dayKmAwal <
            $masterUnits[$unit]['DAY']['km_awal']
        ) {

            $masterUnits[$unit]['DAY']['km_awal']
                =
                $dayKmAwal;
        }
    }



    if ($dayKmAkhir > 0) {


        if (
            $dayKmAkhir >
            $masterUnits[$unit]['DAY']['km_akhir']
        ) {

            $masterUnits[$unit]['DAY']['km_akhir']
                =
                $dayKmAkhir;
        }
    }

    /**
     * ============================================================
     * LANJUTAN KM NIGHT
     * ============================================================
     */


    $nightKmAwal = (float)$row['night_km_awal'];
    $nightKmAkhir = (float)$row['night_km_akhir'];



    if ($nightKmAwal > 0) {


        if (
            $masterUnits[$unit]['NIGHT']['km_awal'] == 0
            ||
            $nightKmAwal <
            $masterUnits[$unit]['NIGHT']['km_awal']
        ) {


            $masterUnits[$unit]['NIGHT']['km_awal']
                =
                $nightKmAwal;
        }
    }



    if ($nightKmAkhir > 0) {


        if (
            $nightKmAkhir >
            $masterUnits[$unit]['NIGHT']['km_akhir']
        ) {


            $masterUnits[$unit]['NIGHT']['km_akhir']
                =
                $nightKmAkhir;
        }
    }
}



/**
 * ============================================================
 * FALLBACK HM / KM KOSONG
 *
 * PRIORITAS:
 * 1. Ambil dari KM98 SHIFT YANG SAMA
 * 2. Jika KM98 kosong, ambil HM/KM AKHIR shift DAY unit sendiri
 *
 * Tidak mengambil HM/KM awal shift DAY
 * ============================================================
 */


$referensiKM98 = [

    'DAY' => [
        'hm_start' => 0,
        'hm_end' => 0,
        'km_awal' => 0,
        'km_akhir' => 0
    ],

    'NIGHT' => [
        'hm_start' => 0,
        'hm_end' => 0,
        'km_awal' => 0,
        'km_akhir' => 0
    ]

];



$unitKM98 = null;

foreach ($masterUnits as $u => $v) {

    if (str_replace(' ', '', strtoupper($u)) == 'KM98') {

        $unitKM98 = $u;
        break;
    }
}


if ($unitKM98 !== null) {


    foreach (['DAY', 'NIGHT'] as $shift) {


        // Ambil hanya nilai AKHIR sebagai referensi fallback

        $referensiKM98[$shift]['hm_end']
            =
            $masterUnits[$unitKM98][$shift]['hm_end'];


        $referensiKM98[$shift]['km_akhir']
            =
            $masterUnits[$unitKM98][$shift]['km_akhir'];
    }
}


foreach ($masterUnits as $unit => &$data) {


    foreach (['DAY', 'NIGHT'] as $shift) {


        /*
        =================================================
        JIKA SHIFT KOSONG
        AMBIL NILAI AKHIR SHIFT YANG SAMA DARI KM98
        =================================================
        */


        if ($data[$shift]['hm_start'] <= 0) {


            if ($referensiKM98[$shift]['hm_end'] > 0) {

                $data[$shift]['hm_start']
                    =
                    $referensiKM98[$shift]['hm_end'];
            } elseif (
                $shift == 'NIGHT'
                &&
                $data['DAY']['hm_end'] > 0
            ) {

                $data[$shift]['hm_start']
                    =
                    $data['DAY']['hm_end'];
            }
        }




        if ($data[$shift]['hm_end'] <= 0) {


            if ($referensiKM98[$shift]['hm_end'] > 0) {

                $data[$shift]['hm_end']
                    =
                    $referensiKM98[$shift]['hm_end'];
            } elseif (
                $shift == 'NIGHT'
                &&
                $data['DAY']['hm_end'] > 0
            ) {

                $data[$shift]['hm_end']
                    =
                    $data['DAY']['hm_end'];
            }
        }





        /*
        =================================================
        KM
        NIGHT KOSONG AMBIL KM AKHIR
        =================================================
        */


        if ($data[$shift]['km_awal'] <= 0) {


            if ($referensiKM98[$shift]['km_akhir'] > 0) {

                $data[$shift]['km_awal']
                    =
                    $referensiKM98[$shift]['km_akhir'];
            } elseif (
                $shift == 'NIGHT'
                &&
                $data['DAY']['km_akhir'] > 0
            ) {

                $data[$shift]['km_awal']
                    =
                    $data['DAY']['km_akhir'];
            }
        }





        if ($data[$shift]['km_akhir'] <= 0) {


            if ($referensiKM98[$shift]['km_akhir'] > 0) {

                $data[$shift]['km_akhir']
                    =
                    $referensiKM98[$shift]['km_akhir'];
            } elseif (
                $shift == 'NIGHT'
                &&
                $data['DAY']['km_akhir'] > 0
            ) {

                $data[$shift]['km_akhir']
                    =
                    $data['DAY']['km_akhir'];
            }
        }
    }
}


unset($data);
/**
 * ============================================================
 * SORTING UNIT SESUAI URUTAN COPY PASTE
 * ============================================================
 */


$indexUnit = [];

foreach ($urutanUnitCustom as $i => $u) {

    $indexUnit[strtoupper(trim($u))] = $i;
}



uksort(
    $masterUnits,
    function ($a, $b) use ($indexUnit) {


        $a = strtoupper(trim($a));
        $b = strtoupper(trim($b));


        $adaA = array_key_exists($a, $indexUnit);
        $adaB = array_key_exists($b, $indexUnit);



        if ($adaA && $adaB) {

            return $indexUnit[$a] - $indexUnit[$b];
        }



        if ($adaA) {

            return -1;
        }



        if ($adaB) {

            return 1;
        }



        return strnatcasecmp($a, $b);
    }
);




?>

<html>

<head>

    <meta charset="UTF-8">


    <style>
        body,
        table {
            font-family: Calibri;
            font-size: 11pt;
            font-weight: normal;
        }

        table {
            border-collapse: collapse;
            mso-displayed-decimal-separator: "\.";
            mso-displayed-thousand-separator: "\,";
        }

        .header {
            background: #0F172A;
            color: white;
            font-weight: 400;
            /* 400 = normal, bukan bold */
            text-align: center;
            vertical-align: middle;
            border-top: .5pt dashed #000;
            border-right: .5pt dashed #000;
            border-bottom: .5pt dashed #000;
            border-left: .5pt dashed #000;
            mso-border-top-alt: .5pt dashed #000;
            mso-border-right-alt: .5pt dashed #000;
            mso-border-bottom-alt: .5pt dashed #000;
            mso-border-left-alt: .5pt dashed #000;
        }

        .group {
            background: #D9E1F2;
            font-weight: 400;
            text-align: center;
            vertical-align: middle;
            border: .5pt dashed #000;
            mso-border-alt: .5pt dashed #000;
        }

        .cell {
            border: .5pt dashed #000;
            mso-border-alt: .5pt dashed #000;
            text-align: center;
            vertical-align: middle;
            font-weight: 400;
        }

        .center {
            text-align: center;
            font-weight: 400;
        }

        .text {
            mso-number-format: "\@";
            text-align: center;
            font-weight: 400;
        }

        .orange {
            background: #FFC000;
            font-weight: 400;
            text-align: center;
            vertical-align: middle;
            border: .5pt dashed #000;
            mso-border-alt: .5pt dashed #000;
        }

        .green {
            background: #E2EFDA;
            font-weight: 400;
            text-align: center;
            vertical-align: middle;
            border: .5pt dashed #000;
            mso-border-alt: .5pt dashed #000;
        }

        .unit {
            background: #AEAAAA;
            font-weight: 400;
            text-align: center;
            vertical-align: middle;
            border: .5pt dashed #000;
            mso-border-alt: .5pt dashed #000;
        }
    </style>

</head>



<body>



    <table border="1">


        <thead>


            <tr>


                <th colspan="8" class="group">
                    DAY SHIFT
                </th>


                <th></th>


                <th colspan="8" class="group">
                    NIGHT SHIFT
                </th>


                <th></th>


                <th colspan="3" class="group">
                    DAY KM
                </th>


                <th colspan="3" class="group">
                    NIGHT KM
                </th>


            </tr>



            <tr>


                <th class="header">NO</th>
                <th class="header">NIK</th>
                <th class="header">NAMA</th>
                <th class="header">RITASE</th>
                <th class="header">UNIT</th>
                <th class="header">HM AWAL</th>
                <th class="header">HM AKHIR</th>
                <th class="header">HOURS</th>



                <th></th>



                <th class="header">NO</th>
                <th class="header">NIK</th>
                <th class="header">NAMA</th>
                <th class="header">RITASE</th>
                <th class="header">UNIT</th>
                <th class="header">HM AWAL</th>
                <th class="header">HM AKHIR</th>
                <th class="header">HOURS</th>



                <th></th>



                <th class="header">AWAL</th>
                <th class="header">AKHIR</th>
                <th class="header">TOTAL</th>


                <th class="header">AWAL</th>
                <th class="header">AKHIR</th>
                <th class="header">TOTAL</th>



            </tr>


        </thead>



        <tbody>

            <?php


            $no = 1;


            foreach ($masterUnits as $unit => $data) {



                /**
                 * ============================================================
                 * CEK MULTI OPERATOR
                 * ============================================================
                 */


                $dayOperator = [];

                foreach ($data['DAY']['drivers'] as $d) {

                    if (!empty($d['day_nik'])) {

                        $dayOperator[$d['day_nik']] = $d;
                    }
                }



                $nightOperator = [];

                foreach ($data['NIGHT']['drivers'] as $d) {

                    if (!empty($d['night_nik'])) {

                        $nightOperator[$d['night_nik']] = $d;
                    }
                }



                $multiDay = count($dayOperator) > 1;

                $multiNight = count($nightOperator) > 1;



                /**
                 * NOTE EXCEL
                 */


                $noteDay = "";

                if ($multiDay) {


                    $noteDay = "0306-CCR-D17\n";


                    foreach ($dayOperator as $op) {


                        $noteDay .=
                            "- " .
                            $op['day_nama'] .
                            " HM " .
                            $op['day_hm_start'] .
                            " s/d " .
                            $op['day_hm_end'] .
                            "\n";
                    }
                }



                $noteNight = "";

                if ($multiNight) {


                    $noteNight = "0306-CCR-D17\n";


                    foreach ($nightOperator as $op) {


                        $noteNight .=
                            "- " .
                            $op['night_nama'] .
                            " HM " .
                            $op['night_hm_start'] .
                            " s/d " .
                            $op['night_hm_end'] .
                            "\n";
                    }
                }



                /**
                 * TOTAL KM
                 */


                $dayTotalKM = 0;


                if (
                    $data['DAY']['km_akhir']
                    >=
                    $data['DAY']['km_awal']
                ) {

                    $dayTotalKM =
                        $data['DAY']['km_akhir']
                        -
                        $data['DAY']['km_awal'];
                }



                $nightTotalKM = 0;


                if (
                    $data['NIGHT']['km_akhir']
                    >=
                    $data['NIGHT']['km_awal']
                ) {

                    $nightTotalKM =
                        $data['NIGHT']['km_akhir']
                        -
                        $data['NIGHT']['km_awal'];
                }



            ?>


                <tr>


                    <!-- DAY -->


                    <td class="cell center">
                        <?= $no ?>
                    </td>


                    <td class="cell text">
                        <?= htmlspecialchars($data['DAY']['nik']) ?>
                    </td>


                    <td class="cell">
                        <?= htmlspecialchars($data['DAY']['nama']) ?>
                    </td>



                    <td
                        class="<?= $multiDay ? 'orange' : 'cell' ?>"
                        title="<?= htmlspecialchars($noteDay) ?>">
                        <?=
                        $data['DAY']['ritase'] > 0
                            ?
                            $data['DAY']['ritase']
                            :
                            ''
                        ?>
                    </td>



                    <td class="unit">
                        <?= $unit ?>
                    </td>



                    <td class="cell center">
                        <?=
                        $data['DAY']['hm_start'] > 0
                            ?
                            $data['DAY']['hm_start']
                            :
                            ''
                        ?>
                    </td>



                    <td class="cell center">
                        <?=
                        $data['DAY']['hm_end'] > 0
                            ?
                            $data['DAY']['hm_end']
                            :
                            ''
                        ?>
                    </td>



                    <td class="cell center">
                        <?=
                        number_format(
                            $data['DAY']['hours'],
                            2
                        )
                        ?>
                    </td>




                    <td></td>



                    <!-- NIGHT -->


                    <td class="cell center">
                        <?= $no ?>
                    </td>



                    <td class="cell text">
                        <?= htmlspecialchars($data['NIGHT']['nik']) ?>
                    </td>



                    <td class="cell">
                        <?= htmlspecialchars($data['NIGHT']['nama']) ?>
                    </td>



                    <td
                        class="<?= $multiNight ? 'orange' : 'cell' ?>"
                        title="<?= htmlspecialchars($noteNight) ?>">

                        <?=
                        $data['NIGHT']['ritase'] > 0
                            ?
                            $data['NIGHT']['ritase']
                            :
                            ''
                        ?>

                    </td>



                    <td class="unit">
                        <?= $unit ?>
                    </td>



                    <td class="cell center">

                        <?=
                        $data['NIGHT']['hm_start'] > 0
                            ?
                            $data['NIGHT']['hm_start']
                            :
                            ''
                        ?>

                    </td>



                    <td class="cell center">

                        <?=
                        $data['NIGHT']['hm_end'] > 0
                            ?
                            $data['NIGHT']['hm_end']
                            :
                            ''
                        ?>

                    </td>



                    <td class="cell center">

                        <?=
                        number_format(
                            $data['NIGHT']['hours'],
                            2
                        )
                        ?>

                    </td>




                    <td></td>




                    <!-- KM DAY -->


                    <td class="cell center">
                        <?= $data['DAY']['km_awal'] ?>
                    </td>


                    <td class="cell center">
                        <?= $data['DAY']['km_akhir'] ?>
                    </td>


                    <td class="<?= $dayTotalKM > 0 ? 'green' : 'cell' ?>">
                        <?= $dayTotalKM ?>
                    </td>




                    <!-- KM NIGHT -->


                    <td class="cell center">
                        <?= $data['NIGHT']['km_awal'] ?>
                    </td>


                    <td class="cell center">
                        <?= $data['NIGHT']['km_akhir'] ?>
                    </td>


                    <td class="<?= $nightTotalKM > 0 ? 'green' : 'cell' ?>">
                        <?= $nightTotalKM ?>
                    </td>



                </tr>



            <?php


                $no++;
            }



            ?>



        </tbody>

    </table>


</body>

</html>