<?php
// loading.php
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HM // SYSTEM INITIALIZING</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            height: 100vh;
            width: 100vw;
            overflow: hidden;
            font-family: 'Orbitron', monospace;
            background: #000;
            color: #00f7ff;
        }

        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&display=swap');

        /* MATRIX RAIN BACKGROUND */
        canvas#matrix {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            opacity: 0.3;
        }

        /* BG FULL DENGAN EFEK SCANLINE */
        .bg {
            position: fixed;
            width: 100%;
            height: 100%;
            background: url('assets/img/loading.jpeg') center/cover no-repeat;
            filter: brightness(0.3) hue-rotate(180deg);
            animation: scan 8s linear infinite;
        }

        .bg::after {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background: repeating-linear-gradient(0deg,
                    rgba(0, 0, 0, 0.15),
                    rgba(0, 0, 0, 0.15) 1px,
                    transparent 1px,
                    transparent 2px);
        }

        @keyframes scan {
            0% {
                background-position: 0 0;
            }

            100% {
                background-position: 0 100%;
            }
        }

        /* HOLOGRAM FRAME */
        .holo-frame {
            position: absolute;
            width: 90%;
            height: 90%;
            top: 5%;
            left: 5%;
            border: 2px solid #00f7ff;
            box-shadow: 0 0 30px #00f7ff, inset 0 0 30px rgba(0, 247, 255, 0.1);
            animation: pulseBorder 2s infinite;
        }

        @keyframes pulseBorder {

            0%,
            100% {
                box-shadow: 0 0 30px #00f7ff, inset 0 0 30px rgba(0, 247, 255, 0.1);
            }

            50% {
                box-shadow: 0 0 60px #00f7ff, inset 0 0 60px rgba(0, 247, 255, 0.2);
            }
        }

        /* KONTEN TENGAH */
        .loader {
            position: relative;
            z-index: 10;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        /* LOGO HOLOGRAM */
        .logo-loading {
            width: 350px;
            max-width: 80%;
            border-radius: 30px;
            border: 3px solid #00f7ff;
            box-shadow: 0 0 50px #00f7ff;
            animation: holoFloat 4s ease-in-out infinite;
            filter: drop-shadow(0 0 20px #00f7ff);
        }

        @keyframes holoFloat {

            0%,
            100% {
                transform: translateY(0) rotateY(0);
            }

            50% {
                transform: translateY(-20px) rotateY(5deg);
            }
        }

        /* TEKS GLITCH CYBER */
        h2 {
            font-size: 42px;
            font-weight: 900;
            margin-top: 30px;
            letter-spacing: 6px;
            color: #00f7ff;
            text-shadow: 0 0 5px #00f7ff, 0 0 20px #00f7ff;
            animation: glitchText 2s infinite;
        }

        @keyframes glitchText {
            0% {
                text-shadow: 0 0 5px #00f7ff;
            }

            20% {
                text-shadow: -2px 0 #ff00ff, 2px 0 #00ffff;
            }

            40% {
                text-shadow: 0 0 5px #00f7ff;
            }

            60% {
                text-shadow: 2px 0 #ff00ff, -2px 0 #00ffff;
            }

            80%,
            100% {
                text-shadow: 0 0 5px #00f7ff;
            }
        }

        /* STATUS BAR */
        .status {
            margin-top: 20px;
            font-size: 14px;
            color: #00ff88;
        }

        .status span {
            animation: blink 1s infinite;
        }

        @keyframes blink {
            50% {
                opacity: 0;
            }
        }

        /* PROGRESS BAR HOLOGRAM */
        .progress-wrap {
            width: 500px;
            max-width: 85%;
            height: 12px;
            background: rgba(0, 247, 255, 0.1);
            border: 1px solid #00f7ff;
            border-radius: 20px;
            margin-top: 30px;
            overflow: hidden;
            position: relative;
        }

        .progress-bar {
            height: 100%;
            width: 0%;
            background: linear-gradient(90deg, #00f7ff, #00ff88, #00f7ff);
            box-shadow: 0 0 20px #00f7ff;
            animation: load 3s linear forwards;
        }

        .progress-wrap::after {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
            animation: shine 1.5s infinite;
        }

        @keyframes load {
            to {
                width: 100%;
            }
        }

        @keyframes shine {
            100% {
                left: 100%;
            }
        }

        /* GRID BAWAH */
        .grid {
            position: fixed;
            bottom: 0;
            width: 100%;
            height: 200px;
            background: linear-gradient(transparent, rgba(0, 247, 255, 0.1));
            perspective: 500px;
        }

        .grid::before {
            content: '';
            position: absolute;
            width: 200%;
            height: 200%;
            background: linear-gradient(#00f7ff 1px, transparent 1px),
                linear-gradient(90deg, #00f7ff 1px, transparent 1px);
            background-size: 50px 50px;
            transform: rotateX(60deg);
            animation: gridMove 2s linear infinite;
        }

        @keyframes gridMove {
            from {
                transform: rotateX(60deg) translateY(0);
            }

            to {
                transform: rotateX(60deg) translateY(50px);
            }
        }
    </style>

    <script>
        // Redirect
        setTimeout(() => window.location.href = "index_main.php", 3000);

        // MATRIX RAIN EFFECT
        const canvas = document.getElementById('matrix');
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const chars = "01HM SYSTEM";
        const fontSize = 14;
        const columns = canvas.width / fontSize;
        const drops = Array(Math.floor(columns)).fill(1);

        function drawMatrix() {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#00f7ff';
            ctx.font = fontSize + 'px monospace';

            drops.forEach((y, i) => {
                const text = chars[Math.floor(Math.random() * chars.length)];
                ctx.fillText(text, i * fontSize, y * fontSize);
                if (y * fontSize > canvas.height && Math.random() > 0.975) drops[i] = 0;
                drops[i]++;
            });
        }
        setInterval(drawMatrix, 33);

        // STATUS TEXT DINAMIS
        const statuses = [
            "INITIALIZING SYSTEM...",
            "LOADING MODULES...",
            "CONNECTING TO DATABASE...",
            "WELCOME HABIB PJO HM"
        ];
        let i = 0;
        setInterval(() => {
            document.getElementById('statusText').innerText = statuses[i % statuses.length];
            i++;
        }, 700);
    </script>
</head>

<body>
    <canvas id="matrix"></canvas>
    <div class="bg"></div>
    <div class="holo-frame"></div>
    <div class="grid"></div>

    <div class="loader">
        <img src="assets/img/loading.jpeg" class="logo-loading" alt="HM Logo">

        <h2>HABIB SANG LEGENDA</h2>

        <div class="status"> <span id="statusText">SABARR</span></div>

        <div class="progress-wrap">
            <div class="progress-bar"></div>
        </div>

        <p style="margin-top:20px; font-size:12px; color:#00ff88;">[ TUNGGU ] SABAR COKK</p>
    </div>

    <!-- SUARA BEEP -->
    <audio autoplay loop>
        <source src="https://freesound.org/data/previews/270/270404_5123851-lq.mp3" type="audio/mpeg">
    </audio>
</body>

</html>