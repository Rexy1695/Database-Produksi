<?php
// 1. Panggil konfigurasi sistem & database
require_once 'config.php';

// 2. Load komponen Header dan Navbar atas
require_once 'templates/header.php';
require_once 'templates/navbar.php';

// Ambil parameter filter tanggal (default hari ini)
$filter_tgl = isset($_GET['tanggal']) ? $_GET['tanggal'] : date('Y-m-d');

/**
 * AMBIL DATA GABUNGAN KM 98, KM 10, dan KM 6
 */
$query = "SELECT * FROM transaksi_produksi WHERE tanggal = :tanggal ORDER BY area ASC, id ASC";
$stmt = $pdo->prepare($query);
$stmt->execute([':tanggal' => $filter_tgl]);
$dbData = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Jika database kosong, buatkan 1 baris kosong sebagai template awal grid
if (empty($dbData)) {
    $dbData = [
        [
            'area' => 'KM98',
            'unit_km' => '',
            'ritase' => 0,
            'night_ritase' => 0,
            'day_nik' => '',
            'day_nama' => '',
            'day_unit_hm' => '',
            'day_hm_start' => 0,
            'day_hm_end' => 0,
            'day_hm_hours' => 0,
            'night_nik' => '',
            'night_nama' => '',
            'night_unit_hm' => '',
            'night_hm_start' => 0,
            'night_hm_end' => 0,
            'night_hm_hours' => 0,
            'day_km_awal' => 0,
            'day_km_akhir' => 0,
            'day_km_total' => 0,
            'night_km_awal' => 0,
            'night_km_akhir' => 0,
            'night_km_total' => 0
        ]
    ];
}
?>

<!-- stylesheet pendukung Handsontable -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/handsontable/dist/handsontable.full.min.css">

<div class="flex flex-1 pt-16">
    <?php require_once 'templates/sidebar.php'; ?>

    <main class="flex-1 p-6 md:ml-64 transition-all bg-slate-50 min-h-screen">

        <!-- Header Section -->
        <div class="mb-6 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-900 tracking-tight">Urutkan No Unit</h1>
                <p class="text-sm text-slate-500">Urutkan Unit dengan copy-paste unit disini.</p>
            </div>

            <!-- Kontrol Aksi Berbaris -->
            <div class="flex flex-wrap items-center gap-3">
                <div class="flex items-center gap-2">
                    <input
                        type="text"
                        id="searchGrid"
                        placeholder="Cari Unit / NIK / Nama / Area..."
                        class="border border-slate-300 rounded-lg px-3 py-2 text-sm w-72">

                    <button
                        type="button"
                        onclick="cariDataGrid()"
                        class="bg-blue-600 text-white px-4 py-2.5 rounded-lg text-sm font-semibold hover:bg-blue-500 shadow-xs transition-all flex items-center gap-2">
                        <i class="fa-solid fa-magnifying-glass"></i>
                        Cari
                    </button>

                    <button
                        type="button"
                        onclick="resetCariGrid()"
                        class="bg-slate-500 text-white px-4 py-2.5 rounded-lg text-sm font-semibold hover:bg-slate-400 shadow-xs transition-all flex items-center gap-2">
                        <i class="fa-solid fa-rotate-left"></i>
                        Reset
                    </button>
                </div>
                <!-- TOMBOL DOWNLOAD EXCEL -->
                <a href="#"
                    id="btnExportExcel"
                    class="bg-emerald-600 text-white px-4 py-2.5 rounded-lg text-sm font-semibold hover:bg-emerald-500 shadow-xs transition-all flex items-center gap-2">

                    <i class="fa-solid fa-file-excel"></i>
                    Download Excel

                </a>
                <!-- TOMBOL HAPUS TOTAL -->
                <button id="btnHapusTotal"
                    class="bg-red-600 text-white px-4 py-2.5 rounded-lg text-sm font-semibold hover:bg-red-500 shadow-xs transition-all flex items-center gap-2">
                    <i class="fa-solid fa-trash"></i>
                    Hapus Semua Data
                </button>
            </div>
        </div>

        <!-- Input Area Urutan Unit Custom (Tempat Copy-Paste) -->
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs mb-6">
            <label class="block text-sm font-semibold text-slate-700 mb-2">
                <i class="fa-solid fa-list-ol text-blue-600 mr-1"></i> Tempel (Copy-Paste) Urutan Nomor Unit di Sini:
            </label>
            <textarea id="customOrderInput" rows="3"
                class="w-full text-sm border-slate-200 rounded-lg focus:ring-blue-500 focus:border-blue-500 placeholder-slate-400"
                placeholder="Contoh: 8029, 8075, 6001, 6005 (Bisa dipisahkan koma, spasi, atau baris baru)"></textarea>

            <div class="mt-3 flex gap-2">
                <button onclick="prosesPengurutanKustom()" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-xs font-semibold hover:bg-blue-500 transition-all shadow-xs flex items-center gap-1.5">
                    <i class="fa-solid fa-arrow-down-short-wide"></i> Terapkan Urutan
                </button>
                <button onclick="resetKeDefault()" class="bg-slate-200 text-slate-700 px-4 py-2 rounded-lg text-xs font-semibold hover:bg-slate-300 transition-all flex items-center gap-1.5">
                    <i class="fa-solid fa-rotate-left"></i> Reset Urutan Asli
                </button>
            </div>
        </div>

        <!-- Wadah Spreadsheet Grid -->
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div id="gridKonsolidasi" class="w-full overflow-hidden"></div>

            <div class="mt-4 flex justify-between items-center">
                <span class="text-xs text-slate-400 italic">* Setelah urutan rapi, bisa langsung klik tombol "Download Excel " di atas.</span>
            </div>
        </div>
    </main>
</div>

<!-- Scripts Engine Handsontable -->
<script src="https://cdn.jsdelivr.net/npm/handsontable/dist/handsontable.full.min.js"></script>
<script>
    // Master data mentah asli dari database
    const dataMasterAsli = <?= json_encode($dbData) ?>;

    // Salinan data dinamis untuk display grid setelah diurutkan
    let dataDisplay = JSON.parse(JSON.stringify(dataMasterAsli));

    const container = document.getElementById('gridKonsolidasi');
    const hot = new Handsontable(container, {
        data: dataDisplay,
        rowHeaders: true,
        height: 'auto',
        licenseKey: 'non-commercial-and-evaluation',
        stretchH: 'all',
        colHeaders: [
            'Area Pos', 'Unit', 'Day Rit', 'Night Rit',
            'Day NIK', 'Day Nama', 'Unit HM Day', 'HM Awal', 'HM Akhir', 'Total HM',
            'Night NIK', 'Night Nama', 'Unit HM Night', 'HM Awal', 'HM Akhir', 'Total HM',
            'KM Awal Day', 'KM Akhir Day', 'Total KM Day',
            'KM Awal Night', 'KM Akhir Night', 'Total KM Night'
        ],
        columns: [{
                data: 'area',
                type: 'dropdown',
                source: ['KM98', 'KM10', 'KM6']
            },
            {
                data: 'unit_km'
            },
            {
                data: 'ritase',
                type: 'numeric'
            },
            {
                data: 'night_ritase',
                type: 'numeric'
            },
            {
                data: 'day_nik'
            },
            {
                data: 'day_nama'
            },
            {
                data: 'day_unit_hm'
            },
            {
                data: 'day_hm_start',
                type: 'numeric',
                numericFormat: {
                    pattern: '0.0'
                }
            },
            {
                data: 'day_hm_end',
                type: 'numeric',
                numericFormat: {
                    pattern: '0.0'
                }
            },
            {
                data: 'day_hm_hours',
                type: 'numeric',
                numericFormat: {
                    pattern: '0.0'
                },
                readOnly: true
            },
            {
                data: 'night_nik'
            },
            {
                data: 'night_nama'
            },
            {
                data: 'night_unit_hm'
            },
            {
                data: 'night_hm_start',
                type: 'numeric',
                numericFormat: {
                    pattern: '0.0'
                }
            },
            {
                data: 'night_hm_end',
                type: 'numeric',
                numericFormat: {
                    pattern: '0.0'
                }
            },
            {
                data: 'night_hm_hours',
                type: 'numeric',
                numericFormat: {
                    pattern: '0.0'
                },
                readOnly: true
            },
            {
                data: 'day_km_awal',
                type: 'numeric'
            },
            {
                data: 'day_km_akhir',
                type: 'numeric'
            },
            {
                data: 'day_km_total',
                type: 'numeric',
                readOnly: true
            },
            {
                data: 'night_km_awal',
                type: 'numeric'
            },
            {
                data: 'night_km_akhir',
                type: 'numeric'
            },
            {
                data: 'night_km_total',
                type: 'numeric',
                readOnly: true
            }
        ],
        afterChange: function(changes, source) {
            if (source === 'loadData' || source === 'render_kalkulasi') return;

            if (changes) {
                changes.forEach(([row, prop, oldVal, newVal]) => {
                    if (prop === 'day_hm_start' || prop === 'day_hm_end') {
                        const start = parseFloat(this.getDataAtRowProp(row, 'day_hm_start')) || 0;
                        const end = parseFloat(this.getDataAtRowProp(row, 'day_hm_end')) || 0;
                        this.setDataAtRowProp(row, 'day_hm_hours', end >= start ? (end - start).toFixed(1) : 0, 'render_kalkulasi');
                    }
                    if (prop === 'night_hm_start' || prop === 'night_hm_end') {
                        const start = parseFloat(this.getDataAtRowProp(row, 'night_hm_start')) || 0;
                        const end = parseFloat(this.getDataAtRowProp(row, 'night_hm_end')) || 0;
                        this.setDataAtRowProp(row, 'night_hm_hours', end >= start ? (end - start).toFixed(1) : 0, 'render_kalkulasi');
                    }
                    if (prop === 'day_km_awal' || prop === 'day_km_akhir') {
                        const awal = parseInt(this.getDataAtRowProp(row, 'day_km_awal')) || 0;
                        const akhir = parseInt(this.getDataAtRowProp(row, 'day_km_akhir')) || 0;
                        this.setDataAtRowProp(row, 'day_km_total', akhir >= awal ? (akhir - awal) : 0, 'render_kalkulasi');
                    }
                    if (prop === 'night_km_awal' || prop === 'night_km_akhir') {
                        const awal = parseInt(this.getDataAtRowProp(row, 'night_km_awal')) || 0;
                        const akhir = parseInt(this.getDataAtRowProp(row, 'night_km_akhir')) || 0;
                        this.setDataAtRowProp(row, 'night_km_total', akhir >= awal ? (akhir - awal) : 0, 'render_kalkulasi');
                    }
                });
            }
        }
    });

    /**
     * LOGIKA EMULASI PENGURUTAN KUSTOM SECARA LIVE
     */
    function prosesPengurutanKustom() {
        const rawInput = document.getElementById('customOrderInput').value;
        if (!rawInput.trim()) {
            alert("Silakan paste/tempel urutan nomor unit terlebih dahulu.");
            return;
        }

        // Pecah teks inputan dari copy-paste (pisahkan berdasarkan koma, spasi, atau baris baru)
        const urutanMilikku = rawInput
            .split(/[,\n\r\t\s]+/)
            .map(item => item.trim())
            .filter(item => item !== "");

        if (urutanMilikku.length === 0) return;

        // Proses sorting baris data display
        dataDisplay.sort((a, b) => {
            const unitA = (a.unit_km || "").toString().trim();
            const unitB = (b.unit_km || "").toString().trim();

            const posA = urutanMilikku.indexOf(unitA);
            const posB = urutanMilikku.indexOf(unitB);

            // Jika kedua unit ada di dalam daftar copy-paste Komandan
            if (posA !== -1 && posB !== -1) return posA - posB;
            // Jika hanya unit A yang ada di daftar kustom, naikkan ke atas
            if (posA !== -1) return -1;
            // Jika hanya unit B yang ada di daftar kustom, turunkan ke bawah
            if (posB !== -1) return 1;

            // Jika tidak ada di daftar, urutkan normal alfanumerik
            return unitA.localeCompare(unitB, undefined, {
                numeric: true,
                sensitivity: 'base'
            });
        });

        // Terapkan hasil urutan live ke grid Handsontable secara instan
        hot.loadData(dataDisplay);
    }

    // Fungsi reset untuk mengembalikan ke urutan default database
    function resetKeDefault() {
        dataDisplay = JSON.parse(JSON.stringify(dataMasterAsli));
        hot.loadData(dataDisplay);
        document.getElementById('customOrderInput').value = "";
    }

    function simpanPerubahanGrid() {
        const dataGrid = hot.getSourceData();
        fetch('<?= MAIN_URL ?>/area/proses_massal.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    tanggal: '<?= $filter_tgl ?>',
                    data: dataGrid
                })
            })
            .then(res => res.json())
            .then(res => {
                alert(res.message);
                if (res.status === 'success') window.location.reload();
            })
            .catch(() => alert('Terjadi kesalahan koneksi sistem.'));
    }

    document
        .getElementById('btnExportExcel')
        .addEventListener('click', function(e) {

            e.preventDefault();


            let urutan = [];


            hot.getSourceData()
                .forEach(row => {

                    if (row.unit_km) {

                        urutan.push(row.unit_km);

                    }

                });



            let tanggal = "<?= $filter_tgl ?>";


            let url =
                "export_excel.php?tanggal=" +
                tanggal +
                "&urutan=" +
                encodeURIComponent(
                    urutan.join("\n")
                );


            window.location.href = url;


        });
    document
        .getElementById('btnHapusTotal')
        .addEventListener('click', function() {

            if (!confirm(
                    "PERINGATAN!\n\nSemua data pada database akan dihapus permanen.\n\nTindakan ini tidak dapat dibatalkan.\n\nLanjutkan?"
                )) {
                return;
            }

            fetch('<?= MAIN_URL ?>/area/hapus_aksi.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        aksi: 'hapus_total'
                    })
                })
                .then(res => res.json())
                .then(res => {

                    alert(res.message);

                    if (res.status === 'success') {
                        window.location.reload();
                    }

                })
                .catch(() => {
                    alert('Gagal menghubungi server.');
                });

        });

    function cariDataGrid() {

        const keyword = document.getElementById("searchGrid").value
            .toLowerCase()
            .trim();

        if (keyword === "") {
            hot.loadData(dataDisplay);
            return;
        }

        const hasil = dataDisplay.filter(row =>
            Object.values(row).some(value =>
                String(value).toLowerCase().includes(keyword)
            )
        );

        hot.loadData(hasil);
    }

    function resetCariGrid() {

        document.getElementById("searchGrid").value = "";

        hot.loadData(dataDisplay);

    }

    document.getElementById("searchGrid").addEventListener("keyup", function(e) {

        if (e.key === "Enter") {
            cariDataGrid();
        }

    });
</script>