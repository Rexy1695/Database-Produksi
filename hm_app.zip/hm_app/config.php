<?php
// 1. Pengaturan Zona Waktu Operasional Tambang (WITA)
date_default_timezone_set('Asia/Makassar'); 

// 2. Memulai Session secara Global
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 3. Konfigurasi Kredensial Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_monitoring_hm');

// 4. Konfigurasi URL Utama (MAIN_URL) secara Dinamis
// Otomatis mendeteksi http://localhost/hm_app
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$domain = $_SERVER['HTTP_HOST'];
define('MAIN_URL', $protocol . $domain . '/hm_app');

// 5. Inisialisasi Koneksi Menggunakan PDO (PHP Data Objects)
try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Error ditampilkan sebagai Exception untuk mempermudah debugging
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Hasil query otomatis berupa Array Asosiatif
        PDO::ATTR_EMULATE_PREPARES   => false,                  // Menggunakan Prepared Statements asli agar aman dari SQL Injection
    ];
    
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    
} catch (PDOException $e) {
    // Jika koneksi gagal, sistem akan stop dan menampilkan pesan error
    die("Koneksi database gagal: " . $e->getMessage());
}