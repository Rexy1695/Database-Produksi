<?php
// 1. Jalur naik satu folder ke root untuk config dan core templates
require_once '../config.php';
require_once '../templates/header.php';
require_once '../templates/navbar.php';

$page_title = strtoupper(basename($_SERVER['PHP_SELF'], '.php'));
?>

<div class="flex flex-1 pt-16">
    <?php require_once '../templates/sidebar.php'; ?>

    <main class="flex-1 p-6 md:ml-64 transition-all">
        <!-- Header Halaman -->
        <div class="mb-6 flex flex-col sm:flex-row justify-between sm:items-center gap-3">
            <div>
                <h1 class="text-2xl font-bold text-slate-900 tracking-tight">Pos Monitoring <?= $page_title ?></h1>
                <p class="text-sm text-slate-500">Input Data Operasional HM & KM Lengkap 2 Shift (Support Copy-Paste Excel).</p>
            </div>
            <div class="bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-xs text-sm font-medium text-slate-600">
                <i class="fa-solid fa-location-crosshairs text-amber-500 mr-1"></i> Pos Aktif
            </div>
        </div>

        <!-- Tombol Aksi Kontrol Grid -->
        <div class="mb-4 flex items-center gap-2">
            <button onclick="tambahBaris()" class="bg-slate-800 text-white px-3 py-1.5 rounded-lg text-xs font-semibold hover:bg-slate-700 transition-all">
                <i class="fa-solid fa-plus mr-1"></i> Tambah Baris
            </button>
            <button onclick="simpanData()" class="bg-emerald-600 text-white px-4 py-1.5 rounded-lg text-xs font-semibold hover:bg-emerald-500 shadow-sm transition-all ml-auto">
                <i class="fa-solid fa-floppy-disk mr-1"></i> Simpan Data Pos
            </button>
        </div>

        <!-- Wadah Tempat Tabel Excel Bekerja -->
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <!-- Ditambahkan class overflow-x-auto agar grid aman digeser di layar desktop/laptop -->
            <div id="excelGrid" class="w-full overflow-x-auto"></div>
        </div>
    </main>
</div>

<?php require_once '../templates/footer.php'; ?>

<script>
    // Struktur data awal penampung kolom grid dengan tambahan NIK & NAMA di tiap shift
    const dataAwal = Array.from({
        length: 15
    }, () => ({
        day_nik: '',
        day_nama: '',
        ritase: '',
        day_unit_hm: '',
        day_hm_start: '',
        day_hm_end: '',
        day_hm_hours: '',
        night_nik: '',
        night_nama: '',
        night_unit_hm: '',
        night_hm_start: '',
        night_hm_end: '',
        night_hm_hours: '',
        unit_km: '',
        day_km_awal: '',
        day_km_akhir: '',
        day_km_total: '',
        night_km_awal: '',
        night_km_akhir: '',
        night_km_total: ''
    }));

    const container = document.getElementById('excelGrid');
    const hot = new Handsontable(container, {
        data: dataAwal,
        rowHeaders: true,
        height: '520',
        autoWrapRow: true,
        autoWrapCol: true,
        minSpareRows: 1,
        licenseKey: 'non-commercial-and-evaluation',

        copyPaste: true,
        outsideClickDeselects: false,
        fillHandle: true,

        // Perubahan Struktur HTML Header bertingkat (Colspan disesuaikan dari 3 menjadi 6)
        nestedHeaders: [
            ['Ritase', {
                label: 'DAY SHIFT HM',
                colspan: 6
            }, {
                label: 'NIGHT SHIFT HM',
                colspan: 6
            }, 'Unit', {
                label: 'DAY SHIFT KM',
                colspan: 3
            }, {
                label: 'NIGHT SHIFT KM',
                colspan: 3
            }],
            ['NIK', 'NAMA','Rit', 'No', 'START', 'END', 'HOURS', 'NIK', 'NAMA', 'No', 'START', 'END', 'HOURS', 'No', 'AWAL', 'AKHIR', 'TOTAL', 'AWAL', 'AKHIR', 'TOTAL']
        ],

        columns: [{
                data: 'ritase',
                type: 'numeric',
                numericFormat: {
                    pattern: '0.0'
                },
                width: 60
            },

            // DAY SHIFT HM
            {
                data: 'day_nik',
                type: 'text',
                className: 'htCenter text-slate-600',
                width: 90
            },
            {
                data: 'day_nama',
                type: 'text',
                className: 'text-slate-700 font-medium',
                width: 140
            },
            {
                data: 'day_unit_hm',
                type: 'text',
                className: 'htCenter font-bold text-slate-700 bg-sky-50',
                width: 80
            },
            {
                data: 'day_hm_start',
                type: 'numeric',
                width: 90
            },
            {
                data: 'day_hm_end',
                type: 'numeric',
                width: 90
            },
            {
                data: 'day_hm_hours',
                type: 'numeric',
                readOnly: true,
                className: 'bg-slate-50 font-medium text-slate-500 htCenter',
                width: 70
            },

            // NIGHT SHIFT HM
            {
                data: 'night_nik',
                type: 'text',
                className: 'htCenter text-slate-600',
                width: 90
            },
            {
                data: 'night_nama',
                type: 'text',
                className: 'text-slate-700 font-medium',
                width: 140
            },
            {
                data: 'night_unit_hm',
                type: 'text',
                className: 'htCenter font-bold text-slate-700 bg-sky-50',
                width: 80
            },
            {
                data: 'night_hm_start',
                type: 'numeric',
                width: 90
            },
            {
                data: 'night_hm_end',
                type: 'numeric',
                width: 90
            },
            {
                data: 'night_hm_hours',
                type: 'numeric',
                readOnly: true,
                className: 'bg-slate-50 font-medium text-slate-500 htCenter',
                width: 70
            },

            // KM SECTION (Unit No Mandiri)
            {
                data: 'unit_km',
                type: 'text',
                className: 'htCenter font-bold text-slate-700 bg-emerald-50',
                width: 80
            },

            // DAY SHIFT KM
            {
                data: 'day_km_awal',
                type: 'numeric',
                width: 90
            },
            {
                data: 'day_km_akhir',
                type: 'numeric',
                width: 90
            },
            {
                data: 'day_km_total',
                type: 'numeric',
                readOnly: true,
                className: 'bg-emerald-50 text-emerald-800 font-semibold htCenter',
                width: 80
            },

            // NIGHT SHIFT KM
            {
                data: 'night_km_awal',
                type: 'numeric',
                width: 90
            },
            {
                data: 'night_km_akhir',
                type: 'numeric',
                width: 90
            },
            {
                data: 'night_km_total',
                type: 'numeric',
                readOnly: true,
                className: 'bg-amber-50 text-amber-800 font-semibold htCenter',
                width: 80
            }
        ],

        // Logika Perhitungan Selisih Angka Jam & Jarak (Tetap Aman Dipertahankan)
        afterChange: function(changes, source) {
            if (source === 'loadData' || !changes) return;

            changes.forEach(([row, prop, oldVal, newVal]) => {
                // Kalkulasi Hours Day Shift HM
                if (prop === 'day_hm_start' || prop === 'day_hm_end') {
                    const start = parseFloat(this.getDataAtRowProp(row, 'day_hm_start')) || 0;
                    const end = parseFloat(this.getDataAtRowProp(row, 'day_hm_end')) || 0;
                    this.setDataAtRowProp(row, 'day_hm_hours', (end - start) >= 0 ? (end - start) : 0);
                }

                // Kalkulasi Hours Night Shift HM
                if (prop === 'night_hm_start' || prop === 'night_hm_end') {
                    const start = parseFloat(this.getDataAtRowProp(row, 'night_hm_start')) || 0;
                    const end = parseFloat(this.getDataAtRowProp(row, 'night_hm_end')) || 0;
                    this.setDataAtRowProp(row, 'night_hm_hours', (end - start) >= 0 ? (end - start) : 0);
                }

                // Kalkulasi Total Day Shift KM
                if (prop === 'day_km_awal' || prop === 'day_km_akhir') {
                    const awal = parseFloat(this.getDataAtRowProp(row, 'day_km_awal')) || 0;
                    const akhir = parseFloat(this.getDataAtRowProp(row, 'day_km_akhir')) || 0;
                    this.setDataAtRowProp(row, 'day_km_total', (akhir - awal) >= 0 ? (akhir - awal) : 0);
                }

                // Kalkulasi Total Night Shift KM
                if (prop === 'night_km_awal' || prop === 'night_km_akhir') {
                    const awal = parseFloat(this.getDataAtRowProp(row, 'night_km_awal')) || 0;
                    const akhir = parseFloat(this.getDataAtRowProp(row, 'night_km_akhir')) || 0;
                    this.setDataAtRowProp(row, 'night_km_total', (akhir - awal) >= 0 ? (akhir - awal) : 0);
                }
            });
        }
    });

    function tambahBaris() {
        hot.alter('insert_row_below', hot.countRows() - 1, 1);
    }

    function simpanData() {
        const dataAktual = hot.getData();
        const dataValid = dataAktual.filter(row => row[0] !== null && row[0] !== '');

        if (dataValid.length === 0) {
            alert('Tidak ada data operasional yang diisi!');
            return;
        }

        console.log("Data Pos Lengkap Siap Kirim ke Controller:", dataValid);
        alert('Sukses memproses ' + dataValid.length + ' data pos monitoring!');
    }
</script>