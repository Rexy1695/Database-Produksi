<?php
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status'  => 'error',
        'message' => 'Method tidak sah.'
    ]);
    exit;
}

$inputRaw  = file_get_contents('php://input');
$inputData = json_decode($inputRaw, true);

if (!isset($inputData['aksi'])) {
    echo json_encode([
        'status'  => 'error',
        'message' => 'Parameter aksi tidak ditemukan.'
    ]);
    exit;
}

try {

    switch ($inputData['aksi']) {

        // ==========================================
        // HAPUS SATU AREA
        // ==========================================
        case 'hapus_area':

            if (empty($inputData['area'])) {
                throw new Exception('Parameter area tidak ditemukan.');
            }

            $target_tabel = $inputData['target_tabel'] ?? 'hari_ini';

            $nama_tabel = ($target_tabel === 'kemarin')
                ? 'transaksi_produksi_kemarin'
                : 'transaksi_produksi';

            $tanggal = ($target_tabel === 'kemarin')
                ? date('Y-m-d', strtotime('-1 day'))
                : date('Y-m-d');

            $stmt = $pdo->prepare("
                DELETE FROM `$nama_tabel`
                WHERE area = :area
                AND tanggal = :tanggal
            ");

            $stmt->execute([
                ':area'     => $inputData['area'],
                ':tanggal'  => $tanggal
            ]);

            echo json_encode([
                'status'  => 'success',
                'message' => 'Data area berhasil dihapus.'
            ]);
            break;


        // ==========================================
        // HAPUS SEMUA DATA
        // ==========================================
        case 'hapus_total':

            $pdo->exec("TRUNCATE TABLE transaksi_produksi");

            echo json_encode([
                'status'  => 'success',
                'message' => 'Semua data berhasil dihapus.'
            ]);
            break;


        default:

            echo json_encode([
                'status'  => 'error',
                'message' => 'Parameter aksi tidak valid.'
            ]);
            break;
    }
} catch (PDOException $e) {

    echo json_encode([
        'status'  => 'error',
        'message' => 'Gagal menghapus data: ' . $e->getMessage()
    ]);
} catch (Exception $e) {

    echo json_encode([
        'status'  => 'error',
        'message' => $e->getMessage()
    ]);
}
