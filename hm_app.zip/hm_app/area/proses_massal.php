    <?php
    require_once __DIR__ . '/../config.php';
    header('Content-Type: application/json');

    $input = json_decode(file_get_contents('php://input'), true);

    if (!$input || empty($input['data'])) {
        echo json_encode(['status' => 'error', 'message' => 'Data kiriman kosong.']);
        exit;
    }

    $tanggal = $input['tanggal'];

    try {
        $pdo->beginTransaction();

        // Hapus data lama pada tanggal tersebut sebelum ditimpa data baru dari grid
        $stmtDelete = $pdo->prepare("DELETE FROM `transaksi_produksi` WHERE `tanggal` = :tanggal");
        $stmtDelete->execute([':tanggal' => $tanggal]);

        $queryInsert = "INSERT INTO `transaksi_produksi` (
            `tanggal`, `area`, `unit_km`, `ritase`, `night_ritase`,
            `day_nik`, `day_nama`, `day_unit_hm`, `day_hm_start`, `day_hm_end`, `day_hm_hours`,
            `night_nik`, `night_nama`, `night_unit_hm`, `night_hm_start`, `night_hm_end`, `night_hm_hours`,
            `day_km_awal`, `day_km_akhir`, `day_km_total`,
            `night_km_awal`, `night_km_akhir`, `night_km_total`
        ) VALUES (
            :tanggal, :area, :unit_km, :ritase, :night_ritase,
            :day_nik, :day_nama, :day_unit_hm, :day_hm_start, :day_hm_end, :day_hm_hours,
            :night_nik, :night_nama, :night_unit_hm, :night_hm_start, :night_hm_end, :night_hm_hours,
            :day_km_awal, :day_km_akhir, :day_km_total,
            :night_km_awal, :night_km_akhir, :night_km_total
        )";

        $stmtInsert = $pdo->prepare($queryInsert);

        foreach ($input['data'] as $row) {
            if (empty($row['unit_km'])) continue; // skip baris kosong

            $stmtInsert->execute([
                ':tanggal'        => $tanggal,
                ':area'           => !empty($row['area']) ? $row['area'] : 'KM98',
                ':unit_km'        => $row['unit_km'],
                ':ritase'         => (int)($row['ritase'] ?? 0),
                ':night_ritase'   => (int)($row['night_ritase'] ?? 0),
                ':day_nik'        => $row['day_nik'] ?: null,
                ':day_nama'       => $row['day_nama'] ?: null,
                ':day_unit_hm'    => $row['day_unit_hm'] ?: null,
                ':day_hm_start'   => (float)($row['day_hm_start'] ?? 0),
                ':day_hm_end'     => (float)($row['day_hm_end'] ?? 0),
                ':day_hm_hours'   => (float)($row['day_hm_hours'] ?? 0),
                ':night_nik'      => $row['night_nik'] ?: null,
                ':night_nama'     => $row['night_nama'] ?: null,
                ':night_unit_hm'  => $row['night_unit_hm'] ?: null,
                ':night_hm_start' => (float)($row['night_hm_start'] ?? 0),
                ':night_hm_end'   => (float)($row['night_hm_end'] ?? 0),
                ':night_hm_hours' => (float)($row['night_hm_hours'] ?? 0),
                ':day_km_awal'    => (int)($row['day_km_awal'] ?? 0),
                ':day_km_akhir'   => (int)($row['day_km_akhir'] ?? 0),
                ':day_km_total'   => (int)($row['day_km_total'] ?? 0),
                ':night_km_awal'  => (int)($row['night_km_awal'] ?? 0),
                ':night_km_akhir' => (int)($row['night_km_akhir'] ?? 0),
                ':night_km_total' => (int)($row['night_km_total'] ?? 0)
            ]);
        }

        $pdo->commit();
        echo json_encode(['status' => 'success', 'message' => 'Seluruh data konsolidasi pos berhasil disimpan!']);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan data: ' . $e->getMessage()]);
    }