<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/navbar.php';

$page_title = strtoupper(basename($_SERVER['SCRIPT_FILENAME'], '.php'));

// Tentukan tabel target berdasarkan kebutuhan halaman
$target_tabel = 'hari_ini'; // Ubah ke 'kemarin' jika ini file halaman hari sebelumnya
$nama_tabel = ($target_tabel === 'kemarin') ? 'transaksi_produksi_kemarin' : 'transaksi_produksi';
$tanggal = ($target_tabel === 'kemarin') ? date('Y-m-d', strtotime('-1 day')) : date('Y-m-d');

// AMBIL DATA LAMA AGAR TIDAK BLANK / KOSONG SAAT DI-LOAD
$data_saved = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM `$nama_tabel` WHERE `tanggal` = :tanggal AND `area` = :area");
    $stmt->execute([':tanggal' => $tanggal, ':area' => $page_title]);
    $data_saved = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Tangani error database jika diperlukan
}
?>

<div class="flex flex-1 pt-16">
    <?php require_once __DIR__ . '/../templates/sidebar.php'; ?>

    <main class="flex-1 p-6 md:ml-64 transition-all">
        <div class="mb-6 flex flex-col sm:flex-row justify-between sm:items-center gap-3">
            <div>
                <h1 class="text-2xl font-bold text-slate-900 tracking-tight">HM <?= $page_title ?></h1>
                <p class="text-sm text-slate-500">Input Data Operasional HM & KM Lengkap 2 Shift (Support Copy-Paste Excel).</p>
            </div>
        </div>

        <div class="mb-4 flex items-center gap-2">
            <button onclick="tambahBaris()" class="bg-slate-800 text-white px-3 py-1.5 rounded-lg text-xs font-semibold hover:bg-slate-700 transition-all">
                <i class="fa-solid fa-plus mr-1"></i> Tambah Baris
            </button>
            <button onclick="simpanData()" class="bg-emerald-600 text-white px-4 py-1.5 rounded-lg text-xs font-semibold hover:bg-emerald-500 shadow-sm transition-all ml-auto">
                <i class="fa-solid fa-floppy-disk mr-1"></i> Simpan Data
            </button>
            <button onclick="hapusDataArea()" class="bg-red-600 text-white px-4 py-1.5 rounded-lg text-xs font-semibold hover:bg-red-500 shadow-sm transition-all">
                <i class="fa-solid fa-trash mr-1"></i> Hapus Data
            </button>
        </div>

        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div id="excelGrid" class="w-full overflow-x-auto"></div>
        </div>
    </main>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>

<script>
    const TARGET_TABEL = '<?= $target_tabel ?>';
    const AREA_NAME = '<?= $page_title ?>';
    const MAIN_URL = '<?= MAIN_URL ?>';

    // Inject data dari database ke Handsontable, jika kosong siapkan 15 baris default
    const dataDb = <?= json_encode($data_saved) ?>;
    const dataAwal = dataDb.length > 0 ? dataDb : Array.from({
        length: 15
    }, () => ({
        day_nik: '',
        day_nama: '',
        ritase: '',
        day_unit_hm: '',
        day_hm_start: '',
        day_hm_end: '',
        day_hm_hours: '',
        night_nik: '',
        night_nama: '',
        night_ritase: '',
        night_unit_hm: '',
        night_hm_start: '',
        night_hm_end: '',
        night_hm_hours: '',
        unit_km: '',
        day_km_awal: '',
        day_km_akhir: '',
        day_km_total: '',
        night_km_awal: '',
        night_km_akhir: '',
        night_km_total: ''
    }));

    const container = document.getElementById('excelGrid');
    const hot = new Handsontable(container, {
        data: dataAwal,
        rowHeaders: true,
        height: '520',
        autoWrapRow: true,
        autoWrapCol: true,
        minSpareRows: 1,
        licenseKey: 'non-commercial-and-evaluation',
        copyPaste: true,
        outsideClickDeselects: false,
        fillHandle: true,

        nestedHeaders: [
            [{
                label: 'DAY SHIFT',
                colspan: 7
            }, {
                label: 'NIGHT SHIFT',
                colspan: 7
            }, 'Unit', {
                label: 'DAY SHIFT KM',
                colspan: 3
            }, {
                label: 'NIGHT SHIFT KM',
                colspan: 3
            }],
            ['NIK', 'NAMA', 'Rit', 'No Unit', 'START HM', 'END HM', 'HOURS', 'NIK', 'NAMA', 'Rit', 'No Unit', 'START HM', 'END HM', 'HOURS', 'No', 'AWAL', 'AKHIR', 'TOTAL', 'AWAL', 'AKHIR', 'TOTAL']
        ],

        columns: [{
                data: 'day_nik',
                type: 'text',
                className: 'htCenter text-slate-600',
                width: 90
            },
            {
                data: 'day_nama',
                type: 'text',
                className: 'text-slate-700 font-medium',
                width: 140
            },
            {
                data: 'ritase',
                type: 'numeric',
                numericFormat: {
                    pattern: '0.0'
                },
                className: 'htCenter',
                width: 60
            },
            {
                data: 'day_unit_hm',
                type: 'text',
                className: 'htCenter font-bold text-slate-700 bg-sky-50',
                width: 80
            },
            {
                data: 'day_hm_start',
                type: 'numeric',
                width: 90
            },
            {
                data: 'day_hm_end',
                type: 'numeric',
                width: 90
            },
            {
                data: 'day_hm_hours',
                type: 'numeric',
                readOnly: true,
                className: 'bg-slate-50 font-medium text-slate-500 htCenter',
                width: 70
            },

            {
                data: 'night_nik',
                type: 'text',
                className: 'htCenter text-slate-600',
                width: 90
            },
            {
                data: 'night_nama',
                type: 'text',
                className: 'text-slate-700 font-medium',
                width: 140
            },
            {
                data: 'night_ritase',
                type: 'numeric',
                numericFormat: {
                    pattern: '0.0'
                },
                className: 'htCenter',
                width: 60
            },
            {
                data: 'night_unit_hm',
                type: 'text',
                className: 'htCenter font-bold text-slate-700 bg-sky-50',
                width: 80
            },
            {
                data: 'night_hm_start',
                type: 'numeric',
                width: 90
            },
            {
                data: 'night_hm_end',
                type: 'numeric',
                width: 90
            },
            {
                data: 'night_hm_hours',
                type: 'numeric',
                readOnly: true,
                className: 'bg-slate-50 font-medium text-slate-500 htCenter',
                width: 70
            },

            {
                data: 'unit_km',
                type: 'text',
                className: 'htCenter font-bold text-slate-700 bg-emerald-50',
                width: 80
            },

            {
                data: 'day_km_awal',
                type: 'numeric',
                width: 90
            },
            {
                data: 'day_km_akhir',
                type: 'numeric',
                width: 90
            },
            {
                data: 'day_km_total',
                type: 'numeric',
                readOnly: true,
                className: 'bg-emerald-50 text-emerald-800 font-semibold htCenter',
                width: 80
            },

            {
                data: 'night_km_awal',
                type: 'numeric',
                width: 90
            },
            {
                data: 'night_km_akhir',
                type: 'numeric',
                width: 90
            },
            {
                data: 'night_km_total',
                type: 'numeric',
                readOnly: true,
                className: 'bg-amber-50 text-amber-800 font-semibold htCenter',
                width: 80
            }
        ],

        afterChange: function(changes, source) {
            // Mencegah looping terus-menerus: ijinkan jalan HANYA dari input manual (edit) atau paste data
            if (source !== 'edit' && source !== 'CopyPaste.paste') return;

            changes.forEach(([row, prop, oldVal, newVal]) => {
                if (prop === 'day_hm_start' || prop === 'day_hm_end') {
                    const start = parseFloat(this.getDataAtRowProp(row, 'day_hm_start')) || 0;
                    const end = parseFloat(this.getDataAtRowProp(row, 'day_hm_end')) || 0;
                    this.setDataAtRowProp(row, 'day_hm_hours', (end - start) >= 0 ? (end - start) : 0);
                }
                if (prop === 'night_hm_start' || prop === 'night_hm_end') {
                    const start = parseFloat(this.getDataAtRowProp(row, 'night_hm_start')) || 0;
                    const end = parseFloat(this.getDataAtRowProp(row, 'night_hm_end')) || 0;
                    this.setDataAtRowProp(row, 'night_hm_hours', (end - start) >= 0 ? (end - start) : 0);
                }
                if (prop === 'day_km_awal' || prop === 'day_km_akhir') {
                    const awal = parseFloat(this.getDataAtRowProp(row, 'day_km_awal')) || 0;
                    const akhir = parseFloat(this.getDataAtRowProp(row, 'day_km_akhir')) || 0;
                    this.setDataAtRowProp(row, 'day_km_total', (akhir - awal) >= 0 ? (akhir - awal) : 0);
                }
                if (prop === 'night_km_awal' || prop === 'night_km_akhir') {
                    const awal = parseFloat(this.getDataAtRowProp(row, 'night_km_awal')) || 0;
                    const akhir = parseFloat(this.getDataAtRowProp(row, 'night_km_akhir')) || 0;
                    this.setDataAtRowProp(row, 'night_km_total', (akhir - awal) >= 0 ? (akhir - awal) : 0);
                }
            });
        }
    });

    function tambahBaris() {
        hot.alter('insert_row_below', hot.countRows() - 1, 1);
    }

    function simpanData() {
        const dataAktual = hot.getSourceData();

        const dataValid = dataAktual.filter(row => {
            return (row.day_nik !== '' && row.day_nik !== null) ||
                (row.night_nik !== '' && row.night_nik !== null) ||
                (row.unit_km !== '' && row.unit_km !== null);
        });

        if (dataValid.length === 0) {
            alert('Tidak ada data koordinat pos yang diisi!');
            return;
        }

        fetch(`${MAIN_URL}/area/proses.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    area: AREA_NAME,
                    target_tabel: TARGET_TABEL,
                    data: dataValid
                })
            })
            .then(response => response.json())
            .then(result => {
                if (result.status === 'success') {
                    alert(result.message);
                    window.location.reload();
                } else {
                    alert('Gagal memproses data: ' + result.message);
                }
            })
            .catch(error => {
                console.error(error);
                alert('Terjadi gangguan jaringan saat menyimpan data ke database.');
            });
    }

    function hapusDataArea() {

        if (!confirm(`Yakin ingin menghapus seluruh data area ${AREA_NAME}?`)) {
            return;
        }

        fetch(`${MAIN_URL}/area/hapus_aksi.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    aksi: 'hapus_area',
                    area: AREA_NAME,
                    target_tabel: TARGET_TABEL
                })
            })
            .then(response => response.json())
            .then(result => {

                if (result.status === 'success') {
                    alert(result.message);
                    window.location.reload();
                } else {
                    alert(result.message);
                }

            })
            .catch(error => {
                console.error(error);
                alert('Terjadi gangguan jaringan.');
            });
    }
</script>