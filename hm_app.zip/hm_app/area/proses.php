<?php
require_once __DIR__ . '/../config.php';

// Atur header agar merespons dalam format JSON
header('Content-Type: application/json');

// Pastikan request menggunakan method POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Method tidak diizinkan.']);
    exit;
}

// Ambil data JSON dari body request
$inputRaw = file_get_contents('php://input');
$inputData = json_decode($inputRaw, true);

if (!$inputData || empty($inputData['data'])) {
    echo json_encode(['status' => 'error', 'message' => 'Data kosong atau format salah.']);
    exit;
}

$area = isset($inputData['area']) ? strtoupper($inputData['area']) : 'KM98';
$targetTabel = isset($inputData['target_tabel']) ? $inputData['target_tabel'] : 'hari_ini';
$gridData = $inputData['data'];

// Tentukan tabel target berdasarkan input halaman
$namaTabel = ($targetTabel === 'kemarin') ? 'transaksi_produksi_kemarin' : 'transaksi_produksi';

// Tentukan tanggal berdasarkan target halaman (Menggunakan waktu sistem 2026 saat ini)
$tanggal = ($targetTabel === 'kemarin') ? date('Y-m-d', strtotime('-1 day')) : date('Y-m-d');

try {
    $pdo->beginTransaction();

    // Hapus data lama pada tanggal dan area yang sama untuk mencegah duplikasi (Over-write data baru)
    $queryDelete = "DELETE FROM `$namaTabel` WHERE `tanggal` = :tanggal AND `area` = :area";
    $stmtDelete = $pdo->prepare($queryDelete);
    $stmtDelete->execute([':tanggal' => $tanggal, ':area' => $area]);

    // Query Insert terstruktur rapi (Ditambahkan kolom night_ritase agar balance dengan grid Handsontable)
    $queryInsert = "INSERT INTO `$namaTabel` (
        `tanggal`, `area`, `ritase`, 
        `day_nik`, `day_nama`, `day_unit_hm`, `day_hm_start`, `day_hm_end`, `day_hm_hours`, 
        `night_nik`, `night_nama`, `night_ritase`, `night_unit_hm`, `night_hm_start`, `night_hm_end`, `night_hm_hours`, 
        `unit_km`, 
        `day_km_awal`, `day_km_akhir`, `day_km_total`, 
        `night_km_awal`, `night_km_akhir`, `night_km_total`
    ) VALUES (
        :tanggal, :area, :ritase, 
        :day_nik, :day_nama, :day_unit_hm, :day_hm_start, :day_hm_end, :day_hm_hours, 
        :night_nik, :night_nama, :night_ritase, :night_unit_hm, :night_hm_start, :night_hm_end, :night_hm_hours, 
        :unit_km, 
        :day_km_awal, :day_km_akhir, :day_km_total, 
        :night_km_awal, :night_km_akhir, :night_km_total
    )";

    // PENTING: Lakukan prepare statement di sini sebelum masuk ke perulangan loop
    $stmtInsert = $pdo->prepare($queryInsert);

    foreach ($gridData as $row) {
        // Skip baris kosong
        if (empty($row['day_nik']) && empty($row['night_nik']) && empty($row['unit_km'])) {
            continue;
        }

        $stmtInsert->execute([
            ':tanggal'         => $tanggal,
            ':area'            => $area,
            ':ritase'          => !empty($row['ritase']) ? $row['ritase'] : 0,
            ':day_nik'         => !empty($row['day_nik']) ? $row['day_nik'] : null,
            ':day_nama'        => !empty($row['day_nama']) ? $row['day_nama'] : null,
            ':day_unit_hm'     => !empty($row['day_unit_hm']) ? $row['day_unit_hm'] : null,
            ':day_hm_start'    => !empty($row['day_hm_start']) ? $row['day_hm_start'] : 0,
            ':day_hm_end'      => !empty($row['day_hm_end']) ? $row['day_hm_end'] : 0,
            ':day_hm_hours'    => !empty($row['day_hm_hours']) ? $row['day_hm_hours'] : 0,
            ':night_nik'       => !empty($row['night_nik']) ? $row['night_nik'] : null,
            ':night_nama'      => !empty($row['night_nama']) ? $row['night_nama'] : null,
            ':night_ritase'    => !empty($row['night_ritase']) ? $row['night_ritase'] : 0, // Mengakomodasi ritase malam
            ':night_unit_hm'   => !empty($row['night_unit_hm']) ? $row['night_unit_hm'] : null,
            ':night_hm_start'  => !empty($row['night_hm_start']) ? $row['night_hm_start'] : 0,
            ':night_hm_end'    => !empty($row['night_hm_end']) ? $row['night_hm_end'] : 0,
            ':night_hm_hours'  => !empty($row['night_hm_hours']) ? $row['night_hm_hours'] : 0,
            ':unit_km'         => !empty($row['unit_km']) ? $row['unit_km'] : null,
            ':day_km_awal'     => !empty($row['day_km_awal']) ? $row['day_km_awal'] : 0,
            ':day_km_akhir'    => !empty($row['day_km_akhir']) ? $row['day_km_akhir'] : 0,
            ':day_km_total'    => !empty($row['day_km_total']) ? $row['day_km_total'] : 0,
            ':night_km_awal'   => !empty($row['night_km_awal']) ? $row['night_km_awal'] : 0,
            ':night_km_akhir'  => !empty($row['night_km_akhir']) ? $row['night_km_akhir'] : 0,
            ':night_km_total'  => !empty($row['night_km_total']) ? $row['night_km_total'] : 0
        ]);
    }

    $pdo->commit();
    echo json_encode(['status' => 'success', 'message' => 'Data berhasil disimpan.']);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan data: ' . $e->getMessage()]);
}
