-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 29, 2026 at 01:38 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_monitoring_hm`
--

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_produksi`
--

CREATE TABLE `transaksi_produksi` (
  `id` int NOT NULL,
  `tanggal` date NOT NULL,
  `area` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ritase` decimal(5,1) DEFAULT '0.0',
  `day_nik` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `day_nama` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `night_ritase` decimal(5,1) DEFAULT '0.0',
  `day_unit_hm` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `day_hm_start` decimal(8,2) DEFAULT '0.00',
  `day_hm_end` decimal(8,2) DEFAULT '0.00',
  `day_hm_hours` decimal(5,2) DEFAULT '0.00',
  `night_nik` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `night_nama` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `night_unit_hm` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `night_hm_start` decimal(8,2) DEFAULT '0.00',
  `night_hm_end` decimal(8,2) DEFAULT '0.00',
  `night_hm_hours` decimal(5,2) DEFAULT '0.00',
  `unit_km` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `day_km_awal` decimal(10,2) DEFAULT '0.00',
  `day_km_akhir` decimal(10,2) DEFAULT '0.00',
  `day_km_total` decimal(8,2) DEFAULT '0.00',
  `night_km_awal` decimal(10,2) DEFAULT '0.00',
  `night_km_akhir` decimal(10,2) DEFAULT '0.00',
  `night_km_total` decimal(8,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_produksi_kemarin`
--

CREATE TABLE `transaksi_produksi_kemarin` (
  `id` int NOT NULL,
  `tanggal` date NOT NULL,
  `area` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ritase` decimal(5,1) DEFAULT '0.0',
  `day_nik` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `day_nama` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `night_ritase` decimal(5,1) DEFAULT '0.0',
  `day_unit_hm` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `day_hm_start` decimal(8,2) DEFAULT '0.00',
  `day_hm_end` decimal(8,2) DEFAULT '0.00',
  `day_hm_hours` decimal(5,2) DEFAULT '0.00',
  `night_nik` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `night_nama` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `night_unit_hm` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `night_hm_start` decimal(8,2) DEFAULT '0.00',
  `night_hm_end` decimal(8,2) DEFAULT '0.00',
  `night_hm_hours` decimal(5,2) DEFAULT '0.00',
  `unit_km` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `day_km_awal` decimal(10,2) DEFAULT '0.00',
  `day_km_akhir` decimal(10,2) DEFAULT '0.00',
  `day_km_total` decimal(8,2) DEFAULT '0.00',
  `night_km_awal` decimal(10,2) DEFAULT '0.00',
  `night_km_akhir` decimal(10,2) DEFAULT '0.00',
  `night_km_total` decimal(8,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transaksi_produksi`
--
ALTER TABLE `transaksi_produksi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tanggal_area` (`tanggal`,`area`);

--
-- Indexes for table `transaksi_produksi_kemarin`
--
ALTER TABLE `transaksi_produksi_kemarin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tanggal_area_kemarin` (`tanggal`,`area`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transaksi_produksi`
--
ALTER TABLE `transaksi_produksi`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transaksi_produksi_kemarin`
--
ALTER TABLE `transaksi_produksi_kemarin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
