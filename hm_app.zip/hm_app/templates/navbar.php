<nav class="bg-white border-b border-slate-200 fixed top-0 z-40 w-full h-16 flex items-center justify-between px-6 shadow-sm">
    <div class="flex items-center gap-3">
        <!-- Icon aplikasi -->
        <div class="bg-amber-500 text-white p-2 rounded-lg flex items-center justify-center w-10 h-10 shadow-md shadow-amber-500/20">
            <i class="fa-solid fa-truck-monster text-lg"></i>
        </div>
        <div>
            <span class="font-bold text-slate-900 tracking-wide text-lg block leading-none">HM_APP</span>
            <span class="text-xs text-slate-500 font-medium">Project Control System</span>
        </div>
    </div>
    
    <!-- Info User / Dispatcher -->
    <div class="flex items-center gap-3 border-l border-slate-200 pl-4 h-8">
        <div class="text-right hidden sm:block">
            <span class="text-sm font-semibold text-slate-700 block leading-tight">Control Room</span>
            <span class="text-[11px] font-medium text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                <i class="fa-solid fa-circle text-[7px] mr-1 align-middle animate-pulse"></i>Shift Active
            </span>
        </div>
        <div class="w-9 h-9 bg-slate-100 rounded-full flex items-center justify-center border border-slate-200">
            <i class="fa-solid fa-user-gear text-slate-500"></i>
        </div>
    </div>
</nav>