</main> <!-- Menutup tag main yang dibuka di index.php -->
</div> <!-- Menutup tag wrapper layout yang dibuka di index.php -->

<!-- Footer -->
<footer class="bg-white border-t border-slate-200 py-4 px-6 text-center text-xs text-slate-500 md:pl-70 transition-all mt-auto z-20">
    &copy; <?= date('Y'); ?> <strong>HM_APP</strong> - Project Control Hauling Department. All Rights Reserved.
</footer>
</body>

</html>