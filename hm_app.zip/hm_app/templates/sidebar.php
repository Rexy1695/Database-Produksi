<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<aside class="w-64 bg-slate-900 text-slate-400 border-r border-slate-800 fixed top-16 left-0 bottom-0 z-30 pt-4 px-4 flex flex-col justify-between hidden md:flex">
    <div class="flex flex-col gap-1">
        <div class="text-[11px] font-bold uppercase tracking-wider text-slate-600 px-3 mb-2">
            Main Menu
        </div>

        <!-- Dashboard -->
        <a href="<?= MAIN_URL ?>/index_main.php"
            class="flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all group
           <?= $currentPage == 'index_main.php'
                ? 'bg-slate-800 text-white font-medium'
                : 'text-slate-400 hover:bg-slate-800 hover:text-white' ?>">
            <i class="fa-solid fa-chart-pie text-amber-500 group-hover:scale-110 transition-transform"></i>
            <span>Dashboard</span>
        </a>

        <!-- Pos Kontrol -->
        <ul class="space-y-2 mt-2">

            <li>
                <a href="<?= MAIN_URL ?>/area/km98.php"
                    class="flex items-center p-2 rounded-lg transition
                   <?= $currentPage == 'km98.php'
                        ? 'bg-amber-500 text-white'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-white' ?>">
                    <i class="fa-solid fa-road mr-2"></i>
                    KM 98
                </a>
            </li>

            <li>
                <a href="<?= MAIN_URL ?>/area/km6.php"
                    class="flex items-center p-2 rounded-lg transition
                   <?= $currentPage == 'km6.php'
                        ? 'bg-amber-500 text-white'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-white' ?>">
                    <i class="fa-solid fa-road mr-2"></i>
                    KM 6
                </a>
            </li>

            <li>
                <a href="<?= MAIN_URL ?>/area/km10.php"
                    class="flex items-center p-2 rounded-lg transition
                   <?= $currentPage == 'km10.php'
                        ? 'bg-amber-500 text-white'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-white' ?>">
                    <i class="fa-solid fa-road mr-2"></i>
                    KM 10
                </a>
            </li>

        </ul>
    </div>

    <div class="border-t border-slate-800 py-4 text-[11px] text-slate-600 px-3">
        <p>Environment:
            <span class="text-slate-500 font-mono">Project Control</span>
        </p>
    </div>
</aside>